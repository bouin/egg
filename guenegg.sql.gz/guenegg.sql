-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
INSERT INTO `be_sessions` VALUES
('5e73faa2b6e0efbcc216e8d79c0901bb42b1c90ed6ac541fe6eb1f00cef0393d','[DISABLED]',2,1777270252,'a:1:{s:26:\"formProtectionSessionToken\";s:64:\"46c9b78ed6f52620fd865ffc63de25f8cc0695f755ed5c7b645e3b3d069bace0\";}');
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `uc` mediumblob DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1776939260,1776865577,1,0,0,0,NULL,'default','a:5:{s:10:\"moduleData\";a:4:{s:23:\"backend_user_management\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:0:{}i:1;s:32:\"89494ca03c0d71614c20797c37296c5a\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:16:\"opendocs::recent\";a:1:{s:32:\"89494ca03c0d71614c20797c37296c5a\";a:5:{i:0;s:9:\"studio_gg\";i:1;a:5:{s:4:\"edit\";a:1:{s:8:\"be_users\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:31:\"&edit%5Bbe_users%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:8:\"be_users\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:83:\"/typo3/module/system/user-management?token=008dd8d838442b95e51b58f6344b18242055a1ad\";}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:4:{s:23:\"backend_user_management\";s:40:\"e2f21276a325c4d1cb823be8303fb7d069dbdf7d\";s:10:\"FormEngine\";s:40:\"e2f21276a325c4d1cb823be8303fb7d069dbdf7d\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"e2f21276a325c4d1cb823be8303fb7d069dbdf7d\";s:16:\"opendocs::recent\";s:40:\"e2f21276a325c4d1cb823be8303fb7d069dbdf7d\";}}',0,NULL,'','studio_gg','$argon2i$v=19$m=65536,t=16,p=1$MDhqM1BNclFYczFZTzY1bg$o89KnEqfkq6OcwaBVaB/gLCheTIazTPEetUvDID85jI','',0,NULL,'','dani@studiothompfister.com','',1,3,NULL,0,NULL,'',NULL,1776925312,NULL),
(2,0,1776939322,1776939213,0,0,0,0,NULL,'default','a:7:{s:10:\"moduleData\";a:6:{s:23:\"backend_user_management\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"57be76d1176cd993f136c0d88877d93e\";a:5:{i:0;s:9:\"Wohnungen\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:32;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B32%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:32;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:0:\"\";}}i:1;s:32:\"57be76d1176cd993f136c0d88877d93e\";}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:16:\"opendocs::recent\";a:8:{s:32:\"1d9b29725e7f63f56a69e02c50a5665c\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:27;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B27%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:27;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=549b6a2ef48dbfb7fb193676456ea8515c78d048&id=3#element-tt_content-27\";}s:32:\"ac8eceb4554a238d877cdbced8a9c761\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:26;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B26%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:26;s:3:\"pid\";i:3;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=549b6a2ef48dbfb7fb193676456ea8515c78d048&id=3\";}s:32:\"37f78eded394840abf86f69fe8a46286\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:24;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B24%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:24;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=549b6a2ef48dbfb7fb193676456ea8515c78d048&id=4\";}s:32:\"87081a86b53312865ee3b6074092ece3\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:23;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B23%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:23;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=549b6a2ef48dbfb7fb193676456ea8515c78d048&id=4\";}s:32:\"e1da1855e005674bf544fb90c5e48165\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:22;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B22%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:22;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=549b6a2ef48dbfb7fb193676456ea8515c78d048&id=4\";}s:32:\"af6a208f792a83220f87a953a62a081a\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:6;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:33:\"&edit%5Btt_content%5D%5B6%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:6;s:3:\"pid\";i:2;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=549b6a2ef48dbfb7fb193676456ea8515c78d048&id=2&#element-tt_content-6\";}s:32:\"7379749a99e9acb386dd0e97c5e558df\";a:5:{i:0;s:20:\"Beratung und Verkauf\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:20;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B20%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:20;s:3:\"pid\";i:10;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:99:\"/typo3/module/web/layout?token=549b6a2ef48dbfb7fb193676456ea8515c78d048&id=10#element-tt_content-20\";}s:32:\"22cbd9b921ab5848edaac19c41752085\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:19;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B19%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:19;s:3:\"pid\";i:10;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:99:\"/typo3/module/web/layout?token=549b6a2ef48dbfb7fb193676456ea8515c78d048&id=10#element-tt_content-19\";}}s:16:\"browse_links.php\";a:1:{s:12:\"expandFolder\";s:20:\"1:/user_upload/PDFs/\";}s:9:\"clipboard\";a:5:{s:5:\"tab_1\";a:0:{}s:5:\"tab_2\";a:0:{}s:5:\"tab_3\";a:0:{}s:7:\"current\";s:6:\"normal\";s:6:\"normal\";a:2:{s:2:\"el\";a:1:{s:13:\"tt_content|21\";s:1:\"1\";}s:4:\"mode\";s:4:\"copy\";}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:6:{s:23:\"backend_user_management\";s:40:\"44cff93071b8c908cd50de92f1d2e2974a400e80\";s:10:\"FormEngine\";s:40:\"8b0361670511e081950c2d878c891b826abd1131\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"8b0361670511e081950c2d878c891b826abd1131\";s:16:\"opendocs::recent\";s:40:\"1da27ef954ffc576a2a27d9d9e16ecfc0741bf62\";s:16:\"browse_links.php\";s:40:\"8b0361670511e081950c2d878c891b826abd1131\";s:9:\"clipboard\";s:40:\"1da27ef954ffc576a2a27d9d9e16ecfc0741bf62\";}s:10:\"inlineView\";s:1016:\"{\"be_users\":{\"2\":{\"sys_file_reference\":[2]}},\"tt_content\":{\"NEW69ea09a1edc93273522896\":{\"sys_file_reference\":[4]},\"NEW69ea1119e84de817682126\":{\"sys_file_reference\":[5]},\"3\":{\"sys_file_reference\":[8,9,10]},\"4\":{\"sys_file_reference\":[12]},\"NEW69ea13912c4ab034917437\":{\"sys_file_reference\":[13]},\"10\":{\"sys_file_reference\":{\"1\":\"\"}},\"11\":{\"sys_file_reference\":[]},\"13\":{\"sys_file_reference\":{\"1\":\"\"}},\"16\":{\"sys_file_reference\":[39],\"tt_content\":{\"1\":\"\"}},\"21\":{\"sys_file_reference\":[25,26,27]},\"28\":{\"sys_file_reference\":[37]},\"NEW69eb3c99da0e6836493958\":{\"tx_mask_places\":[1]},\"29\":{\"tx_mask_places\":[\"\",5]},\"30\":{\"tt_content\":[31],\"tx_mask_accordion_with_data\":{\"5\":\"1\"}},\"NEW69ecb8e03007f612577217\":{\"tx_mask_apartments\":[1]},\"32\":{\"tx_mask_apartments\":[\"\",7],\"sys_file_reference\":[42,44]}},\"tx_powermail_domain_model_form\":{\"NEW69eb15f9ab145008659280\":{\"tx_powermail_domain_model_field\":[1],\"tx_powermail_domain_model_page\":[1]},\"1\":{\"tx_powermail_domain_model_page\":[\"1\"],\"tx_powermail_domain_model_field\":[\"\"]}}}\";s:11:\"colorScheme\";s:5:\"light\";}',0,NULL,'','studio_gg','$argon2i$v=19$m=65536,t=16,p=1$SC8wYXZXdnRBZUJiTUpHcQ$SVc2Tk9iRwY2128WiNBxmictv6rO47PS1WBghk2hb3w','',1,NULL,'','dani@studiothompfister.com','STP',1,3,NULL,0,NULL,'',NULL,1777266942,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'redirects_ee31ccff4f35371c553b52c18d11eb6fdab3c114',1777270898,'x�K�2���\0O�'),
(2,'redirects_df58248c414f342c81e056b40bee12d17a08bf61',1777270898,'x�K�2���\0O�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'3__0_0_0_0',1779859298,'x��V;��8�+�A\"�k��VArH�C\Zo\\E��X&,�\nI�k,��]w�Q��\0)�\"�t�o�y?H�4byrO�M�?�|�G=+�{���\r�Y*E*�#%m:\r$�M�K�w��r\nQR!g��l�\Z)��{be	�\0���\n�X�Ϡ-Cd�GG ��=��y�Gqd/J.k+c�:Ӽ�<��d!X�GU�(��yq�&h��JRӶ�i�9ox��N�tT@���(�}I<���A+L�+��8\\G��4!����FA��� <� ����eQ��\\�p�9�H�KVJ⌰���T���TB���M�7�G��xy�����{O�z�x����w�u��I�lg�s\"O���WaN\n�*�99\nސ�8�R�{d��2\r�H\'L]#[��˵	8V�z$���#x�\nҬ+��յ�!4h��21�Bٟ����*s�+Y����W�@/�h�U.�:���(���]��V� �[���^�4��Q(��?t�S���_�����Z++l��u\'SQ�\n0���\0S�T�����2����c�X�M]i��ݱ��g�*�V;��*�S(e����g�^�(��n��ʲ��A*Aet��\n�>�H�^X�.f���@g`�������|�Ði���)��mK�c�chq�̒!��~��3I�U@j�IrtIK[r��Eݗ0�~�B8�/�1�%N����ś�[�8�l���ϡ�;�ؖ���5�Y{�*��B�~��!�\Z3���X��F~)i7�����+�(=�Y��\\��dƷV�6�6���\n�f�,���蜚n�$��pgz�������R�u���X������as(���rФ�懵��ɠaZ��C��[�e��	oP�fC�?��qd\0?\r�g�����1\\v�٣�Z����l�Yr���cc �`(7�\r9���:P����4Ь�\r6�8K.g�����]nO��,9lLC�Mi������Y�?S����\r�t�۬~���~�N��OU��\'8H`\nf�D�̫�?�_�|��E4�IV��09ҾV��e�ʻ�_����|���v�'),
(2,'4__0_0_0_0',1779859298,'x��V͎�6~�B砑�,kOAR��\"��E�AKc��$�$���7�/��(Jr��C��8ߐ����EZ��\"���.+^d�)��U�=+��\r�[*E*+\"%m{\r$�]�O�w��唢�\nBN� gWD4��H����*�F`_D(U(�Z1|]\"y�Ԃ��,�\"�#{Qr�XW��D����� K�z�8~�Ɋ������Qj��ȫ$\r���@��4Iܑ�\n��\n�|��/�GX?����*v<��F���N(��5�^P�� 4�G�\"�zY�}u�\'8��h%$+%qJX��t���@��ĉ�9-����������?�o�������_>����i��76&�,Ƥ�B����-	�C/�|@F���!S�Ҟ�q��5����5�,Qτ�=<�/�A�u���0��V�&&V��S[�a�	&�,����!`������j}��SO�\0���>�p���Q��-�-��^��������p�1�2pEG?����[�+,9�u5SQ�\n0]��	\0��T��^WwH����)�xU7ڨ�DWmhC����p\"���J�|f��.*鼛�β�pz�J�RY\0���B��M�����o�EЅ�$:��*,+���{7d\Z��eH�$�Hy��sL�-�Y2���O�K&�0H�6�NkiS���l�\n��of��<���ɑ7\r�x���G8\n�3��N��+iC\Z֝��z��~��!�Zӷ�ۘ��z~-i?�V�+���+��<�U����lƷ�`�e�Mvk��6K�_q:��S0I�o`\n�q�Ǡ�hɛ�z-eK78��5Ȣ~n`a�vЇB�5,�2�a�Y[z9�\Z���X1����\\T-����a6Դ-���#��h(�k,toL���m�2g?@<e�ϒc㷔o#i�H��n�E变�Б\n~�O-�`S���g�p�\"XTOs{��g�qb\Z�MJ{�U��p�_f���y��A����~��ﾅ�P?�(�������w8H`\n�\"z��\r���Q~�1�Z+�)\'���ɑ��W+���X!������xE'),
(3,'5__0_0_0_0',1779859298,'x��V͎�6~�B砑�,kOA�@�\\v��\'��h��$�$���7�/�!��(�rhir�|C��i�̋���xVŦ�^E����[�G**+\"�4m{$�]�O�w�rJYQ�BNn8�\"�X�4�Rb�{�Uź�H�Z�<c]\"y���{U$EGxQ	�yW���,7��\"���R�^s_}@���y���6�HC�z�5#�x˃?�$�HO%��\nVb���/�GX[?����*~<���>�N(��%B/��\'&�4�G��z!꾺��B�l�(%qJ n}:�tz`�M���mN윍�3��z��K�ß��7�������wo]~��4ɷ�D� ��Ø����sr��%�r�V�61䚵�\'��Br}�0y㟷��%���gO=�uf��⬯=]jkH���7Ѕ��� �T3�*��<q�||\0���v�7�=�DK� \"��[B�jЃ)����W1w{?T��a8�U8����������\nG\r��ES�T�L��}��Mu�����vH���c�y�U���#�fCbϠuh�1@Ũ,O��1H+f6���\"d��w�W��MJKZj�H:hڔ� ��᡹�\Z]x�+b�K\n�â�yH�wCf�jX��I���?�<:���%c���t�d���4P_����V�r�we3Tl�`���p�bOa.	rM#.^�|*��ݑ%�+����/iC\Zޝ矈z��y��[۵�ې��5x~-i?�V�+���+��<�Ř���lƷ�`�e�Mvk��6K�_q:��30I���Ǚ��g�%���E\nK78���Ȣ~n`a�XvЇB�5,�2�a�Y#��M\r�7T,�}���*�oQfKM�«Y;�����{;`r6;<bײg?@<�������mc$����k�\\T��a��T��|xZh���z��5������x�Ň�81-�&%�x�}��Y�?oS3���]n���n�\rl���{������`Ÿf�E<��ǆ���A~�1�Z+�-\'�V�ɑ�����3�~����\n��/��w�'),
(4,'7__0_0_0_0',1779859298,'x��V͎�6~�B砕�dkOA�HE.ޠ艠��LXU���]�����G%9@P4@��������-���=-�x�Ŧ�VE����\r�[*E*+\"%m{\r$y��6q�\'�S��*9���Q\r(0Rb{�Ī\n��JJ�F�AW�ȶ��@j�T/�����^�\\(��Fu��w��E$��d)X�G]���jxy�&�y���]=�\Z����PI��驀N�`�Q�&�+��0�sXŎ�񺅟��~ �	��(z��#��?�#x��Y�)���bA�������lFܸu�tz��M���MZ����xu�����cO~{����7����J��<a�A�Q)y����(xK�ϡ�Z> #���\"S�Ҟ�q��5���xg\\����k{x�	^��@�$�gu�at\r~[a��h����N��A��!�/�u��S5g�E�{����.��O=Q\0c����%>��G �[\"[%\r��K�	�T�|?z��\\�������S�9������.l*jP��h��=��}��������S��_�h��]��\r�g�:�V��*�S(e���*�g�^����n��̺��A*AKe4�\n�6�#H0wXh.f@�͂.<�$щ&8Way��$ܻ!�p5,C�$ێ���?�d:��%c����n�$fi��f���-m�֕�P������x���0�89�����T^�	;%����񎕴!\r��s%�^��O�7�Yk��t�A]�Bϯ%�&�J\\�p%4�x%�g�h��1�M���D�fY��nM�mv����8�Q�����m���{&Z�j�^K��\rήb\r���XX6����v\r�A��v�o֖^N)��ih7^�}n)UK,;�A}�\r�rŜ�vd\0�\r�{������]��٣�Z�.)��)cɱ�[ʷ����e�\\{7��G�V�H����@��6���,��Y3ܯ\n�ݞ|�Yr���r�Ҟx�}-����ަf�����y��v��k���V��wu���p��,�E\\��\r1��!��\r�\'Y�ϵ\"�r� +I���ШOZ?���\n����/���|1'),
(5,'8__0_0_0_0',1779859298,'x��V͎�6~�B砕�X����)�E.ޠ艠��LXU���X�����G%9@P4@���H\r����y�?�<y��.˟e�ɣ�����Fꭔ��呒�����.;l�x�ٓB�TAx����.�Jh@��ۻgV�Ѝ�!�P�P��0b�te���R>��2O�(��EɅb]m��n�9��<��d!X�Ƿ�[P2���2�M�y���]=�\Z��ޜ�#Mw��:��%D�\rL�V&��d밒U�xa����<�^\"������x�rn�E�Sw�z�SL\"�V�A��Zg��MP�N?ht�8��}S;��߾�xy�������������o޿����t0\'�,����J��a�Z>�Ah��!S�Ҟ�q��-���5�2QO��=<�/�A�u���0��VX&���K��rh���%���\\�~`�!:�xD�+V��A>�D	\0L�� ��\Z���E �����G�0�#?�S+�ht�#��:{c�y�t�����h*jP�@4`�J���^\r���C�X�M�h��3ݹ��?�u�v�	T�P�X��eH�]�(��n��e���$����\0:I�\nC��$X6,t��\"K�E�$���*�,_���0d\Z.�eJ�dߑ����XJ\'Z\\0�dL���n����* \r6�,9���-9º�JXX�[!���\'o\Z~�&��*�H�P	�#|��Nl�;VІ4������i����0k\ruM��ԕ)��Z�a:[�\\)M������h�ף0�����(�g�nsw�m���(tN-&a��\n�>��$��������J�u�oױY��,ls�P(;�rЬ������eа-�&�|̭�j�%�ԧ�H���jFG��h$�5V\n��S�,��O�Z��/����H�V�1��XF�ѻ�?b�CG)xi><\r�(h�Mg�5g�p�%XT�s��ϊ��4����;�W�k�_f���9M� ���oE�����|+������������$�)X*�w7��ۆ�7Dԟ|bEL�Ԋh�	��$A2��Ш�Z?�߷�_]!_�K�y�'),
(6,'2__0_0_0_0',1779862263,'x�uUM��6�+��Ek\';�М�b{(��Y=	�M;Blɕ�I�������J[����|�H�|d�\"o��όl7�M�5)&�Ϝ��k�V�ֆF6�3Pm���f�]o�I�\Zf �<mV{<ْ���^N�i@x`O\n����x��hRdG�h���5)IQ���T��n���!V}\"���/�k�G�%F�f=@�M/�wZ�c�MӞ�nb�)f[U��RБ)��rRux^Uz�,4��\'�5�m������/�Z��wf�s���(VgM�$U�Ma`��ȑ�gd_}��������\n�J��P�:���o�P3!�YO{.�3�I��_�� �Ur�sg,h�0my6��8����5��y���8\"�.H(�b�^Y����PR�7��v��q�j\'h�:F{���qn����_�ܧl��=H�W����	����\"I[���L.\Z�KS�ɚ��!�L:XI��4R�\0����ᮡL�Lo��l��	�Z����8����O��8|֜��S<������6/&]�S�Kg.�`}h�T�#�����8�~EX&�Yz�󉵨��.�+7P���e�T3���҅y�xaFוs���H��M��q��(�[��G����χ��������_�pn��~�][��8���L�VEt�������V��_��\n��\\�#\\G�?t�\0����Q�϶�qW�����u?�G\r�,��Ko���������*��q��	ǉ�D��T��&�=�G$#�n��#q��V	��s}�y1�>�E�hL���?uM�7�6(s�=\'$$��;��h�9��V$�d��Y\0Lҭ�$���M<��[Ѵu�<�&�	Z%�He�aC��f5	����[q~���FS��M����Nwߏ�-�� bY���-�>i��|\n;�\'D\"�7�A~�n��]���ݒ�ir�\'�r�\\����$����Ct');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'3__0_0_0_0','pageId_2'),
(2,'3__0_0_0_0','pageId_3'),
(3,'4__0_0_0_0','pageId_2'),
(4,'4__0_0_0_0','pageId_4'),
(5,'5__0_0_0_0','pageId_2'),
(6,'5__0_0_0_0','pageId_5'),
(7,'7__0_0_0_0','pageId_2'),
(8,'7__0_0_0_0','pageId_7'),
(9,'8__0_0_0_0','pageId_2'),
(10,'8__0_0_0_0','pageId_8'),
(11,'2__0_0_0_0','pageId_2');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `url` varchar(255) NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `contentFromPid` (`content_from_pid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1776865633,1776865609,1,1,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"slug\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,0.5,0,1,'Grünegg','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,0,1776866736,1776865629,0,0,0,0,'',128,NULL,0,0,0,0,NULL,'{\"TSconfig\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"cache_tags\":\"\",\"cache_timeout\":\"\",\"canonical_link\":\"\",\"categories\":\"\",\"content_from_pid\":\"\",\"description\":\"\",\"doktype\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"is_siteroot\":\"\",\"keywords\":\"\",\"l18n_cfg\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"media\":\"\",\"module\":\"\",\"nav_hide\":\"\",\"nav_title\":\"\",\"newUntil\":\"\",\"no_follow\":\"\",\"no_index\":\"\",\"no_search\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"og_title\":\"\",\"php_tree_stop\":\"\",\"rowDescription\":\"\",\"seo_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"slug\":\"\",\"starttime\":\"\",\"subtitle\":\"\",\"target\":\"\",\"title\":\"\",\"tsconfig_includes\":\"\",\"twitter_card\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_title\":\"\"}',0,0,0,0,1,0,31,27,0,1777029973,0,0,0,0.5,0,1,'Grünegg Webseite','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',1,1,0,'',0,'pagets__default','pagets__default','','',0,0,'','','',NULL,0,'',NULL,0,''),
(3,2,1776925491,1776925472,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1777266972,0,0,0,0.5,0,1,'Wohnen','/wohnen',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(4,2,1776925495,1776925481,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1777028903,0,0,0,0.5,0,1,'Umgebung','/umgebung',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(5,2,1776925497,1776925487,0,0,0,0,'0',768,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1777021856,0,0,0,0.5,0,1,'Kontakt','/kontakt',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(6,2,1776929184,1776927029,0,0,0,0,'0',1024,NULL,0,0,0,0,NULL,'{\"nav_hide\":\"\"}',0,0,0,0,1,0,31,27,0,1776929184,0,0,0,0.5,0,1,'404','/404',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(7,2,1776930071,1776930027,0,0,0,0,'0',1280,NULL,0,0,0,0,NULL,'{\"nav_hide\":\"\"}',0,0,0,0,1,0,31,27,0,1776930071,0,0,0,0.5,0,1,'Datenschutz','/datenschutz',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(8,2,1776930076,1776930035,0,0,0,0,'0',1536,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,1776930076,0,0,0,0.5,0,1,'Impressum','/impressum',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(9,2,1777014257,1777014255,0,0,0,0,'0',1792,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,0,0,0,0,0.5,0,254,'Storage','/storage',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(10,5,1777014658,1777014649,0,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,2,0,31,27,0,1777015065,0,0,0,0.5,0,1,'Danke für Ihre Nachricht','/kontakt/danke-fuer-ihre-nachricht',NULL,0,0,0,0,'',1,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1776866714,1776866714,'/user_upload/greuegg-home.jpg','ff189e216432a6eeba925eee560b4fc8e1664bb5','19669f1e02c2f16705ec7587044c66443be70725','jpg','greuegg-home.jpg','e9c80d51ec7ee28cf926ae4eaf96bd95cb9ea371',1776866714,1776866714,640963,1,2,'image/jpeg',0,0),
(2,0,1776929308,1776929308,'/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Images/logo1.svg','5436cf515f1793035b82f466584a6d0c2d11b2f2','0694e63664343e0c9119289f1fafa23fb4d4b57f','svg','logo1.svg','aa7d4e9d949b3d96a1bf68e3a42f8816f55defef',1776870527,1776870527,3220,0,2,'image/svg+xml',0,0),
(3,0,1776929409,1776929409,'/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Images/adowia.svg','3f163136dafca09938206e26988ffe0fa5c433aa','0694e63664343e0c9119289f1fafa23fb4d4b57f','svg','adowia.svg','9f71c1dc341b2b7b987ff290db43004e03fe97af',1776929388,1776929388,1451,0,2,'image/svg+xml',0,0),
(4,0,1776939314,1776939314,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1776865466,1776865466,0,1,5,'application/x-empty',0,0),
(5,0,1776939318,1776939318,'/user_upload/Bildschirmfoto_2026-04-23_um_12.15.08.png','897775ab52c1ef0786217ff733074c1bdfd95fe0','19669f1e02c2f16705ec7587044c66443be70725','png','Bildschirmfoto_2026-04-23_um_12.15.08.png','849aa2ac09ccb39e0b57395999ce7c87d0565a9c',1776939318,1776939318,190746,1,2,'image/png',0,0),
(6,0,1776945679,1776945679,'/user_upload/HOme/wohnen-konolfingen-1.jpg','c20e096fc7ba2e8dd3178a2f7d68b023ae59794b','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','wohnen-konolfingen-1.jpg','12ac1b35b22ba01091c914253e5b1239187b6f0a',1776945679,1776945679,962001,1,2,'image/jpeg',0,0),
(7,0,1776945679,1776945679,'/user_upload/HOme/wohnen-konolfingen-2.jpg','f62b4ecd18e406e39238a37c8e7d2d3d312ebee4','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','wohnen-konolfingen-2.jpg','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e',1776945679,1776945679,2326603,1,2,'image/jpeg',0,0),
(8,0,1776947512,1776947512,'/user_upload/HOme/wohnung-konolfingen.jpg','5ac6b257ad51cd4a74a1481a09c77bfceb7ca0a3','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','wohnung-konolfingen.jpg','ff446f94f456d638c4dfca3e569b25c1cb419bd8',1776947512,1776947512,2082608,1,2,'image/jpeg',0,0),
(9,0,1776947904,1776947904,'/user_upload/HOme/konolfingen-haus.jpg','9cb93b2da9b6b88bcf3028d4eafa1aee378979dc','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','konolfingen-haus.jpg','648ad7d6374a41e0db2e271a444fc29ddc67474c',1776947904,1776947904,2127061,1,2,'image/jpeg',0,0),
(10,0,1776947904,1776947904,'/user_upload/HOme/konolfingen-haus-3.jpg','2120a22d1435d55b2b7af36e2c72c2b63bd3a18a','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','konolfingen-haus-3.jpg','8793628f4e1d6575fed55b7d494a0c3d7fc70586',1776947904,1776947904,869471,1,2,'image/jpeg',0,0),
(11,0,1776948036,1776948036,'/user_upload/konolfingen-familie.jpg','25d8659d85d8607212c0040c961d5ccd0fc76241','19669f1e02c2f16705ec7587044c66443be70725','jpg','konolfingen-familie.jpg','7efa14c9e93af361a4640bd3581f0305902a93bf',1776948036,1776948036,1283817,1,2,'image/jpeg',0,0),
(12,0,1776948176,1776948176,'/user_upload/HOme/konolfingen-hund.jpg','b816ab34805f6e0be97ed96d77c97096fa15c64d','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','konolfingen-hund.jpg','9fcf566c1f3994c3e7bde8aa875a3b22a0630f4a',1776948176,1776948176,1992893,1,2,'image/jpeg',0,0),
(13,0,1776952011,1776952011,'/user_upload/HOme/frau-wohnt-in-konolfingen.jpg','1788ad70b03d94d81e5eae704544777ea64b2cb0','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','frau-wohnt-in-konolfingen.jpg','47a6631b5d05ba603a5b9ef5633e3278d47652d5',1776952011,1776952011,1465425,1,2,'image/jpeg',0,0),
(14,0,1776952871,1776952871,'/user_upload/HOme/dominique-waser.jpg','02e1993756f48281cc052022e06ff982b2bbdab8','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','dominique-waser.jpg','7b9ac90ddc6af81a5b1d3e8977c28b3059114713',1776952871,1776952871,862431,1,2,'image/jpeg',0,0),
(15,0,1776954738,1776954738,'/user_upload/Wohnen/kon2.jpg','01cfa667fddea116c65c2a3424aeb73c472047ce','2730809ecc7cdf7b21d0723711cf6855336cd90e','jpg','kon2.jpg','c4a899600c2d56d36a66a70942fb49c4ad303ceb',1776954738,1776954738,1224480,1,2,'image/jpeg',0,0),
(16,0,1776955937,1776955937,'/user_upload/kind-wohnt-in-konolfingen.jpg','79a3d240d72dee765a40737581851acc8ddc2c89','19669f1e02c2f16705ec7587044c66443be70725','jpg','kind-wohnt-in-konolfingen.jpg','e477f2909d801bbbd31e3acfbc51e6b518508878',1776955937,1776955937,1952109,1,2,'image/jpeg',0,0),
(17,0,1777014155,1777014155,'/user_upload/Wohnen/blumen-wohnung-in-konolfingen.jpg','97046466c5d54960b6dd7d32654df0ac24c8df7b','2730809ecc7cdf7b21d0723711cf6855336cd90e','jpg','blumen-wohnung-in-konolfingen.jpg','b0df6fd2c44e6c04e008a95b75e4736a812c7478',1777014155,1777014155,942166,1,2,'image/jpeg',0,0),
(18,0,1777018482,1777018482,'/user_upload/Umgebung/konol1.jpg','c5679f5cfab4dbf22b2082184c4a50a900a3b16d','ca8b28a6a189475eeabc4db3096317d15339f901','jpg','konol1.jpg','8ca116667842171ff228055fdc3a9032f7a7a6b3',1777018482,1777018482,1545005,1,2,'image/jpeg',0,0),
(19,0,1777018482,1777018482,'/user_upload/Umgebung/wohnen-konolfingen-1.jpg','32249b6124b7ed2339320396af6e50b6781a7d88','ca8b28a6a189475eeabc4db3096317d15339f901','jpg','wohnen-konolfingen-1.jpg','12ac1b35b22ba01091c914253e5b1239187b6f0a',1777018482,1777018482,962001,1,2,'image/jpeg',0,0),
(20,0,1777018482,1777018482,'/user_upload/Umgebung/wohnen-konolfingen-2.jpg','20ca29a1179222c6c730a6bd324776322d197275','ca8b28a6a189475eeabc4db3096317d15339f901','jpg','wohnen-konolfingen-2.jpg','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e',1777018482,1777018482,2326603,1,2,'image/jpeg',0,0),
(21,0,1777019433,1777019433,'/user_upload/Umgebung/man-velo.jpg','b909a896514f18133f9a60e30b6ffc7697f845a0','ca8b28a6a189475eeabc4db3096317d15339f901','jpg','man-velo.jpg','e8109478cd6ecfddaac7cee64821f744110c19ca',1777019433,1777019433,843385,1,2,'image/jpeg',0,0),
(22,0,1777019755,1777019755,'/user_upload/HOme/gleitsicht_hero_small_desktop.png','a732aa3e0a7c0d027bd75b9bab6edf9ef08c2b96','2eadbad7519d410d5cb58d3afd276a42735043cc','png','gleitsicht_hero_small_desktop.png','6837242d3605b73f64d168b06cc5496db594009c',1777019755,1777019755,25183047,1,2,'image/png',0,0),
(23,0,1777019768,1777019768,'/user_upload/HOme/konolfingen-234.jpg','abdb149a3541022e34dadbaf98009fa30b117144','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','konolfingen-234.jpg','e3d7315c7d2438a97456c9ba0dfdcec3ad2f3b9a',1777019768,1777019768,2477430,1,2,'image/jpeg',0,0),
(24,0,1777021060,1777021060,'/user_upload/HOme/keller-konolfingen.jpg','c52ee1bee44902d7f06e808ce9ac96aec5940814','2eadbad7519d410d5cb58d3afd276a42735043cc','jpg','keller-konolfingen.jpg','4279379ad4a1a2fa5d5d5fa36cb8052dc4b7d415',1777021060,1777021060,2027155,1,2,'image/jpeg',0,0),
(25,0,1777021854,1777021854,'/user_upload/Wohnen/blumen-wohnung-in-konolfingen-2.jpg','18abde32cfce28327b702bd6660083ac7eb90da5','2730809ecc7cdf7b21d0723711cf6855336cd90e','jpg','blumen-wohnung-in-konolfingen-2.jpg','028ab61ad015961dca2391c37fff8bd43fa49108',1777021854,1777021854,967788,1,2,'image/jpeg',0,0),
(26,0,1777121584,1777121584,'/user_upload/PDFs/blank.pdf','5e245b4692223638cbc9c655ab990eab3c843793','6030031e970e654e81c8226ffbfaa34357ff20b1','pdf','blank.pdf','3dad168e79bc7f421760c98a8b6be2e1630a63ec',1777121584,1777121584,4911,1,5,'application/pdf',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `status` varchar(24) DEFAULT '',
  `latitude` decimal(24,14) DEFAULT 0.00000000000000,
  `longitude` decimal(24,14) DEFAULT 0.00000000000000,
  `pages` int(10) unsigned DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `visible` smallint(5) unsigned NOT NULL DEFAULT 1,
  `keywords` longtext DEFAULT NULL,
  `caption` longtext DEFAULT NULL,
  `creator_tool` varchar(255) NOT NULL DEFAULT '',
  `download_name` varchar(255) NOT NULL DEFAULT '',
  `creator` varchar(255) NOT NULL DEFAULT '',
  `publisher` varchar(120) NOT NULL DEFAULT '',
  `source` varchar(255) NOT NULL DEFAULT '',
  `copyright` longtext DEFAULT NULL,
  `location_country` varchar(45) NOT NULL DEFAULT '',
  `location_region` varchar(45) NOT NULL DEFAULT '',
  `location_city` varchar(45) NOT NULL DEFAULT '',
  `ranking` int(10) unsigned NOT NULL DEFAULT 0,
  `content_creation_date` bigint(20) NOT NULL DEFAULT 0,
  `content_modification_date` bigint(20) NOT NULL DEFAULT 0,
  `note` longtext DEFAULT NULL,
  `unit` varchar(3) NOT NULL DEFAULT '',
  `duration` int(11) NOT NULL DEFAULT 0,
  `color_space` varchar(4) NOT NULL DEFAULT '',
  `language` varchar(45) NOT NULL DEFAULT '',
  `fe_groups` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1776866714,1776866714,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,1,NULL,1326,789,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(2,0,1776929308,1776929308,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,2,NULL,956,181,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(3,0,1776929409,1776929409,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,3,NULL,155,27,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(4,0,1776939314,1776939314,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,4,NULL,0,0,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(5,0,1776939318,1776939318,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,5,NULL,320,256,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(6,0,1776945678,1776945678,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,6,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(7,0,1776945678,1776945678,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,7,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(8,0,1776947512,1776947512,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,8,NULL,3582,2072,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(9,0,1776947904,1776947904,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,9,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(10,0,1776947904,1776947904,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,10,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(11,0,1776948036,1776948036,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,11,NULL,2582,1494,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(12,0,1776948176,1776948176,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,12,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(13,0,1776952011,1776952011,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,13,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(14,0,1776952871,1776952871,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,14,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(15,0,1776954738,1776954738,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,15,NULL,2582,1494,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(16,0,1776955937,1776955937,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,16,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(17,0,1777014155,1777014155,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,17,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(18,0,1777018482,1777018482,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,18,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(19,0,1777018482,1777018482,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,19,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(20,0,1777018482,1777018482,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,20,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(21,0,1777019433,1777019433,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,21,NULL,1518,1130,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(22,0,1777019755,1777019755,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,22,NULL,5120,2880,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(23,0,1777019768,1777019768,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,23,NULL,3838,2220,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(24,0,1777021059,1777021059,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,24,NULL,2284,2131,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(25,0,1777021854,1777021854,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,25,NULL,1507,1740,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL),
(26,0,1777121584,1777121584,0,0,NULL,'',0,0,0,0,NULL,NULL,'',0.00000000000000,0.00000000000000,0,0,26,NULL,612,792,1,NULL,NULL,'','','','','',NULL,'','','',0,0,0,NULL,'',0,'','',NULL);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=119 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1776866714,1776866714,1,1,'/_processed_/b/4/preview_greuegg-home_d0d0971fbb.jpg','preview_greuegg-home_d0d0971fbb.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','e9c80d51ec7ee28cf926ae4eaf96bd95cb9ea371','Image.Preview','d0d0971fbb',64,38),
(2,1776866714,1776866714,1,1,'/_processed_/b/4/csm_greuegg-home_1cff4c8bc4.jpg','csm_greuegg-home_1cff4c8bc4.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e9c80d51ec7ee28cf926ae4eaf96bd95cb9ea371','Image.CropScaleMask','1cff4c8bc4',252,150),
(3,1776866714,1776866714,1,1,'/_processed_/b/4/csm_greuegg-home_89f27fecf2.jpg','csm_greuegg-home_89f27fecf2.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','e9c80d51ec7ee28cf926ae4eaf96bd95cb9ea371','Image.CropScaleMask','89f27fecf2',76,45),
(4,1776866737,1776866737,1,1,'/_processed_/b/4/csm_greuegg-home_ecf40b3a4d.jpg','csm_greuegg-home_ecf40b3a4d.jpg',NULL,'a:12:{s:5:\"width\";s:5:\"1280c\";s:6:\"height\";s:5:\"1280c\";s:13:\"fileExtension\";s:0:\"\";s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:7:\"noScale\";s:0:\"\";s:6:\"sample\";b:0;s:20:\"additionalParameters\";s:0:\"\";s:5:\"frame\";i:0;s:4:\"crop\";N;}','4f02ca5a16d98c6a664848c7ba1653128aee6201','e9c80d51ec7ee28cf926ae4eaf96bd95cb9ea371','Image.CropScaleMask','ecf40b3a4d',1280,1280),
(5,1776871049,1776871049,1,1,'/_processed_/b/4/csm_greuegg-home_5e743ecb87.jpg','csm_greuegg-home_5e743ecb87.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"2000c\";s:6:\"height\";s:5:\"1200c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','fb589d805113478b8a31f2f876cf119f57089760','e9c80d51ec7ee28cf926ae4eaf96bd95cb9ea371','Image.CropScaleMask','5e743ecb87',2000,1200),
(6,1776929308,1776929308,0,2,'',NULL,'','a:7:{s:5:\"width\";s:5:\"125px\";s:6:\"height\";s:4:\"auto\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','890377ffb359f1ffe1d5654954b6f7972e941e08','aa7d4e9d949b3d96a1bf68e3a42f8816f55defef','Image.CropScaleMask','9b8405330f',125,24),
(7,1776929315,1776929315,0,2,'',NULL,'','a:7:{s:5:\"width\";s:5:\"225px\";s:6:\"height\";s:4:\"auto\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','fb5ea3bc08a30745e9c1ad7d096abb3466164f2a','aa7d4e9d949b3d96a1bf68e3a42f8816f55defef','Image.CropScaleMask','3ede244404',225,43),
(8,1776929409,1776929409,0,3,'',NULL,'','a:7:{s:5:\"width\";s:5:\"175px\";s:6:\"height\";s:4:\"auto\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','7d88cefadaf70302c29410291277702fa6428375','9f71c1dc341b2b7b987ff290db43004e03fe97af','Image.CropScaleMask','7e35e122a9',175,30),
(9,1776929417,1776929417,0,2,'',NULL,'','a:7:{s:5:\"width\";s:5:\"255px\";s:6:\"height\";s:4:\"auto\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ff50ff0b71612303051657fe7d970af6ae36b190','aa7d4e9d949b3d96a1bf68e3a42f8816f55defef','Image.CropScaleMask','46a374d828',255,48),
(10,1776929436,1776929436,0,2,'',NULL,'','a:7:{s:5:\"width\";s:5:\"305px\";s:6:\"height\";s:4:\"auto\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','823ed4a60efa196b482f7a768470f100a97fdbef','aa7d4e9d949b3d96a1bf68e3a42f8816f55defef','Image.CropScaleMask','a138b70055',305,58),
(11,1776929436,1776929436,0,3,'',NULL,'','a:7:{s:5:\"width\";s:5:\"145px\";s:6:\"height\";s:4:\"auto\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','ee34dd4cc3c77d2d7e51258a946c90b6102ae29a','9f71c1dc341b2b7b987ff290db43004e03fe97af','Image.CropScaleMask','09bedd4190',145,25),
(12,1776939314,1776939314,1,1,'/_processed_/b/4/csm_greuegg-home_3e39a75c2b.jpg','csm_greuegg-home_3e39a75c2b.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','e9c80d51ec7ee28cf926ae4eaf96bd95cb9ea371','Image.CropScaleMask','3e39a75c2b',166,99),
(13,1776939318,1776939318,1,5,'/_processed_/7/d/csm_Bildschirmfoto_2026-04-23_um_12.15.08_8f14716ebd.png','csm_Bildschirmfoto_2026-04-23_um_12.15.08_8f14716ebd.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','849aa2ac09ccb39e0b57395999ce7c87d0565a9c','Image.CropScaleMask','8f14716ebd',144,115),
(14,1776939326,1776939319,1,5,'/_processed_/7/d/csm_Bildschirmfoto_2026-04-23_um_12.15.08_4d4a025ec5.png','csm_Bildschirmfoto_2026-04-23_um_12.15.08_4d4a025ec5.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','849aa2ac09ccb39e0b57395999ce7c87d0565a9c','Image.CropScaleMask','4d4a025ec5',188,150),
(15,1776939320,1776939319,1,5,'/_processed_/7/d/csm_Bildschirmfoto_2026-04-23_um_12.15.08_6dcf903466.png','csm_Bildschirmfoto_2026-04-23_um_12.15.08_6dcf903466.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','849aa2ac09ccb39e0b57395999ce7c87d0565a9c','Image.CropScaleMask','6dcf903466',56,45),
(16,1776939324,1776939324,1,5,'/_processed_/7/d/csm_Bildschirmfoto_2026-04-23_um_12.15.08_bb173a44f4.png','csm_Bildschirmfoto_2026-04-23_um_12.15.08_bb173a44f4.png','','a:2:{s:5:\"width\";s:3:\"24c\";s:6:\"height\";s:3:\"24c\";}','82b22ab432074975de2bed394e641126f85ea53b','849aa2ac09ccb39e0b57395999ce7c87d0565a9c','Image.CropScaleMask','bb173a44f4',24,24),
(17,1776945679,1776945679,1,6,'/_processed_/e/c/csm_wohnen-konolfingen-1_f159744ce9.jpg','csm_wohnen-konolfingen-1_f159744ce9.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','12ac1b35b22ba01091c914253e5b1239187b6f0a','Image.CropScaleMask','f159744ce9',100,115),
(18,1776945679,1776945679,1,7,'/_processed_/6/5/csm_wohnen-konolfingen-2_37bcfd43fd.jpg','csm_wohnen-konolfingen-2_37bcfd43fd.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e','Image.CropScaleMask','37bcfd43fd',100,115),
(19,1776945680,1776945680,1,6,'/_processed_/e/c/csm_wohnen-konolfingen-1_0c25ef3c88.jpg','csm_wohnen-konolfingen-1_0c25ef3c88.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','12ac1b35b22ba01091c914253e5b1239187b6f0a','Image.CropScaleMask','0c25ef3c88',130,150),
(20,1776945680,1776945680,1,6,'/_processed_/e/c/csm_wohnen-konolfingen-1_38d31786be.jpg','csm_wohnen-konolfingen-1_38d31786be.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','12ac1b35b22ba01091c914253e5b1239187b6f0a','Image.CropScaleMask','38d31786be',39,45),
(21,1776945697,1776945697,1,7,'/_processed_/6/5/csm_wohnen-konolfingen-2_ae415d7263.jpg','csm_wohnen-konolfingen-2_ae415d7263.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e','Image.CropScaleMask','ae415d7263',130,150),
(22,1776945697,1776945697,1,7,'/_processed_/6/5/csm_wohnen-konolfingen-2_5f3ff5e78d.jpg','csm_wohnen-konolfingen-2_5f3ff5e78d.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e','Image.CropScaleMask','5f3ff5e78d',39,45),
(23,1776945702,1776945702,1,6,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','12ac1b35b22ba01091c914253e5b1239187b6f0a','Image.CropScaleMask','9983d7e21b',0,0),
(24,1776945702,1776945702,1,7,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e','Image.CropScaleMask','871df98699',0,0),
(25,1776947513,1776947512,1,8,'/_processed_/6/3/csm_wohnung-konolfingen_180c54d2ac.jpg','csm_wohnung-konolfingen_180c54d2ac.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','ff446f94f456d638c4dfca3e569b25c1cb419bd8','Image.CropScaleMask','180c54d2ac',166,96),
(26,1776947514,1776947513,1,8,'/_processed_/6/3/csm_wohnung-konolfingen_63e62b52f2.jpg','csm_wohnung-konolfingen_63e62b52f2.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','ff446f94f456d638c4dfca3e569b25c1cb419bd8','Image.CropScaleMask','63e62b52f2',259,150),
(27,1776947514,1776947513,1,8,'/_processed_/6/3/csm_wohnung-konolfingen_65d4ad7954.jpg','csm_wohnung-konolfingen_65d4ad7954.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','ff446f94f456d638c4dfca3e569b25c1cb419bd8','Image.CropScaleMask','65d4ad7954',78,45),
(28,1776947524,1776947524,1,8,'/_processed_/6/3/csm_wohnung-konolfingen_472fee4586.jpg','csm_wohnung-konolfingen_472fee4586.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','ff446f94f456d638c4dfca3e569b25c1cb419bd8','Image.CropScaleMask','472fee4586',1920,1280),
(29,1776947708,1776947708,1,8,'/_processed_/6/3/csm_wohnung-konolfingen_7833671c3c.jpg','csm_wohnung-konolfingen_7833671c3c.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"800c\";s:6:\"height\";s:5:\"1200c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','f53552173bad8f51a3c183963d5077c61353bdca','ff446f94f456d638c4dfca3e569b25c1cb419bd8','Image.CropScaleMask','7833671c3c',800,1200),
(30,1776947904,1776947904,1,10,'/_processed_/b/a/csm_konolfingen-haus-3_ab8bbce236.jpg','csm_konolfingen-haus-3_ab8bbce236.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','8793628f4e1d6575fed55b7d494a0c3d7fc70586','Image.CropScaleMask','ab8bbce236',100,115),
(31,1776947904,1776947904,1,9,'/_processed_/d/f/csm_konolfingen-haus_662488c325.jpg','csm_konolfingen-haus_662488c325.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','648ad7d6374a41e0db2e271a444fc29ddc67474c','Image.CropScaleMask','662488c325',100,115),
(32,1776947907,1776947906,1,9,'/_processed_/d/f/csm_konolfingen-haus_5a496b92d2.jpg','csm_konolfingen-haus_5a496b92d2.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','648ad7d6374a41e0db2e271a444fc29ddc67474c','Image.CropScaleMask','5a496b92d2',130,150),
(33,1776947906,1776947906,1,9,'/_processed_/d/f/csm_konolfingen-haus_dad88cc73f.jpg','csm_konolfingen-haus_dad88cc73f.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','648ad7d6374a41e0db2e271a444fc29ddc67474c','Image.CropScaleMask','dad88cc73f',39,45),
(34,1776947922,1776947921,1,10,'/_processed_/b/a/csm_konolfingen-haus-3_bf486d38ff.jpg','csm_konolfingen-haus-3_bf486d38ff.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','8793628f4e1d6575fed55b7d494a0c3d7fc70586','Image.CropScaleMask','bf486d38ff',130,150),
(35,1776947921,1776947921,1,10,'/_processed_/b/a/csm_konolfingen-haus-3_c72a736758.jpg','csm_konolfingen-haus-3_c72a736758.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','8793628f4e1d6575fed55b7d494a0c3d7fc70586','Image.CropScaleMask','c72a736758',39,45),
(36,1776947925,1776947925,1,9,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','648ad7d6374a41e0db2e271a444fc29ddc67474c','Image.CropScaleMask','e15d3e1f62',0,0),
(37,1776947925,1776947925,1,10,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','8793628f4e1d6575fed55b7d494a0c3d7fc70586','Image.CropScaleMask','d2fa8ce1cb',0,0),
(38,1776948036,1776948036,1,11,'/_processed_/1/f/preview_konolfingen-familie_51b197ef0f.jpg','preview_konolfingen-familie_51b197ef0f.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','7efa14c9e93af361a4640bd3581f0305902a93bf','Image.Preview','51b197ef0f',64,37),
(39,1776948036,1776948036,1,11,'/_processed_/1/f/csm_konolfingen-familie_f30b397def.jpg','csm_konolfingen-familie_f30b397def.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','7efa14c9e93af361a4640bd3581f0305902a93bf','Image.CropScaleMask','f30b397def',259,150),
(40,1776948036,1776948036,1,11,'/_processed_/1/f/csm_konolfingen-familie_14e1cfed16.jpg','csm_konolfingen-familie_14e1cfed16.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','7efa14c9e93af361a4640bd3581f0305902a93bf','Image.CropScaleMask','14e1cfed16',78,45),
(41,1776948038,1776948038,1,11,'/_processed_/1/f/csm_konolfingen-familie_ff1ad8a419.jpg','csm_konolfingen-familie_ff1ad8a419.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','7efa14c9e93af361a4640bd3581f0305902a93bf','Image.CropScaleMask','ff1ad8a419',1920,1280),
(42,1776948038,1776948038,1,11,'/_processed_/1/f/csm_konolfingen-familie_4ec31c58dd.jpg','csm_konolfingen-familie_4ec31c58dd.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"800c\";s:6:\"height\";s:5:\"1200c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','f53552173bad8f51a3c183963d5077c61353bdca','7efa14c9e93af361a4640bd3581f0305902a93bf','Image.CropScaleMask','4ec31c58dd',800,1200),
(43,1776948176,1776948176,1,12,'/_processed_/7/7/csm_konolfingen-hund_a512777fe3.jpg','csm_konolfingen-hund_a512777fe3.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','9fcf566c1f3994c3e7bde8aa875a3b22a0630f4a','Image.CropScaleMask','a512777fe3',100,115),
(44,1776948178,1776948177,1,12,'/_processed_/7/7/csm_konolfingen-hund_5a6cff0d2b.jpg','csm_konolfingen-hund_5a6cff0d2b.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','9fcf566c1f3994c3e7bde8aa875a3b22a0630f4a','Image.CropScaleMask','5a6cff0d2b',130,150),
(45,1776948177,1776948177,1,12,'/_processed_/7/7/csm_konolfingen-hund_18b707e033.jpg','csm_konolfingen-hund_18b707e033.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','9fcf566c1f3994c3e7bde8aa875a3b22a0630f4a','Image.CropScaleMask','18b707e033',39,45),
(46,1776948190,1776948190,1,12,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','9fcf566c1f3994c3e7bde8aa875a3b22a0630f4a','Image.CropScaleMask','947aba453a',0,0),
(47,1776952011,1776952011,1,13,'/_processed_/5/c/csm_frau-wohnt-in-konolfingen_576df67521.jpg','csm_frau-wohnt-in-konolfingen_576df67521.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','47a6631b5d05ba603a5b9ef5633e3278d47652d5','Image.CropScaleMask','576df67521',100,115),
(48,1776952013,1776952012,1,13,'/_processed_/5/c/csm_frau-wohnt-in-konolfingen_5a8ec3dfa6.jpg','csm_frau-wohnt-in-konolfingen_5a8ec3dfa6.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','47a6631b5d05ba603a5b9ef5633e3278d47652d5','Image.CropScaleMask','5a8ec3dfa6',130,150),
(49,1776952012,1776952012,1,13,'/_processed_/5/c/csm_frau-wohnt-in-konolfingen_97ac783345.jpg','csm_frau-wohnt-in-konolfingen_97ac783345.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','47a6631b5d05ba603a5b9ef5633e3278d47652d5','Image.CropScaleMask','97ac783345',39,45),
(50,1776952060,1776952060,1,13,'/_processed_/5/c/csm_frau-wohnt-in-konolfingen_82b45292e2.jpg','csm_frau-wohnt-in-konolfingen_82b45292e2.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1400c\";s:6:\"height\";s:5:\"1400c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','925ffcbbb9aa466b1b1e0aa3fe53b5eb5a476cb8','47a6631b5d05ba603a5b9ef5633e3278d47652d5','Image.CropScaleMask','82b45292e2',1400,1400),
(51,1776952871,1776952871,1,14,'/_processed_/b/c/csm_dominique-waser_54fab0051a.jpg','csm_dominique-waser_54fab0051a.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','54fab0051a',100,115),
(52,1776952873,1776952872,1,14,'/_processed_/b/c/csm_dominique-waser_526ce0d8d8.jpg','csm_dominique-waser_526ce0d8d8.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','526ce0d8d8',130,150),
(53,1776952872,1776952872,1,14,'/_processed_/b/c/csm_dominique-waser_f44206dac1.jpg','csm_dominique-waser_f44206dac1.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','f44206dac1',39,45),
(54,1776952885,1776952885,1,14,'/_processed_/b/c/csm_dominique-waser_39daee422f.jpg','csm_dominique-waser_39daee422f.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1400c\";s:6:\"height\";s:5:\"1400c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','925ffcbbb9aa466b1b1e0aa3fe53b5eb5a476cb8','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','39daee422f',1400,1400),
(55,1776953206,1776953206,1,14,'/_processed_/b/c/csm_dominique-waser_2d7469ad23.jpg','csm_dominique-waser_2d7469ad23.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:5:\"1400c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','77cbd8cd75504ab99af74d3cb900c6c92b2809fc','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','2d7469ad23',1600,1400),
(56,1776953433,1776953433,1,14,'/_processed_/b/c/csm_dominique-waser_815c415188.jpg','csm_dominique-waser_815c415188.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1600c\";s:6:\"height\";s:5:\"1200c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','925dd21e60f4b4027a71f7e46ddf445484b80414','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','815c415188',1600,1200),
(57,1776953446,1776953446,1,14,'/_processed_/b/c/csm_dominique-waser_23f5cae83f.jpg','csm_dominique-waser_23f5cae83f.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1100c\";s:6:\"height\";s:5:\"1600c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','6ec2d29579b2b3b9d4049231e0ea5a412079e55b','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','23f5cae83f',1100,1600),
(58,1776953451,1776953451,1,14,'/_processed_/b/c/csm_dominique-waser_67aa5fc9cb.jpg','csm_dominique-waser_67aa5fc9cb.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"900c\";s:6:\"height\";s:5:\"1600c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','1900f1340e1a9686dffe6c53db377e9d3a1a4aa3','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','67aa5fc9cb',900,1600),
(59,1776953457,1776953457,1,14,'/_processed_/b/c/csm_dominique-waser_22522a7ac0.jpg','csm_dominique-waser_22522a7ac0.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1200c\";s:6:\"height\";s:5:\"1600c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','3311e843a89ef59ad2e4d4a830cd2442e4b678e1','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','22522a7ac0',1200,1600),
(60,1776953471,1776953471,1,14,'/_processed_/b/c/csm_dominique-waser_fc13aefb0e.jpg','csm_dominique-waser_fc13aefb0e.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1200c\";s:6:\"height\";s:5:\"1800c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','19bdbdfdd644ca663fa555609b1a7c553fb699fd','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','fc13aefb0e',1200,1800),
(61,1776954729,1776954729,1,11,'/_processed_/1/f/csm_konolfingen-familie_161066d067.jpg','csm_konolfingen-familie_161066d067.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','7efa14c9e93af361a4640bd3581f0305902a93bf','Image.CropScaleMask','161066d067',166,96),
(62,1776954738,1776954738,1,15,'/_processed_/e/6/csm_kon2_b70167843f.jpg','csm_kon2_b70167843f.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','c4a899600c2d56d36a66a70942fb49c4ad303ceb','Image.CropScaleMask','b70167843f',166,96),
(63,1776954739,1776954739,1,15,'/_processed_/e/6/csm_kon2_1aba3df4f5.jpg','csm_kon2_1aba3df4f5.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','c4a899600c2d56d36a66a70942fb49c4ad303ceb','Image.CropScaleMask','1aba3df4f5',259,150),
(64,1776954739,1776954739,1,15,'/_processed_/e/6/csm_kon2_34218a875d.jpg','csm_kon2_34218a875d.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','c4a899600c2d56d36a66a70942fb49c4ad303ceb','Image.CropScaleMask','34218a875d',78,45),
(65,1776954752,1776954752,1,15,'/_processed_/e/6/csm_kon2_daa3d687e6.jpg','csm_kon2_daa3d687e6.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','c4a899600c2d56d36a66a70942fb49c4ad303ceb','Image.CropScaleMask','daa3d687e6',1920,1280),
(66,1776954752,1776954752,1,15,'/_processed_/e/6/csm_kon2_edd787246b.jpg','csm_kon2_edd787246b.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"800c\";s:6:\"height\";s:5:\"1200c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','f53552173bad8f51a3c183963d5077c61353bdca','c4a899600c2d56d36a66a70942fb49c4ad303ceb','Image.CropScaleMask','edd787246b',800,1200),
(67,1776955670,1776955670,1,11,'/_processed_/1/f/csm_konolfingen-familie_86dc89ad28.jpg','csm_konolfingen-familie_86dc89ad28.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','7efa14c9e93af361a4640bd3581f0305902a93bf','Image.CropScaleMask','86dc89ad28',1920,1080),
(68,1776955670,1776955670,1,15,'/_processed_/e/6/csm_kon2_adc65d0f50.jpg','csm_kon2_adc65d0f50.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','c4a899600c2d56d36a66a70942fb49c4ad303ceb','Image.CropScaleMask','adc65d0f50',1920,1080),
(69,1776955938,1776955937,1,16,'/_processed_/1/3/csm_kind-wohnt-in-konolfingen_387f2563a5.jpg','csm_kind-wohnt-in-konolfingen_387f2563a5.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','e477f2909d801bbbd31e3acfbc51e6b518508878','Image.CropScaleMask','387f2563a5',100,115),
(70,1776955939,1776955939,1,16,'/_processed_/1/3/csm_kind-wohnt-in-konolfingen_63ccece381.jpg','csm_kind-wohnt-in-konolfingen_63ccece381.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e477f2909d801bbbd31e3acfbc51e6b518508878','Image.CropScaleMask','63ccece381',130,150),
(71,1776955939,1776955939,1,16,'/_processed_/1/3/csm_kind-wohnt-in-konolfingen_9c0535bd69.jpg','csm_kind-wohnt-in-konolfingen_9c0535bd69.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','e477f2909d801bbbd31e3acfbc51e6b518508878','Image.CropScaleMask','9c0535bd69',39,45),
(72,1776955989,1776955989,1,16,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','e477f2909d801bbbd31e3acfbc51e6b518508878','Image.CropScaleMask','f6c504bffa',0,0),
(73,1777013998,1776952871,1,14,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','7b9ac90ddc6af81a5b1d3e8977c28b3059114713','Image.CropScaleMask','b673cdcbb4',1507,1740),
(74,1777014155,1777014155,1,17,'/_processed_/2/1/csm_blumen-wohnung-in-konolfingen_518d4db898.jpg','csm_blumen-wohnung-in-konolfingen_518d4db898.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','b0df6fd2c44e6c04e008a95b75e4736a812c7478','Image.CropScaleMask','518d4db898',100,115),
(75,1777021801,1777014156,1,17,'/_processed_/2/1/csm_blumen-wohnung-in-konolfingen_87c883884e.jpg','csm_blumen-wohnung-in-konolfingen_87c883884e.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','b0df6fd2c44e6c04e008a95b75e4736a812c7478','Image.CropScaleMask','87c883884e',130,150),
(76,1777014156,1777014156,1,17,'/_processed_/2/1/csm_blumen-wohnung-in-konolfingen_542dba23a3.jpg','csm_blumen-wohnung-in-konolfingen_542dba23a3.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','b0df6fd2c44e6c04e008a95b75e4736a812c7478','Image.CropScaleMask','542dba23a3',39,45),
(77,1777014212,1777014212,1,17,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','b0df6fd2c44e6c04e008a95b75e4736a812c7478','Image.CropScaleMask','94fd315f70',0,0),
(78,1777014904,1776952011,1,13,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','47a6631b5d05ba603a5b9ef5633e3278d47652d5','Image.CropScaleMask','897112146d',1507,1740),
(79,1777018483,1777018482,1,18,'/_processed_/0/b/csm_konol1_cdb55993e8.jpg','csm_konol1_cdb55993e8.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','8ca116667842171ff228055fdc3a9032f7a7a6b3','Image.CropScaleMask','cdb55993e8',100,115),
(80,1777018483,1777018482,1,19,'/_processed_/2/e/csm_wohnen-konolfingen-1_f7206b5568.jpg','csm_wohnen-konolfingen-1_f7206b5568.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','12ac1b35b22ba01091c914253e5b1239187b6f0a','Image.CropScaleMask','f7206b5568',100,115),
(81,1777018483,1777018482,1,20,'/_processed_/8/4/csm_wohnen-konolfingen-2_a071496b90.jpg','csm_wohnen-konolfingen-2_a071496b90.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e','Image.CropScaleMask','a071496b90',100,115),
(82,1777018490,1777018488,1,18,'/_processed_/0/b/csm_konol1_330a348ebf.jpg','csm_konol1_330a348ebf.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','8ca116667842171ff228055fdc3a9032f7a7a6b3','Image.CropScaleMask','330a348ebf',130,150),
(83,1777018488,1777018488,1,18,'/_processed_/0/b/csm_konol1_9863ea4b30.jpg','csm_konol1_9863ea4b30.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','8ca116667842171ff228055fdc3a9032f7a7a6b3','Image.CropScaleMask','9863ea4b30',39,45),
(84,1777019441,1777018488,1,19,'/_processed_/2/e/csm_wohnen-konolfingen-1_3be24e98ca.jpg','csm_wohnen-konolfingen-1_3be24e98ca.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','12ac1b35b22ba01091c914253e5b1239187b6f0a','Image.CropScaleMask','3be24e98ca',130,150),
(85,1777019441,1777018488,1,19,'/_processed_/2/e/csm_wohnen-konolfingen-1_8b61c31991.jpg','csm_wohnen-konolfingen-1_8b61c31991.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','12ac1b35b22ba01091c914253e5b1239187b6f0a','Image.CropScaleMask','8b61c31991',39,45),
(86,1777019440,1777018488,1,20,'/_processed_/8/4/csm_wohnen-konolfingen-2_23a5c04306.jpg','csm_wohnen-konolfingen-2_23a5c04306.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e','Image.CropScaleMask','23a5c04306',130,150),
(87,1777019442,1777018488,1,20,'/_processed_/8/4/csm_wohnen-konolfingen-2_4c5cbaccb4.jpg','csm_wohnen-konolfingen-2_4c5cbaccb4.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e','Image.CropScaleMask','4c5cbaccb4',39,45),
(88,1777018491,1777018491,1,18,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','8ca116667842171ff228055fdc3a9032f7a7a6b3','Image.CropScaleMask','ac0d98ca92',0,0),
(89,1777018740,1777018740,1,19,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','12ac1b35b22ba01091c914253e5b1239187b6f0a','Image.CropScaleMask','8d6ca010d3',0,0),
(90,1777018740,1777018740,1,20,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','9bb4b376c7a0421ce468efe6ddc5a9c6bd412d4e','Image.CropScaleMask','898692f966',0,0),
(91,1777019433,1777019433,1,21,'/_processed_/4/e/csm_man-velo_1be7302a16.jpg','csm_man-velo_1be7302a16.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','e8109478cd6ecfddaac7cee64821f744110c19ca','Image.CropScaleMask','1be7302a16',154,115),
(92,1777019440,1777019440,1,21,'/_processed_/4/e/csm_man-velo_c5731c9e93.jpg','csm_man-velo_c5731c9e93.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e8109478cd6ecfddaac7cee64821f744110c19ca','Image.CropScaleMask','c5731c9e93',202,150),
(93,1777019440,1777019440,1,21,'/_processed_/4/e/csm_man-velo_a813051a22.jpg','csm_man-velo_a813051a22.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','e8109478cd6ecfddaac7cee64821f744110c19ca','Image.CropScaleMask','a813051a22',60,45),
(94,1777019449,1777019449,1,21,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','e8109478cd6ecfddaac7cee64821f744110c19ca','Image.CropScaleMask','119c5a3832',0,0),
(95,1777019756,1777019755,1,22,'/_processed_/9/4/csm_gleitsicht_hero_small_desktop_69dccc6f3c.png','csm_gleitsicht_hero_small_desktop_69dccc6f3c.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','6837242d3605b73f64d168b06cc5496db594009c','Image.CropScaleMask','69dccc6f3c',166,93),
(96,1777019768,1777019768,1,23,'/_processed_/b/a/csm_konolfingen-234_1f3cc7a57b.jpg','csm_konolfingen-234_1f3cc7a57b.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','e3d7315c7d2438a97456c9ba0dfdcec3ad2f3b9a','Image.CropScaleMask','1f3cc7a57b',166,96),
(97,1777019773,1777019772,1,22,'/_processed_/9/4/csm_gleitsicht_hero_small_desktop_2d4d527f96.png','csm_gleitsicht_hero_small_desktop_2d4d527f96.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','6837242d3605b73f64d168b06cc5496db594009c','Image.CropScaleMask','2d4d527f96',267,150),
(98,1777019773,1777019772,1,22,'/_processed_/9/4/csm_gleitsicht_hero_small_desktop_82385b62d1.png','csm_gleitsicht_hero_small_desktop_82385b62d1.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','6837242d3605b73f64d168b06cc5496db594009c','Image.CropScaleMask','82385b62d1',80,45),
(99,1777019772,1777019772,1,23,'/_processed_/b/a/csm_konolfingen-234_26ba439b85.jpg','csm_konolfingen-234_26ba439b85.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','e3d7315c7d2438a97456c9ba0dfdcec3ad2f3b9a','Image.CropScaleMask','26ba439b85',259,150),
(100,1777019774,1777019772,1,23,'/_processed_/b/a/csm_konolfingen-234_04da98ae8e.jpg','csm_konolfingen-234_04da98ae8e.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','e3d7315c7d2438a97456c9ba0dfdcec3ad2f3b9a','Image.CropScaleMask','04da98ae8e',78,45),
(101,1777019776,1777019776,1,22,'/_processed_/9/4/csm_gleitsicht_hero_small_desktop_9d36cbc5b1.png','csm_gleitsicht_hero_small_desktop_9d36cbc5b1.png',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','6837242d3605b73f64d168b06cc5496db594009c','Image.CropScaleMask','9d36cbc5b1',1920,1080),
(102,1777019776,1777019776,1,23,'/_processed_/b/a/csm_konolfingen-234_a5b95b4acb.jpg','csm_konolfingen-234_a5b95b4acb.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','e3d7315c7d2438a97456c9ba0dfdcec3ad2f3b9a','Image.CropScaleMask','a5b95b4acb',1920,1080),
(103,1777019776,1777019776,1,22,'/_processed_/9/4/csm_gleitsicht_hero_small_desktop_8cdc21ec92.png','csm_gleitsicht_hero_small_desktop_8cdc21ec92.png',NULL,'a:7:{s:5:\"width\";s:4:\"800c\";s:6:\"height\";s:5:\"1200c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','f53552173bad8f51a3c183963d5077c61353bdca','6837242d3605b73f64d168b06cc5496db594009c','Image.CropScaleMask','8cdc21ec92',800,1200),
(104,1777019776,1777019776,1,23,'/_processed_/b/a/csm_konolfingen-234_38fe691fb2.jpg','csm_konolfingen-234_38fe691fb2.jpg',NULL,'a:7:{s:5:\"width\";s:4:\"800c\";s:6:\"height\";s:5:\"1200c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','f53552173bad8f51a3c183963d5077c61353bdca','e3d7315c7d2438a97456c9ba0dfdcec3ad2f3b9a','Image.CropScaleMask','38fe691fb2',800,1200),
(105,1777019786,1777019784,1,22,'/_processed_/9/4/csm_gleitsicht_hero_small_desktop_f80afb5110.png','csm_gleitsicht_hero_small_desktop_f80afb5110.png','','a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','6837242d3605b73f64d168b06cc5496db594009c','Image.CropScaleMask','f80afb5110',1920,1280),
(106,1777019784,1777019784,1,23,'/_processed_/b/a/csm_konolfingen-234_2bcc2617b7.jpg','csm_konolfingen-234_2bcc2617b7.jpg','','a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1280c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','c85056709b36a5dba556244a70b46d10e87d1d03','e3d7315c7d2438a97456c9ba0dfdcec3ad2f3b9a','Image.CropScaleMask','2bcc2617b7',1920,1280),
(107,1777020542,1777020542,1,8,'/_processed_/6/3/csm_wohnung-konolfingen_78c03af95a.jpg','csm_wohnung-konolfingen_78c03af95a.jpg',NULL,'a:7:{s:5:\"width\";s:5:\"1920c\";s:6:\"height\";s:5:\"1080c\";s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','b5f8a0d9965982e5c525fdbd5a94e7cab4ce7f2d','ff446f94f456d638c4dfca3e569b25c1cb419bd8','Image.CropScaleMask','78c03af95a',1920,1080),
(108,1777021060,1777021060,1,24,'/_processed_/e/4/csm_keller-konolfingen_0dee82d840.jpg','csm_keller-konolfingen_0dee82d840.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','4279379ad4a1a2fa5d5d5fa36cb8052dc4b7d415','Image.CropScaleMask','0dee82d840',123,115),
(109,1777029438,1777021061,1,24,'/_processed_/e/4/csm_keller-konolfingen_2e592a75c0.jpg','csm_keller-konolfingen_2e592a75c0.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','4279379ad4a1a2fa5d5d5fa36cb8052dc4b7d415','Image.CropScaleMask','2e592a75c0',161,150),
(110,1777021061,1777021061,1,24,'/_processed_/e/4/csm_keller-konolfingen_106ca0044a.jpg','csm_keller-konolfingen_106ca0044a.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','4279379ad4a1a2fa5d5d5fa36cb8052dc4b7d415','Image.CropScaleMask','106ca0044a',48,45),
(111,1777021072,1777021072,1,24,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','4279379ad4a1a2fa5d5d5fa36cb8052dc4b7d415','Image.CropScaleMask','831319cb99',0,0),
(112,1777021854,1777021854,1,25,'/_processed_/b/1/csm_blumen-wohnung-in-konolfingen-2_61a11690d4.jpg','csm_blumen-wohnung-in-konolfingen-2_61a11690d4.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','028ab61ad015961dca2391c37fff8bd43fa49108','Image.CropScaleMask','61a11690d4',100,115),
(113,1777021855,1777021855,1,25,'/_processed_/b/1/csm_blumen-wohnung-in-konolfingen-2_b97d4db2ff.jpg','csm_blumen-wohnung-in-konolfingen-2_b97d4db2ff.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','028ab61ad015961dca2391c37fff8bd43fa49108','Image.CropScaleMask','b97d4db2ff',130,150),
(114,1777021855,1777021855,1,25,'/_processed_/b/1/csm_blumen-wohnung-in-konolfingen-2_b51c3cd92b.jpg','csm_blumen-wohnung-in-konolfingen-2_b51c3cd92b.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','028ab61ad015961dca2391c37fff8bd43fa49108','Image.CropScaleMask','b51c3cd92b',39,45),
(115,1777021857,1777021857,1,25,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','028ab61ad015961dca2391c37fff8bd43fa49108','Image.CropScaleMask','bf5a2da3ac',0,0),
(116,1777121585,1777121585,1,26,'/_processed_/1/3/csm_blank_e4925eaaa0.png','csm_blank_e4925eaaa0.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','3dad168e79bc7f421760c98a8b6be2e1630a63ec','Image.CropScaleMask','e4925eaaa0',89,115),
(117,1777121587,1777121586,1,26,'/_processed_/1/3/csm_blank_3b5c1aa5bf.png','csm_blank_3b5c1aa5bf.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','3dad168e79bc7f421760c98a8b6be2e1630a63ec','Image.CropScaleMask','3b5c1aa5bf',116,150),
(118,1777121586,1777121586,1,26,'/_processed_/1/3/csm_blank_6aed5070c6.png','csm_blank_6aed5070c6.png','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','3dad168e79bc7f421760c98a8b6be2e1630a63ec','Image.CropScaleMask','6aed5070c6',35,45);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,2,1776866736,1776866725,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,1,NULL,'Grünegg Konolfingen',2,'pages','media',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(2,0,1776939322,1776939322,0,0,0,0,NULL,'',0,0,0,0,5,NULL,NULL,2,'be_users','avatar',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(3,2,1776947735,1776945701,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,6,NULL,'wohnung konolfingen',1,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(4,2,1776947735,1776945701,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,7,NULL,'wohnung konolfingen',1,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(5,2,1776947519,1776947519,0,0,0,0,NULL,'',0,0,0,0,8,NULL,'konolfingen',2,'tt_content','tx_mask_simple_image_class',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(6,2,1776947924,1776947889,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,6,NULL,'wohnung konolfingen',3,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(7,2,1776947924,1776947889,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,7,NULL,'wohnung konolfingen',3,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(8,2,1776947924,1776947924,0,0,0,0,NULL,'',0,0,0,0,9,NULL,'konolfingen haus',3,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(9,2,1776947924,1776947924,0,0,0,0,NULL,'',0,0,0,0,9,NULL,NULL,3,'tt_content','tx_mask_image_first_column',2,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(10,2,1776947924,1776947924,0,0,0,0,NULL,'',0,0,0,0,10,NULL,'konolfingen haus',3,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(11,2,1776948038,1776948027,1,0,0,0,NULL,'',0,0,0,0,8,NULL,'konolfingen',4,'tt_content','tx_mask_simple_image_class',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(12,2,1776948038,1776948038,0,0,0,0,NULL,'',0,0,0,0,11,NULL,NULL,4,'tt_content','tx_mask_simple_image_class',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(13,2,1776948204,1776948189,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,12,NULL,'konolfingen hund familie',5,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(14,2,1776953671,1776952060,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,13,NULL,'frau konolfingen',9,'tt_content','tx_mask_add_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(15,2,1776954054,1776952884,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,14,NULL,'Dominique Andreas Waser',10,'tt_content','tx_mask_add_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(16,3,1776954935,1776954685,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,11,NULL,NULL,11,'tt_content','tx_mask_simple_image_class',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(17,3,1776954935,1776954747,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,15,NULL,'konolfingen',11,'tt_content','tx_mask_simple_image_class',2,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(18,4,1776955987,1776955864,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,12,NULL,'konolfingen hund familie',13,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(19,4,1776955987,1776955955,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,16,NULL,'Kind Spaziergang',13,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(20,5,1777021694,1776956137,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,14,NULL,'Dominique Andreas Waser',15,'tt_content','tx_mask_add_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(21,5,1777021808,1777014210,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,17,NULL,'wohnung blumen konolfingen',16,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(22,10,1777015006,1777014917,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,14,NULL,'Dominique Andreas Waser',19,'tt_content','tx_mask_add_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(23,10,1777015065,1777015013,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,14,NULL,'Dominique Andreas Waser',20,'tt_content','tx_mask_add_image',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(24,4,1777018490,1777018374,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,12,NULL,'konolfingen hund familie',21,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(25,4,1777018490,1777018490,0,0,0,0,NULL,'',0,0,0,0,18,NULL,NULL,21,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(26,4,1777018490,1777018490,0,0,0,0,NULL,'',0,0,0,0,19,NULL,NULL,21,'tt_content','tx_mask_image_second_column',2,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(27,4,1777018490,1777018490,0,0,0,0,NULL,'',0,0,0,0,20,NULL,NULL,21,'tt_content','tx_mask_image_second_column',3,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(28,4,1777019554,1777019445,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,21,NULL,NULL,22,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(29,4,1777019554,1777019445,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,19,NULL,NULL,22,'tt_content','tx_mask_image_first_column',2,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(30,4,1777019554,1777019445,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,20,NULL,NULL,22,'tt_content','tx_mask_image_first_column',3,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(31,4,1777019783,1777019775,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,22,NULL,NULL,23,'tt_content','tx_mask_simple_image_class',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(32,4,1777019783,1777019775,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,23,NULL,NULL,23,'tt_content','tx_mask_simple_image_class',2,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(33,3,1777020490,1777020490,0,0,0,0,NULL,'',0,0,0,0,8,NULL,NULL,26,'tt_content','tx_mask_simple_image_class',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(34,3,1777021071,1777020957,1,0,0,0,NULL,'',0,0,0,0,18,NULL,NULL,28,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(35,3,1777021071,1777020957,1,0,0,0,NULL,'',0,0,0,0,19,NULL,NULL,28,'tt_content','tx_mask_image_second_column',2,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(36,3,1777021071,1777020957,1,0,0,0,NULL,'',0,0,0,0,20,NULL,NULL,28,'tt_content','tx_mask_image_second_column',3,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(37,3,1777021078,1777021071,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,24,NULL,NULL,28,'tt_content','tx_mask_image_second_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(38,5,1777021856,1777021808,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,17,NULL,'Konoflingen',16,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(39,5,1777021856,1777021856,0,0,0,0,NULL,'',0,0,0,0,25,NULL,NULL,16,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(40,2,1777029973,1777029480,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,24,NULL,NULL,30,'tt_content','tx_mask_image_first_column',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(41,3,1777121648,1777121599,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,26,NULL,NULL,1,'tx_mask_apartments','tx_mask_pdf',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(42,3,1777121648,1777121648,0,0,0,0,NULL,'',0,0,0,0,26,NULL,NULL,2,'tx_mask_apartments','tx_mask_pdf',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(43,3,1777121695,1777121695,0,0,0,0,NULL,'',0,0,0,0,26,NULL,NULL,3,'tx_mask_apartments','tx_mask_pdf',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(44,3,1777121736,1777121695,0,0,0,0,NULL,'{\"alternative\":\"\",\"crop\":\"\",\"description\":\"\",\"hidden\":\"\",\"link\":\"\",\"title\":\"\",\"uid_local\":\"\"}',0,0,0,0,26,NULL,NULL,4,'tx_mask_apartments','tx_mask_pdf',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(45,3,1777121736,1777121736,0,0,0,0,NULL,'',0,0,0,0,26,NULL,NULL,5,'tx_mask_apartments','tx_mask_pdf',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(46,3,1777266972,1777121736,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,26,NULL,NULL,6,'tx_mask_apartments','tx_mask_pdf',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0),
(47,3,1777266972,1777266972,0,0,0,0,NULL,'',0,0,0,0,26,NULL,NULL,7,'tx_mask_apartments','tx_mask_pdf',1,'',NULL,'{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1776865663,1776865663,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1776865609,1,'BE',1,0,1,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":0,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Gr\\u00fcnegg\",\"crdate\":1776865609,\"t3ver_stage\":0,\"tstamp\":1776865609,\"uid\":1}',0,'0400$61470953265540e683ecfbecc2c02b87:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1776865609,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"}}',0,'0400$5786077edf0797669ad1895ca2337edc:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1776865629,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":0,\"sorting\":128,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Gr\\u00fcnegg Webseite\",\"crdate\":1776865629,\"t3ver_stage\":0,\"tstamp\":1776865629,\"uid\":2}',0,'0400$8426b3799915b8333da52d12c92642ed:f11830df10b4b0bca2db34810c2241b3'),
(4,1776865629,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"}}',0,'0400$23024a9d96eb86c5b9759bfd95c69ba0:f11830df10b4b0bca2db34810c2241b3'),
(5,1776865633,4,'BE',1,0,1,'pages',NULL,0,'0400$8c346f9e00928a54be49d002617d82a9:e175f7045d7ccbfb26ffcf279422c2e5'),
(6,1776865661,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$f16226189512190590099c6e17777e92:f11830df10b4b0bca2db34810c2241b3'),
(7,1776865692,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"is_siteroot\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"backend_layout\":\"pagets__default\",\"backend_layout_next_level\":\"pagets__default\",\"is_siteroot\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"TSconfig\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\"}\"}}',0,'0400$6b4b86ce95469138d32aca6b94db6c50:f11830df10b4b0bca2db34810c2241b3'),
(8,1776866725,1,'BE',1,0,1,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Gr\\u00fcnegg Konolfingen\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"1\",\"sys_language_uid\":0,\"crdate\":1776866725,\"t3ver_stage\":0,\"tstamp\":1776866725,\"uid\":1}',0,'0400$733aa843b608829f068124b3237ab030:4cf496f597e7b095ce8b755e6cec3c0c'),
(9,1776866736,2,'BE',1,0,1,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$15ae8e5ba6f261403114ba7d78d5df53:4cf496f597e7b095ce8b755e6cec3c0c'),
(10,1776925472,1,'BE',1,0,3,'pages','{\"doktype\":\"1\",\"slug\":\"\\/wohnen\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Wohnen\",\"sys_language_uid\":0,\"crdate\":1776925472,\"t3ver_stage\":0,\"tstamp\":1776925472,\"uid\":3}',0,'0400$967052de56a6c52c18e601580ede6f31:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(11,1776925481,1,'BE',1,0,4,'pages','{\"doktype\":\"1\",\"slug\":\"\\/umgebung\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":512,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Umgebung\",\"sys_language_uid\":0,\"crdate\":1776925481,\"t3ver_stage\":0,\"tstamp\":1776925481,\"uid\":4}',0,'0400$26bade05f690d2b4ca17332a392a98c2:412add0b3eb6ec8f1cb6710aea92e21e'),
(12,1776925487,1,'BE',1,0,5,'pages','{\"doktype\":\"1\",\"slug\":\"\\/kontakt\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":768,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Kontakt\",\"sys_language_uid\":0,\"crdate\":1776925487,\"t3ver_stage\":0,\"tstamp\":1776925487,\"uid\":5}',0,'0400$d831f7d8a8a5152c7ea3540dc471f4bd:7ef5a4e3e11db8ac3fea4d7a75468161'),
(13,1776925491,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$34fc9ceb749c6d0bfebb6db4473c0c62:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(14,1776925495,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$05e27f282c3760ad855cf6b7e1bb44ee:412add0b3eb6ec8f1cb6710aea92e21e'),
(15,1776925497,2,'BE',1,0,5,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$1b7772c993b0920b0f809985b3274b81:7ef5a4e3e11db8ac3fea4d7a75468161'),
(16,1776927029,1,'BE',1,0,6,'pages','{\"doktype\":\"1\",\"slug\":\"\\/404\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":1024,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"404\",\"sys_language_uid\":0,\"crdate\":1776927029,\"t3ver_stage\":0,\"tstamp\":1776927029,\"uid\":6}',0,'0400$2da4d1353035b8e437d67cca86765239:c75354c439a48dbde16b03ac553a080d'),
(17,1776927032,2,'BE',1,0,6,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$2a68ea9def4f43c887f3aba731ccc691:c75354c439a48dbde16b03ac553a080d'),
(18,1776929184,2,'BE',1,0,6,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$0e8cfa4f463feaabc238ad320c6bcbbd:c75354c439a48dbde16b03ac553a080d'),
(19,1776930027,1,'BE',1,0,7,'pages','{\"doktype\":\"1\",\"slug\":\"\\/datenschutz\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":1280,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Datenschutz\",\"sys_language_uid\":0,\"crdate\":1776930027,\"t3ver_stage\":0,\"tstamp\":1776930027,\"uid\":7}',0,'0400$7647283b0730b5827f11f1d76d492a43:df50bb24cbce671cf0d61f42fbbef601'),
(20,1776930035,1,'BE',1,0,8,'pages','{\"doktype\":\"1\",\"slug\":\"\\/impressum\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":1536,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Impressum\",\"sys_language_uid\":0,\"crdate\":1776930035,\"t3ver_stage\":0,\"tstamp\":1776930035,\"uid\":8}',0,'0400$9eb92310ae93cc718c7019ca76b9c62a:595375f2fb9f014e091eb08fbc51ec88'),
(21,1776930068,2,'BE',1,0,7,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$77f57f4308565a4f69028091708bdf31:df50bb24cbce671cf0d61f42fbbef601'),
(22,1776930071,2,'BE',1,0,7,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$b0b070f6a30fecf63fd9b1e9414cf798:df50bb24cbce671cf0d61f42fbbef601'),
(23,1776930074,2,'BE',1,0,8,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$917149057e214a7c47eae26bf82cebab:595375f2fb9f014e091eb08fbc51ec88'),
(24,1776930076,2,'BE',1,0,8,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$acc37e47d95586e7db737bfd81b071a4:595375f2fb9f014e091eb08fbc51ec88'),
(25,1776939260,4,'BE',2,0,1,'be_users',NULL,0,'0400$6515eed5dd68e67a724fa524fd52cd79:084907bc914ff27cf2301aec50eb66b2'),
(26,1776939266,2,'BE',2,0,2,'be_users','{\"oldRecord\":{\"username\":\"studio_gg_2\"},\"newRecord\":{\"username\":\"studio_gg\"}}',0,'0400$4c0dac50e167ff8fcb9a32bc18126225:c98a59192960d7c1b8e415cda9ffe933'),
(27,1776939322,1,'BE',2,0,2,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":0,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"5\",\"sys_language_uid\":0,\"crdate\":1776939322,\"t3ver_stage\":0,\"tstamp\":1776939322,\"uid\":2}',0,'0400$e7bb3b3a81c5c0b7a2898517e9697ed4:814fc0f720dfab882655a795e23a5b66'),
(28,1776945701,1,'BE',2,0,1,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":256,\"sys_language_uid\":0,\"tx_mask_text_first_col\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_color_second_column\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776945701,\"t3ver_stage\":0,\"tstamp\":1776945701,\"uid\":1}',0,'0400$22a5cc84ca476f33302ddc67390044c4:7fa2c035f26826fe83eeecaaeddc4d40'),
(29,1776945701,1,'BE',2,0,3,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"wohnung konolfingen\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"6\",\"sys_language_uid\":0,\"crdate\":1776945701,\"t3ver_stage\":0,\"tstamp\":1776945701,\"uid\":3}',0,'0400$22a5cc84ca476f33302ddc67390044c4:d2c609347a4764200256b39b9425159a'),
(30,1776945701,1,'BE',2,0,4,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"wohnung konolfingen\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"7\",\"sys_language_uid\":0,\"crdate\":1776945701,\"t3ver_stage\":0,\"tstamp\":1776945701,\"uid\":4}',0,'0400$22a5cc84ca476f33302ddc67390044c4:cea5fcd7b97871880cfe3717d6b52ef4'),
(31,1776945902,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\"}\"}}',0,'0400$b79e272c159097fab349253739d876a0:7fa2c035f26826fe83eeecaaeddc4d40'),
(32,1776945902,2,'BE',2,0,3,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$b79e272c159097fab349253739d876a0:d2c609347a4764200256b39b9425159a'),
(33,1776945902,2,'BE',2,0,4,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$b79e272c159097fab349253739d876a0:cea5fcd7b97871880cfe3717d6b52ef4'),
(34,1776945910,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\"},\"newRecord\":{\"tx_mask_text_first_col\":\"<p>Test<\\/p>\",\"tx_mask_text_second_column\":\"<p>Test<\\/p>\"}}',0,'0400$99ec75195d3f5e626cc89373b0f82b1e:7fa2c035f26826fe83eeecaaeddc4d40'),
(35,1776946378,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"0\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"1\"}}',0,'0400$ad70d76c48f58456c973197b920f5cb1:7fa2c035f26826fe83eeecaaeddc4d40'),
(36,1776946385,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"1\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"2\"}}',0,'0400$2a384fe1fe7329ed193ef716c7103cdf:7fa2c035f26826fe83eeecaaeddc4d40'),
(37,1776947221,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$d1d89fad95e15b69492d8b61d6ffb5cb:7fa2c035f26826fe83eeecaaeddc4d40'),
(38,1776947519,1,'BE',2,0,2,'tt_content','{\"CType\":\"mask_simple_image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":512,\"sys_language_uid\":0,\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776947519,\"t3ver_stage\":0,\"tstamp\":1776947519,\"uid\":2}',0,'0400$dcab5d3490ee8d66a21a17a3967811cc:01dbc21fdb1263685b9147b3b1596ea8'),
(39,1776947519,1,'BE',2,0,5,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"konolfingen\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"8\",\"sys_language_uid\":0,\"crdate\":1776947519,\"t3ver_stage\":0,\"tstamp\":1776947519,\"uid\":5}',0,'0400$dcab5d3490ee8d66a21a17a3967811cc:5f15a1453f67b933ed3314381f5d67e4'),
(40,1776947735,2,'BE',2,0,1,'tt_content','{\"oldRecord\":{\"tx_mask_text_first_col\":\"<p>Test<\\/p>\",\"tx_mask_text_second_column\":\"<p>Test<\\/p>\"},\"newRecord\":{\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\"}}',0,'0400$65d219ba8b912cf3db99e922612236cf:7fa2c035f26826fe83eeecaaeddc4d40'),
(41,1776947889,1,'BE',2,0,6,'sys_file_reference','{\"pid\":2,\"tstamp\":1776947889,\"crdate\":1776947889,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"6\",\"title\":null,\"alternative\":\"wohnung konolfingen\",\"uid_foreign\":1,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_image_first_column\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":6}',0,'0400$10a0359b489279e8909383fcfc8dddc9:768f9cd4e98812f969df7ebe17f11b50'),
(42,1776947889,1,'BE',2,0,7,'sys_file_reference','{\"pid\":2,\"tstamp\":1776947889,\"crdate\":1776947889,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"7\",\"title\":null,\"alternative\":\"wohnung konolfingen\",\"uid_foreign\":1,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_image_second_column\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":7}',0,'0400$10a0359b489279e8909383fcfc8dddc9:117c97010b9af15cb554d115dba4e316'),
(43,1776947889,1,'BE',2,0,3,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":768,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"2\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"crdate\":1776947889,\"t3ver_stage\":0,\"tstamp\":1776947889,\"uid\":3}',0,'0400$f9edfd179ed488a46c9477ae5cc11e1d:b92300cfb5d1d3645c9cb212a7f56c1f'),
(44,1776947889,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$de2fcc614eb310eee3be3b0340f02a70:b92300cfb5d1d3645c9cb212a7f56c1f'),
(45,1776947892,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$3529c3ab247193ae7b45d1ea18296f4d:b92300cfb5d1d3645c9cb212a7f56c1f'),
(46,1776947924,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$09bdda53ff398978e645175e2a19eebd:b92300cfb5d1d3645c9cb212a7f56c1f'),
(47,1776947924,1,'BE',2,0,8,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"konolfingen haus\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"9\",\"sys_language_uid\":0,\"crdate\":1776947924,\"t3ver_stage\":0,\"tstamp\":1776947924,\"uid\":8}',0,'0400$09bdda53ff398978e645175e2a19eebd:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(48,1776947924,1,'BE',2,0,9,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"9\",\"sys_language_uid\":0,\"crdate\":1776947924,\"t3ver_stage\":0,\"tstamp\":1776947924,\"uid\":9}',0,'0400$09bdda53ff398978e645175e2a19eebd:729356755eb8ee035abf6b9b02e20c8f'),
(49,1776947924,1,'BE',2,0,10,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"konolfingen haus\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"10\",\"sys_language_uid\":0,\"crdate\":1776947924,\"t3ver_stage\":0,\"tstamp\":1776947924,\"uid\":10}',0,'0400$09bdda53ff398978e645175e2a19eebd:b34a074e38840d41041eaee66c42bb0d'),
(50,1776947924,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$09bdda53ff398978e645175e2a19eebd:b92300cfb5d1d3645c9cb212a7f56c1f'),
(51,1776947924,2,'BE',2,0,3,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$09bdda53ff398978e645175e2a19eebd:b92300cfb5d1d3645c9cb212a7f56c1f'),
(52,1776947924,4,'BE',2,0,6,'sys_file_reference',NULL,0,'0400$09bdda53ff398978e645175e2a19eebd:768f9cd4e98812f969df7ebe17f11b50'),
(53,1776947924,4,'BE',2,0,7,'sys_file_reference',NULL,0,'0400$09bdda53ff398978e645175e2a19eebd:117c97010b9af15cb554d115dba4e316'),
(54,1776948027,1,'BE',2,0,11,'sys_file_reference','{\"pid\":2,\"tstamp\":1776948027,\"crdate\":1776948027,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"8\",\"title\":null,\"alternative\":\"konolfingen\",\"uid_foreign\":2,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_simple_image_class\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":11}',0,'0400$5e9d81af8c6b7057044d8e92772d8743:b70904b959c6d327947fc437df028f6f'),
(55,1776948027,1,'BE',2,0,4,'tt_content','{\"CType\":\"mask_simple_image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":1024,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":null,\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":null,\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"crdate\":1776948027,\"t3ver_stage\":0,\"tstamp\":1776948027,\"uid\":4}',0,'0400$21f8351d35fc15b86d0fe440464d9795:4d391f5ef79b8d5d10dffa8a07ca167d'),
(56,1776948027,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$7a322dedb329d1de969c82d2672d3ccb:4d391f5ef79b8d5d10dffa8a07ca167d'),
(57,1776948029,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$0b152aa4e5b83b4b46975c334a66e0b5:4d391f5ef79b8d5d10dffa8a07ca167d'),
(58,1776948038,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_simple_image_class\\\":\\\"\\\"}\"}}',0,'0400$4264e1e81cd1178c8a82c97c580e12f3:4d391f5ef79b8d5d10dffa8a07ca167d'),
(59,1776948038,1,'BE',2,0,12,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"11\",\"sys_language_uid\":0,\"crdate\":1776948038,\"t3ver_stage\":0,\"tstamp\":1776948038,\"uid\":12}',0,'0400$4264e1e81cd1178c8a82c97c580e12f3:fef2cecc4ff45c64d73fc27195ee5748'),
(60,1776948038,2,'BE',2,0,4,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_simple_image_class\\\":\\\"\\\"}\"}}',0,'0400$4264e1e81cd1178c8a82c97c580e12f3:4d391f5ef79b8d5d10dffa8a07ca167d'),
(61,1776948038,4,'BE',2,0,11,'sys_file_reference',NULL,0,'0400$4264e1e81cd1178c8a82c97c580e12f3:b70904b959c6d327947fc437df028f6f'),
(62,1776948189,1,'BE',2,0,5,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":640,\"sys_language_uid\":0,\"tx_mask_height_of_the_elemnet\":\"0\",\"tx_mask_text_first_col\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"tx_mask_text_white_first_col\":\"0\",\"tx_mask_color_first_column\":\"#F6F2EC\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_second_column\":\"0\",\"tx_mask_color_second_column\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776948189,\"t3ver_stage\":0,\"tstamp\":1776948189,\"uid\":5}',0,'0400$957f3842b64935614d322e3ede54a6a8:c7626fc9bcba6f70beb6ebc085a400db'),
(63,1776948189,1,'BE',2,0,13,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"konolfingen hund familie\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"12\",\"sys_language_uid\":0,\"crdate\":1776948189,\"t3ver_stage\":0,\"tstamp\":1776948189,\"uid\":13}',0,'0400$957f3842b64935614d322e3ede54a6a8:5e1f4fea56ad8d21a419f2b59b059abf'),
(64,1776948199,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"0\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"1\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$31d116c2866ec468cfa40d165fcb0718:c7626fc9bcba6f70beb6ebc085a400db'),
(65,1776948199,2,'BE',2,0,13,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$31d116c2866ec468cfa40d165fcb0718:5e1f4fea56ad8d21a419f2b59b059abf'),
(66,1776948204,2,'BE',2,0,5,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"1\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"2\"}}',0,'0400$2bc793fa8383fd6d8f8dc276b693cfb1:c7626fc9bcba6f70beb6ebc085a400db'),
(67,1776948964,1,'BE',2,0,6,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":384,\"sys_language_uid\":0,\"tx_mask_color_of_the_lement\":\"#C7CAC5\",\"header\":\"\",\"tx_mask_text_text_on_colorful_background\":\"<p>DREI WOHNWELTEN DREI ARTEN SICH ZUHAUSE ZU F\\u00dcHLEN.<\\/p>\",\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"4\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776948964,\"t3ver_stage\":0,\"tstamp\":1776948964,\"uid\":6}',0,'0400$8ebc85de27cc01f300a6fab653f255d0:c0db6803ab1ec5f70c36e2a72187867b'),
(68,1776949548,1,'BE',2,0,7,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":704,\"sys_language_uid\":0,\"tx_mask_color_of_the_lement\":\"#B9A99A\",\"header\":\"\",\"tx_mask_text_text_on_colorful_background\":\"<p>Text \\u00fcber Konolfingen sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_link\":\"t3:\\/\\/page?uid=3\",\"tx_mask_layout_choose\":\"0\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776949548,\"t3ver_stage\":0,\"tstamp\":1776949548,\"uid\":7}',0,'0400$4e60ccf3a04e1997aa25bf1eb91d8c0c:ea41b626baac59a1fe0716bc344af5d9'),
(69,1776949675,2,'BE',2,0,7,'tt_content','{\"oldRecord\":{\"tx_mask_text_to_link\":\"\",\"tx_mask_layout_choose\":\"0\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_text_to_link\":\"Mehr erfahren\",\"tx_mask_layout_choose\":\"3\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"}}',0,'0400$3e2b9b4d55b9727bcf7cd20e69d30eae:ea41b626baac59a1fe0716bc344af5d9'),
(70,1776949885,1,'BE',2,0,8,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":128,\"sys_language_uid\":0,\"tx_mask_color_of_the_lement\":\"#F6F2EC\",\"header\":\"Modernes Wohnprojekt in Konolfingen H\\u00e4user, Garten- und Terrassenwohnungen\",\"tx_mask_text_text_on_colorful_background\":\"<p>Einleitungstext zum Projekt Gr\\u00fcnegg sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_text_to_link\":\"\",\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"0\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776949885,\"t3ver_stage\":0,\"tstamp\":1776949885,\"uid\":8}',0,'0400$1eb9942dcafe4d4de31fcaf30ee35feb:2097d84972a039cb6bfe093b17089287'),
(71,1776952060,1,'BE',2,0,9,'tt_content','{\"CType\":\"mask_info_contact_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":896,\"sys_language_uid\":0,\"header\":\"Wer findet in gr\\u00fcnegg das passende zuhause?\",\"tx_mask_make_my_life_colorfull\":\"#48433F\",\"tx_mask_image_on_the_right_side\":\"0\",\"tx_mask_text_whiteee\":\"1\",\"tx_mask_copy_textus\":\"<p>Text \\u00fcber die Zielgruppe sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_height_of_the_element\":\"0\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776952060,\"t3ver_stage\":0,\"tstamp\":1776952060,\"uid\":9}',0,'0400$0e6907e77c963033afc31ab2b5deb55a:367f4f227870d8e2a11496a182574aa3'),
(72,1776952060,1,'BE',2,0,14,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"frau konolfingen\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"13\",\"sys_language_uid\":0,\"crdate\":1776952060,\"t3ver_stage\":0,\"tstamp\":1776952060,\"uid\":14}',0,'0400$0e6907e77c963033afc31ab2b5deb55a:2207c2b650522ebf0efd90eaad3962af'),
(73,1776952078,2,'BE',2,0,9,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_element\":\"0\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_height_of_the_element\":\"2\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"}}',0,'0400$ed32bb647a4651e30f02ecff7d2c9142:367f4f227870d8e2a11496a182574aa3'),
(74,1776952078,2,'BE',2,0,14,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$ed32bb647a4651e30f02ecff7d2c9142:2207c2b650522ebf0efd90eaad3962af'),
(75,1776952821,1,'BE',2,0,10,'tt_content','{\"CType\":\"mask_info_contact_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":1280,\"sys_language_uid\":0,\"header\":\"\",\"tx_mask_make_my_life_colorfull\":\"#F6F2EC\",\"tx_mask_image_on_the_right_side\":\"0\",\"tx_mask_text_whiteee\":\"0\",\"tx_mask_copy_textus\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_extra_text_right_side\":\"<p><a href=\\\"tel:+41797737519\\\">+41 79 773 75 19<\\/a><br \\/><a href=\\\"mailto:info@adowia.ch\\\">info@adowia.ch<\\/a><\\/p>\",\"tx_mask_small_contact_text_below_text\":\"Kontakt aufnehmen\",\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=5\",\"tx_mask_height_of_the_element\":\"2\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776952821,\"t3ver_stage\":0,\"tstamp\":1776952821,\"uid\":10}',0,'0400$bb93ef709eac30d7185eac1eb475bf70:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(76,1776952884,2,'BE',2,0,10,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"}}',0,'0400$7498e14dc880016acb085032a019ee79:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(77,1776952884,1,'BE',2,0,15,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Dominique Andreas Waser\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"14\",\"sys_language_uid\":0,\"crdate\":1776952884,\"t3ver_stage\":0,\"tstamp\":1776952884,\"uid\":15}',0,'0400$7498e14dc880016acb085032a019ee79:53cbb769126fb106e07a09de5e196b60'),
(78,1776952884,2,'BE',2,0,10,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"}}',0,'0400$7498e14dc880016acb085032a019ee79:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(79,1776953123,2,'BE',2,0,10,'tt_content','{\"oldRecord\":{\"tx_mask_design_layout\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_design_layout\":\"1\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"}}',0,'0400$b9c1fa02ab7fc62d2e66d669f311182e:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(80,1776953123,2,'BE',2,0,15,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$b9c1fa02ab7fc62d2e66d669f311182e:53cbb769126fb106e07a09de5e196b60'),
(81,1776953671,2,'BE',2,0,9,'tt_content','{\"oldRecord\":{\"tx_mask_design_layout\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_design_layout\":\"0\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"}}',0,'0400$b7fb0c15452c90ac4e793ca5c49f2da4:367f4f227870d8e2a11496a182574aa3'),
(82,1776954685,1,'BE',2,0,16,'sys_file_reference','{\"pid\":3,\"tstamp\":1776954685,\"crdate\":1776954685,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"11\",\"title\":null,\"alternative\":null,\"uid_foreign\":4,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_simple_image_class\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":16}',0,'0400$06d8f78047670fa7b3aed80149e5c46e:5a9ade48273ee95d803333aed1c78820'),
(83,1776954685,1,'BE',2,0,11,'tt_content','{\"CType\":\"mask_simple_image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_simple_image_class\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":3,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":null,\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":null,\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_text_text_on_colorful_background\":null,\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":null,\"tx_mask_extra_text_right_side\":null,\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"\",\"tx_mask_design_layout\":\"\",\"crdate\":1776954685,\"t3ver_stage\":0,\"tstamp\":1776954685,\"uid\":11}',0,'0400$02028a255bb673b1847faac47412aaef:7a14c618500ae24604910dfdd2f8ff12'),
(84,1776954685,2,'BE',2,0,11,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_simple_image_class\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$443edf041caedac23ca43baee79a014f:7a14c618500ae24604910dfdd2f8ff12'),
(85,1776954687,2,'BE',2,0,11,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$96f285a0e90ba9618a683a78eb914b22:7a14c618500ae24604910dfdd2f8ff12'),
(86,1776954747,2,'BE',2,0,11,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_simple_image_class\\\":\\\"\\\"}\"}}',0,'0400$4224c202092dec7d055076035948260b:7a14c618500ae24604910dfdd2f8ff12'),
(87,1776954747,2,'BE',2,0,16,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4224c202092dec7d055076035948260b:5a9ade48273ee95d803333aed1c78820'),
(88,1776954747,1,'BE',2,0,17,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"konolfingen\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"15\",\"sys_language_uid\":0,\"crdate\":1776954747,\"t3ver_stage\":0,\"tstamp\":1776954747,\"uid\":17}',0,'0400$4224c202092dec7d055076035948260b:78ba90db28917b77e8d54ca398316d0e'),
(89,1776954747,2,'BE',2,0,11,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_simple_image_class\\\":\\\"\\\"}\"}}',0,'0400$4224c202092dec7d055076035948260b:7a14c618500ae24604910dfdd2f8ff12'),
(90,1776954935,2,'BE',2,0,17,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$f7b3d6bb5dd892889bacef41da425711:78ba90db28917b77e8d54ca398316d0e'),
(91,1776955738,1,'BE',2,0,12,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":3,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"Modernes Wohnprojekt in Konolfingen H\\u00e4user, Garten- und Terrassenwohnungen\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":null,\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":null,\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"#F6F2EC\",\"tx_mask_text_text_on_colorful_background\":\"<p>Einleitungstext zum Projekt Gr\\u00fcnegg sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"0\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":null,\"tx_mask_extra_text_right_side\":null,\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"\",\"tx_mask_design_layout\":\"\",\"crdate\":1776955738,\"t3ver_stage\":0,\"tstamp\":1776955738,\"uid\":12}',0,'0400$a17382570ea24f2109372bb7b1be8f39:b13bbccfb8e2fc277be02db62485ced6'),
(92,1776955738,2,'BE',2,0,12,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$3736186a4f28335c4c95def399fe1989:b13bbccfb8e2fc277be02db62485ced6'),
(93,1776955740,2,'BE',2,0,12,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$20757ede773866d791129ca82ffa38f8:b13bbccfb8e2fc277be02db62485ced6'),
(94,1776955761,2,'BE',2,0,12,'tt_content','{\"oldRecord\":{\"tx_mask_color_of_the_lement\":\"#F6F2EC\",\"header\":\"Modernes Wohnprojekt in Konolfingen H\\u00e4user, Garten- und Terrassenwohnungen\",\"tx_mask_text_text_on_colorful_background\":\"<p>Einleitungstext zum Projekt Gr\\u00fcnegg sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_color_of_the_lement\":\"#E2E4E6\",\"header\":\"Wohnungen im \\u00fcberblick\",\"tx_mask_text_text_on_colorful_background\":\"<p>Einleitungstext zu den Objekten sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"}}',0,'0400$e926f35040959aa8c471530bcd0e0d5c:b13bbccfb8e2fc277be02db62485ced6'),
(95,1776955772,3,'BE',2,0,11,'tt_content','{\"oldData\":{\"pid\":3,\"tstamp\":1776954935,\"sorting\":256},\"newData\":{\"tstamp\":1776955772,\"sorting\":64,\"pid\":3}}',0,'0400$e687df205a3302983d32dc1392ab7c94:7a14c618500ae24604910dfdd2f8ff12'),
(96,1776955772,2,'BE',2,0,11,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_simple_image_class\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$fe159a184450a1b0cea3792dba83c44a:7a14c618500ae24604910dfdd2f8ff12'),
(97,1776955864,1,'BE',2,0,18,'sys_file_reference','{\"pid\":4,\"tstamp\":1776955864,\"crdate\":1776955864,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"12\",\"title\":null,\"alternative\":\"konolfingen hund familie\",\"uid_foreign\":5,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_image_second_column\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":18}',0,'0400$1b6a139539870cc163f018ed142c6e0c:c9d27ac33ea45c5163a9ef7a25d8e7c7'),
(98,1776955864,1,'BE',2,0,13,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"tx_mask_color_first_column\":\"#F6F2EC\",\"tx_mask_text_second_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"2\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_text_text_on_colorful_background\":null,\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":null,\"tx_mask_extra_text_right_side\":null,\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"\",\"tx_mask_design_layout\":\"\",\"crdate\":1776955864,\"t3ver_stage\":0,\"tstamp\":1776955864,\"uid\":13}',0,'0400$3a98782a697c539f8da1273e84e46509:aa58d78b4f5fe95c0d2d1cb36d041737'),
(99,1776955864,2,'BE',2,0,13,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$ecc3610ce0c0f86eea75bb175fc52abb:aa58d78b4f5fe95c0d2d1cb36d041737'),
(100,1776955866,2,'BE',2,0,13,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$287432dfa7b71548a66bef7ac77b9e44:aa58d78b4f5fe95c0d2d1cb36d041737'),
(101,1776955955,2,'BE',2,0,13,'tt_content','{\"oldRecord\":{\"tx_mask_text_first_col\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"tx_mask_color_first_column\":\"#F6F2EC\",\"tx_mask_text_second_column\":\"\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_text_first_col\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$db284e276937c383f3df0977a0757faf:aa58d78b4f5fe95c0d2d1cb36d041737'),
(102,1776955955,1,'BE',2,0,19,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Kind Spaziergang\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"16\",\"sys_language_uid\":0,\"crdate\":1776955955,\"t3ver_stage\":0,\"tstamp\":1776955955,\"uid\":19}',0,'0400$db284e276937c383f3df0977a0757faf:7008e0248119dc3a255a0170bf6e9370'),
(103,1776955955,2,'BE',2,0,13,'tt_content','{\"oldRecord\":{\"tx_mask_text_first_col\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"tx_mask_color_first_column\":\"#F6F2EC\",\"tx_mask_text_second_column\":\"\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_text_first_col\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$db284e276937c383f3df0977a0757faf:aa58d78b4f5fe95c0d2d1cb36d041737'),
(104,1776955987,2,'BE',2,0,13,'tt_content','{\"oldRecord\":{\"tx_mask_text_white_second_column\":0,\"tx_mask_image_second_column\":1,\"tx_mask_color_second_column\":\"\"},\"newRecord\":{\"tx_mask_text_white_second_column\":\"1\",\"tx_mask_image_second_column\":0,\"tx_mask_color_second_column\":\"#B9A99A\"}}',0,'0400$5507ace79a39e9e6a9bdaa386d19bbf0:aa58d78b4f5fe95c0d2d1cb36d041737'),
(105,1776955987,2,'BE',2,0,19,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$5507ace79a39e9e6a9bdaa386d19bbf0:7008e0248119dc3a255a0170bf6e9370'),
(106,1776955987,4,'BE',2,0,18,'sys_file_reference',NULL,0,'0400$5507ace79a39e9e6a9bdaa386d19bbf0:c9d27ac33ea45c5163a9ef7a25d8e7c7'),
(107,1776956029,1,'BE',2,0,14,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":512,\"sys_language_uid\":0,\"tx_mask_color_of_the_lement\":\"#F6F2EC\",\"header\":\"\",\"tx_mask_text_text_on_colorful_background\":\"<p>Text \\u00fcber Konolfingen dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_text_to_link\":\"\",\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"4\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1776956029,\"t3ver_stage\":0,\"tstamp\":1776956029,\"uid\":14}',0,'0400$11773edf1165405504a383f00cd5b87e:338e104baa774eacaec42da729015b5f'),
(108,1776956137,1,'BE',2,0,20,'sys_file_reference','{\"pid\":5,\"tstamp\":1776956137,\"crdate\":1776956137,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"14\",\"title\":null,\"alternative\":\"Dominique Andreas Waser\",\"uid_foreign\":10,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_add_image\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":20}',0,'0400$4af1fa87488d36b239f809a7f8e5d9eb:97d0d1c7a42cd9603b2010379c1e4e4d'),
(109,1776956137,1,'BE',2,0,15,'tt_content','{\"CType\":\"mask_info_contact_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":null,\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":null,\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_text_text_on_colorful_background\":null,\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"#F6F2EC\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_extra_text_right_side\":\"<p><a href=\\\"tel:+41797737519\\\">+41 79 773 75 19<\\/a><br \\/><a href=\\\"mailto:info@adowia.ch\\\">info@adowia.ch<\\/a><\\/p>\",\"tx_mask_small_contact_text_below_text\":\"Kontakt aufnehmen\",\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=5\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"2\",\"tx_mask_design_layout\":\"1\",\"crdate\":1776956137,\"t3ver_stage\":0,\"tstamp\":1776956137,\"uid\":15}',0,'0400$1313d0f49221a22d5502fc1f31926060:cb118fde3da18e67b21a92b60bb8cbda'),
(110,1776956137,2,'BE',2,0,15,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$8d840fcf3459b6ec37b0240cb2a25e13:cb118fde3da18e67b21a92b60bb8cbda'),
(111,1776956138,2,'BE',2,0,15,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$6160f90ee31d640517d589ca3b10f42e:cb118fde3da18e67b21a92b60bb8cbda'),
(112,1776956187,2,'BE',2,0,15,'tt_content','{\"oldRecord\":{\"header\":\"\",\"tx_mask_make_my_life_colorfull\":\"#F6F2EC\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_extra_text_right_side\":\"<p><a href=\\\"tel:+41797737519\\\">+41 79 773 75 19<\\/a><br \\/><a href=\\\"mailto:info@adowia.ch\\\">info@adowia.ch<\\/a><\\/p>\",\"tx_mask_small_contact_text_below_text\":\"Kontakt aufnehmen\",\"tx_mask_design_layout\":\"1\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Beratung und Verkauf\",\"tx_mask_make_my_life_colorfull\":\"#D3D6D7\",\"tx_mask_image_on_the_right_side\":\"1\",\"tx_mask_copy_textus\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/p>\\r\\n<p>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer Adowia<\\/p>\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_small_contact_text_below_text\":\"Zum Kontaktformular\",\"tx_mask_design_layout\":\"2\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"}}',0,'0400$25e6b205577d5d06f83952f63f822935:cb118fde3da18e67b21a92b60bb8cbda'),
(113,1776956187,2,'BE',2,0,20,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$25e6b205577d5d06f83952f63f822935:97d0d1c7a42cd9603b2010379c1e4e4d'),
(114,1777014061,1,'BE',2,0,16,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":512,\"sys_language_uid\":0,\"tx_mask_height_of_the_elemnet\":\"0\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_white_first_col\":\"0\",\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_second_column\":\"0\",\"tx_mask_color_second_column\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777014061,\"t3ver_stage\":0,\"tstamp\":1777014061,\"uid\":16}',0,'0400$3fb60031389962ee16e78c03b78dab60:43f02d513e41a72738b96558f7ee9015'),
(115,1777014210,2,'BE',2,0,16,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"0\",\"tx_mask_color_second_column\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"2\",\"tx_mask_color_second_column\":\"#F6F2EC\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$33ac386aab5c3d78236e12ba5e58f8f1:43f02d513e41a72738b96558f7ee9015'),
(116,1777014210,1,'BE',2,0,21,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"wohnung blumen konolfingen\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":5,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"17\",\"sys_language_uid\":0,\"crdate\":1777014210,\"t3ver_stage\":0,\"tstamp\":1777014210,\"uid\":21}',0,'0400$33ac386aab5c3d78236e12ba5e58f8f1:bd8e6a36b477d61e04d92cfd10d00f96'),
(117,1777014210,2,'BE',2,0,16,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"0\",\"tx_mask_color_second_column\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"2\",\"tx_mask_color_second_column\":\"#F6F2EC\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$33ac386aab5c3d78236e12ba5e58f8f1:43f02d513e41a72738b96558f7ee9015'),
(118,1777014255,1,'BE',2,0,9,'pages','{\"doktype\":\"254\",\"slug\":\"\\/storage\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":2,\"sorting\":1792,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Storage\",\"sys_language_uid\":0,\"crdate\":1777014255,\"t3ver_stage\":0,\"tstamp\":1777014255,\"uid\":9}',0,'0400$dd921ce8604100469f9a84b1095bc966:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(119,1777014257,2,'BE',2,0,9,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4d3dfbbe2148d2c7ffc592d96c020788:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(120,1777014296,1,'BE',2,0,1,'tx_powermail_domain_model_form','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"autocomplete_token\":\"\",\"pid\":9,\"title\":\"Contact form\",\"css\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1777014296,\"t3ver_stage\":0,\"tstamp\":1777014296,\"uid\":1}',0,'0400$1f47516fb0dea2dfb2d81176288c2b11:77fadea38ee7186969949ea2d770fa93'),
(121,1777014296,1,'BE',2,0,1,'tx_powermail_domain_model_page','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"form\":0,\"pid\":9,\"sorting\":256,\"title\":\"Contact form first page\",\"css\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fields\\\":\\\"\\\",\\\"form\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\",\"crdate\":1777014296,\"t3ver_stage\":0,\"tstamp\":1777014296,\"uid\":1}',0,'0400$1f47516fb0dea2dfb2d81176288c2b11:815cca2cf067a5fe97906554dd6c4ed0'),
(122,1777014296,1,'BE',2,0,1,'tx_powermail_domain_model_field','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"settings\":\"\",\"content_element\":0,\"text\":\"\",\"mandatory_text\":\"\",\"validation\":\"0\",\"prefill_value\":\"\",\"placeholder\":\"\",\"placeholder_repeat\":\"\",\"create_from_typoscript\":\"\",\"own_marker_select\":\"0\",\"page\":0,\"autocomplete_token\":\"\",\"pid\":9,\"sorting\":256,\"title\":\"Vorname\",\"type\":\"input\",\"sender_email\":\"0\",\"sender_name\":\"0\",\"mandatory\":\"1\",\"feuser_value\":\"\",\"css\":\"\",\"description\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\",\"crdate\":1777014296,\"t3ver_stage\":0,\"tstamp\":1777014296,\"marker\":\"vorname\",\"uid\":1}',0,'0400$1f47516fb0dea2dfb2d81176288c2b11:ed5eb58d03ba4d3d71a179b4d8b4a71a'),
(123,1777014325,2,'BE',2,0,1,'tx_powermail_domain_model_form','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"note\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$1e860b6582b2041ec809aeff1e2ccd97:77fadea38ee7186969949ea2d770fa93'),
(124,1777014325,2,'BE',2,0,1,'tx_powermail_domain_model_page','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fields\\\":\\\"\\\",\\\"form\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fields\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$1e860b6582b2041ec809aeff1e2ccd97:815cca2cf067a5fe97906554dd6c4ed0'),
(125,1777014325,2,'BE',2,0,1,'tx_powermail_domain_model_field','{\"oldRecord\":{\"sender_name\":0,\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"sender_name\":\"1\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"}}',0,'0400$1e860b6582b2041ec809aeff1e2ccd97:ed5eb58d03ba4d3d71a179b4d8b4a71a'),
(126,1777014325,1,'BE',2,0,2,'tx_powermail_domain_model_field','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"settings\":\"\",\"content_element\":0,\"text\":\"\",\"mandatory_text\":\"\",\"validation\":\"0\",\"prefill_value\":\"\",\"placeholder\":\"\",\"placeholder_repeat\":\"\",\"create_from_typoscript\":\"\",\"own_marker_select\":\"0\",\"page\":0,\"autocomplete_token\":\"\",\"pid\":9,\"sorting\":0,\"title\":\"Name\",\"type\":\"input\",\"sender_email\":\"0\",\"sender_name\":\"1\",\"mandatory\":\"1\",\"feuser_value\":\"\",\"css\":\"\",\"description\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\",\"crdate\":1777014325,\"t3ver_stage\":0,\"tstamp\":1777014325,\"marker\":\"name\",\"uid\":2}',0,'0400$1e860b6582b2041ec809aeff1e2ccd97:b81fa3248eb0979894ffb18e8664f4bc'),
(127,1777014325,2,'BE',2,0,1,'tx_powermail_domain_model_page','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fields\\\":\\\"\\\",\\\"form\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fields\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$1e860b6582b2041ec809aeff1e2ccd97:815cca2cf067a5fe97906554dd6c4ed0'),
(128,1777014337,2,'BE',2,0,1,'tx_powermail_domain_model_form','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"note\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"pages\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\"}\"}}',0,'0400$46e46f472d4ea1abd198145ac34ef9e1:77fadea38ee7186969949ea2d770fa93'),
(129,1777014337,2,'BE',2,0,1,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$46e46f472d4ea1abd198145ac34ef9e1:ed5eb58d03ba4d3d71a179b4d8b4a71a'),
(130,1777014337,2,'BE',2,0,2,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"}}',0,'0400$46e46f472d4ea1abd198145ac34ef9e1:b81fa3248eb0979894ffb18e8664f4bc'),
(131,1777014337,1,'BE',2,0,3,'tx_powermail_domain_model_field','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"settings\":\"\",\"content_element\":0,\"text\":\"\",\"mandatory_text\":\"\",\"validation\":\"0\",\"prefill_value\":\"\",\"placeholder\":\"\",\"placeholder_repeat\":\"\",\"create_from_typoscript\":\"\",\"own_marker_select\":\"0\",\"page\":0,\"autocomplete_token\":\"\",\"pid\":9,\"sorting\":0,\"title\":\"E-Mail\",\"type\":\"input\",\"sender_email\":\"1\",\"sender_name\":\"0\",\"mandatory\":\"1\",\"feuser_value\":\"\",\"css\":\"\",\"description\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\",\"crdate\":1777014337,\"t3ver_stage\":0,\"tstamp\":1777014337,\"marker\":\"e_mail\",\"uid\":3}',0,'0400$46e46f472d4ea1abd198145ac34ef9e1:a8d7ff9f004bc4385d27c077c840ab4a'),
(132,1777014344,2,'BE',2,0,2,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$bc1855ad5eaf1d04b1dd46b61e06f875:b81fa3248eb0979894ffb18e8664f4bc'),
(133,1777014344,2,'BE',2,0,3,'tx_powermail_domain_model_field','{\"oldRecord\":{\"validation\":0,\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"validation\":\"1\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"}}',0,'0400$bc1855ad5eaf1d04b1dd46b61e06f875:a8d7ff9f004bc4385d27c077c840ab4a'),
(134,1777014488,1,'BE',2,0,4,'tx_powermail_domain_model_field','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"settings\":\"\",\"content_element\":0,\"text\":\"\",\"mandatory_text\":\"\",\"validation\":\"0\",\"prefill_value\":\"\",\"placeholder\":\"\",\"placeholder_repeat\":\"\",\"create_from_typoscript\":\"\",\"own_marker_select\":\"0\",\"page\":0,\"autocomplete_token\":\"\",\"pid\":9,\"sorting\":0,\"title\":\"Telefonnummer\",\"type\":\"input\",\"sender_email\":\"0\",\"sender_name\":\"0\",\"mandatory\":\"1\",\"feuser_value\":\"\",\"css\":\"\",\"description\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\",\"crdate\":1777014488,\"t3ver_stage\":0,\"tstamp\":1777014488,\"marker\":\"telefonnummer\",\"uid\":4}',0,'0400$0c12f84acdb6a5ccea141fc9c571db7a:80f063665beebd0450888f3fa2497ab9'),
(135,1777014502,2,'BE',2,0,3,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c1fc9b3a8468a2ac1b4007730d0600b7:a8d7ff9f004bc4385d27c077c840ab4a'),
(136,1777014502,2,'BE',2,0,4,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"}}',0,'0400$c1fc9b3a8468a2ac1b4007730d0600b7:80f063665beebd0450888f3fa2497ab9'),
(137,1777014502,1,'BE',2,0,5,'tx_powermail_domain_model_field','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"settings\":\"\",\"content_element\":0,\"text\":\"\",\"mandatory_text\":\"\",\"validation\":\"0\",\"prefill_value\":\"\",\"placeholder\":\"\",\"placeholder_repeat\":\"\",\"create_from_typoscript\":\"\",\"own_marker_select\":\"0\",\"page\":0,\"autocomplete_token\":\"\",\"pid\":9,\"sorting\":0,\"title\":\"Ich interessiere mich f\\u00fcr folgenden Wohnraum\",\"type\":\"textarea\",\"sender_email\":\"0\",\"sender_name\":\"0\",\"mandatory\":\"0\",\"feuser_value\":\"\",\"css\":\"\",\"description\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\",\"crdate\":1777014502,\"t3ver_stage\":0,\"tstamp\":1777014502,\"marker\":\"ichinteressieremichfuerfolgendenwohnraum\",\"uid\":5}',0,'0400$c1fc9b3a8468a2ac1b4007730d0600b7:8e79b3fad92007430c6158853517bb53'),
(138,1777014522,2,'BE',2,0,4,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$6147c01c532f2ae87a417f0823225b38:80f063665beebd0450888f3fa2497ab9'),
(139,1777014522,2,'BE',2,0,5,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"}}',0,'0400$6147c01c532f2ae87a417f0823225b38:8e79b3fad92007430c6158853517bb53'),
(140,1777014522,1,'BE',2,0,6,'tx_powermail_domain_model_field','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"settings\":\"\",\"content_element\":0,\"text\":\"\",\"mandatory_text\":\"\",\"validation\":\"0\",\"prefill_value\":\"\",\"placeholder\":\"\",\"placeholder_repeat\":\"\",\"create_from_typoscript\":\"\",\"own_marker_select\":\"0\",\"page\":0,\"autocomplete_token\":\"\",\"pid\":9,\"sorting\":0,\"title\":\"Anfrage senden\",\"type\":\"submit\",\"sender_email\":\"0\",\"sender_name\":\"0\",\"mandatory\":\"0\",\"feuser_value\":\"\",\"css\":\"\",\"description\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\",\"crdate\":1777014522,\"t3ver_stage\":0,\"tstamp\":1777014522,\"marker\":\"anfragesenden\",\"uid\":6}',0,'0400$6147c01c532f2ae87a417f0823225b38:2eac15cec105d1e4e874b103ce4be2d2'),
(141,1777014526,2,'BE',2,0,5,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$dd1c9cb220f2324d25a4a3294c76079f:8e79b3fad92007430c6158853517bb53'),
(142,1777014526,2,'BE',2,0,6,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"autocomplete_token\\\":\\\"\\\",\\\"content_element\\\":\\\"\\\",\\\"create_from_typoscript\\\":\\\"\\\",\\\"css\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"feuser_value\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"mandatory\\\":\\\"\\\",\\\"mandatory_text\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"page\\\":\\\"\\\",\\\"placeholder\\\":\\\"\\\",\\\"placeholder_repeat\\\":\\\"\\\",\\\"prefill_value\\\":\\\"\\\",\\\"sender_email\\\":\\\"\\\",\\\"sender_name\\\":\\\"\\\",\\\"settings\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"text\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\",\\\"validation\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\"}\"}}',0,'0400$dd1c9cb220f2324d25a4a3294c76079f:2eac15cec105d1e4e874b103ce4be2d2'),
(143,1777014640,1,'BE',2,0,17,'tt_content','{\"CType\":\"powermail_pi1\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"999\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":5,\"sorting\":128,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.main.form\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.confirmation\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.optin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.moresteps\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.pid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"receiver\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.receiver.type\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.name\\\">\\n                    <value index=\\\"vDEF\\\">Adowia \\u2013\\u00a0Dominique Andreas Waser<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.email\\\">\\n                    <value index=\\\"vDEF\\\">dani@studiothompfister.com<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.subject\\\">\\n                    <value index=\\\"vDEF\\\">Gr\\u00fcnegg |\\u00a0Nachricht \\u00fcber das Kontaktformular<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"sender\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.sender.name\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.email\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.subject\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"thx\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.thx.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.thx.redirect\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"sys_language_uid\":0,\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777014640,\"t3ver_stage\":0,\"tstamp\":1777014640,\"uid\":17}',0,'0400$85f3c2d74a982f5c5c31f569d3238737:017157395cc6da9e5d2911de6dfd4b9e'),
(144,1777014640,2,'BE',2,0,21,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$85f3c2d74a982f5c5c31f569d3238737:bd8e6a36b477d61e04d92cfd10d00f96'),
(145,1777014649,1,'BE',2,0,10,'pages','{\"doktype\":\"1\",\"slug\":\"\\/kontakt\\/danke-fuer-ihre-nachricht\",\"categories\":\"0\",\"layout\":\"0\",\"lastUpdated\":0,\"newUntil\":0,\"cache_timeout\":\"0\",\"shortcut\":0,\"shortcut_mode\":\"0\",\"content_from_pid\":0,\"mount_pid\":0,\"module\":\"\",\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"pid\":5,\"sorting\":256,\"perms_userid\":2,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Danke f\\u00fcr Ihre Nachricht\",\"sys_language_uid\":0,\"crdate\":1777014649,\"t3ver_stage\":0,\"tstamp\":1777014649,\"uid\":10}',0,'0400$90493afa4184338a59676f1d2cb1c9a7:e904af5a60392ab3165f5849f5877e45'),
(146,1777014656,2,'BE',2,0,10,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"}}',0,'0400$edcf067711f7e19613fcc5d1f73f8f86:e904af5a60392ab3165f5849f5877e45'),
(147,1777014658,2,'BE',2,0,10,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"nav_hide\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$f7074ac805ef4f3ef9fba5632112ced2:e904af5a60392ab3165f5849f5877e45'),
(148,1777014845,1,'BE',2,0,18,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":256,\"sys_language_uid\":0,\"tx_mask_color_of_the_lement\":\"#D3D6D7\",\"header\":\"Danke f\\u00fcr Ihre Nachricht\",\"tx_mask_text_text_on_colorful_background\":\"<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">Vielen Dank f\\u00fcr Ihre Nachricht.<\\/p>\\r\\n<p class=\\\"text-center\\\">Ich werde mich zeitnah bei Ihnen melden.<\\/p>\\r\\n<p class=\\\"text-center\\\">Freundliche Gr\\u00fcsse<br \\/><br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\"><a href=\\\"t3:\\/\\/page?uid=2\\\">Zur\\u00fcck zur Homepage<\\/a><\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\",\"tx_mask_text_to_link\":\"\",\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"4\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777014845,\"t3ver_stage\":0,\"tstamp\":1777014845,\"uid\":18}',0,'0400$2de225d8989b2a104e6db26462b5a3c8:0a64be1ae1f9096cc345beb76e5e2095'),
(149,1777014869,2,'BE',2,0,18,'tt_content','{\"oldRecord\":{\"tx_mask_text_text_on_colorful_background\":\"<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">Vielen Dank f\\u00fcr Ihre Nachricht.<\\/p>\\r\\n<p class=\\\"text-center\\\">Ich werde mich zeitnah bei Ihnen melden.<\\/p>\\r\\n<p class=\\\"text-center\\\">Freundliche Gr\\u00fcsse<br \\/><br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\"><a href=\\\"t3:\\/\\/page?uid=2\\\">Zur\\u00fcck zur Homepage<\\/a><\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_text_text_on_colorful_background\":\"<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">Vielen Dank f\\u00fcr Ihre Nachricht.<br \\/>Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\"><a href=\\\"t3:\\/\\/page?uid=2\\\">Zur\\u00fcck zur Homepage<\\/a><\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"}}',0,'0400$7fe2b5cae598f1671d49ef313fbbe55a:0a64be1ae1f9096cc345beb76e5e2095'),
(150,1777014914,2,'BE',2,0,18,'tt_content','{\"oldRecord\":{\"hidden\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"1\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$d7e3fd74055c648b36097b5f9f5edde3:0a64be1ae1f9096cc345beb76e5e2095'),
(151,1777014917,1,'BE',2,0,22,'sys_file_reference','{\"pid\":10,\"tstamp\":1777014917,\"crdate\":1777014917,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"14\",\"title\":null,\"alternative\":\"Dominique Andreas Waser\",\"uid_foreign\":10,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_add_image\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":22}',0,'0400$3e07329eba3be7531cb8a921181a3105:d6a5725e5b31cdd97b9c53c992e81850'),
(152,1777014917,1,'BE',2,0,19,'tt_content','{\"CType\":\"mask_info_contact_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":null,\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":null,\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_text_text_on_colorful_background\":null,\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"#F6F2EC\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_extra_text_right_side\":\"<p><a href=\\\"tel:+41797737519\\\">+41 79 773 75 19<\\/a><br \\/><a href=\\\"mailto:info@adowia.ch\\\">info@adowia.ch<\\/a><\\/p>\",\"tx_mask_small_contact_text_below_text\":\"Kontakt aufnehmen\",\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=5\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"2\",\"tx_mask_design_layout\":\"1\",\"tx_mask_content_parent_uid\":0,\"crdate\":1777014917,\"t3ver_stage\":0,\"tstamp\":1777014917,\"uid\":19}',0,'0400$2873e5cfde302f1651ac5f30fb74249a:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(153,1777014917,2,'BE',2,0,19,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$e8a7873d3495d852d4c481bcaf7087be:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(154,1777014918,2,'BE',2,0,19,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$182462bd90be89867a85a85ce40ea0f7:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(155,1777014959,2,'BE',2,0,19,'tt_content','{\"oldRecord\":{\"header\":\"\",\"tx_mask_copy_textus\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_extra_text_right_side\":\"<p><a href=\\\"tel:+41797737519\\\">+41 79 773 75 19<\\/a><br \\/><a href=\\\"mailto:info@adowia.ch\\\">info@adowia.ch<\\/a><\\/p>\",\"tx_mask_small_contact_text_below_text\":\"Kontakt aufnehmen\",\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=5\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Danke f\\u00fcr Ihre Nachricht\",\"tx_mask_copy_textus\":\"<p class=\\\"text-center\\\">Vielen Dank f\\u00fcr Ihre Nachricht.<br \\/>Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\"><a href=\\\"t3:\\/\\/page?uid=2\\\">Zur\\u00fcck zur Homepage<\\/a><\\/p>\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_small_contact_text_below_text\":\"Zur\\u00fcck zur Homepage\",\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=2\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"}}',0,'0400$ab914fd3cd9d90ac43d142b333bf85db:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(156,1777014959,2,'BE',2,0,22,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$ab914fd3cd9d90ac43d142b333bf85db:d6a5725e5b31cdd97b9c53c992e81850'),
(157,1777014965,2,'BE',2,0,19,'tt_content','{\"oldRecord\":{\"tx_mask_image_on_the_right_side\":0},\"newRecord\":{\"tx_mask_image_on_the_right_side\":\"1\"}}',0,'0400$c4db8ff9ebfe4d30ce550b2db1c4d4f2:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(158,1777014986,2,'BE',2,0,19,'tt_content','{\"oldRecord\":{\"tx_mask_copy_textus\":\"<p class=\\\"text-center\\\">Vielen Dank f\\u00fcr Ihre Nachricht.<br \\/>Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\"><a href=\\\"t3:\\/\\/page?uid=2\\\">Zur\\u00fcck zur Homepage<\\/a><\\/p>\"},\"newRecord\":{\"tx_mask_copy_textus\":\"<h1 class=\\\"text-center\\\">Vielen Dank f\\u00fcr Ihre Nachricht.<\\/h1>\\r\\n<p class=\\\"text-center\\\">Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\"><a href=\\\"t3:\\/\\/page?uid=2\\\">Zur\\u00fcck zur Homepage<\\/a><\\/p>\"}}',0,'0400$8b219b7fc2f117f9093b1101a1d51556:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(159,1777014992,2,'BE',2,0,19,'tt_content','{\"oldRecord\":{\"tx_mask_copy_textus\":\"<h1 class=\\\"text-center\\\">Vielen Dank f\\u00fcr Ihre Nachricht.<\\/h1>\\r\\n<p class=\\\"text-center\\\">Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\"><a href=\\\"t3:\\/\\/page?uid=2\\\">Zur\\u00fcck zur Homepage<\\/a><\\/p>\"},\"newRecord\":{\"tx_mask_copy_textus\":\"<h1 class=\\\"text-center\\\"><strong>Vielen Dank f\\u00fcr Ihre Nachricht.<\\/strong><\\/h1>\\r\\n<p class=\\\"text-center\\\">Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\\r\\n<p class=\\\"text-center\\\">&nbsp;<\\/p>\\r\\n<p class=\\\"text-center\\\"><a href=\\\"t3:\\/\\/page?uid=2\\\">Zur\\u00fcck zur Homepage<\\/a><\\/p>\"}}',0,'0400$404713e84bf10df1b29ed752e952d344:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(160,1777015006,4,'BE',2,0,22,'sys_file_reference',NULL,0,'0400$a9a9f3782b892c208057e2722d4c1996:d6a5725e5b31cdd97b9c53c992e81850'),
(161,1777015006,4,'BE',2,0,19,'tt_content',NULL,0,'0400$a9a9f3782b892c208057e2722d4c1996:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(162,1777015013,1,'BE',2,0,23,'sys_file_reference','{\"pid\":10,\"tstamp\":1777015013,\"crdate\":1777015013,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"14\",\"title\":null,\"alternative\":\"Dominique Andreas Waser\",\"uid_foreign\":15,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_add_image\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":23}',0,'0400$63561c47aa7420380c6553493e0002ae:a4b81cbb471961a3c12b21861b94f4e1'),
(163,1777015013,1,'BE',2,0,20,'tt_content','{\"CType\":\"mask_info_contact_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":10,\"sorting\":128,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"Beratung und Verkauf\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":null,\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":null,\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_text_text_on_colorful_background\":null,\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"#D3D6D7\",\"tx_mask_image_on_the_right_side\":1,\"tx_mask_copy_textus\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/p>\\r\\n<p>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer Adowia<\\/p>\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_small_contact_text_below_text\":\"Zum Kontaktformular\",\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=5\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"2\",\"tx_mask_design_layout\":\"2\",\"tx_mask_content_parent_uid\":0,\"crdate\":1777015013,\"t3ver_stage\":0,\"tstamp\":1777015013,\"uid\":20}',0,'0400$7b790a4aad13e79ae2293f8e4aae427b:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(164,1777015013,2,'BE',2,0,20,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$5095fbfa7415e9f7aa353cbbf58002f9:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(165,1777015014,2,'BE',2,0,20,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$54822fbe3950dfaee65132fb064ba7e6:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(166,1777015050,2,'BE',2,0,20,'tt_content','{\"oldRecord\":{\"header\":\"Beratung und Verkauf\",\"tx_mask_copy_textus\":\"<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.<\\/p>\\r\\n<p>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer Adowia<\\/p>\",\"tx_mask_small_contact_text_below_text\":\"Zum Kontaktformular\",\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=5\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Danke f\\u00fcr Ihre Nachricht\",\"tx_mask_copy_textus\":\"<p>Vielen Dank f\\u00fcr Ihre Nachricht.<br \\/>Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\",\"tx_mask_small_contact_text_below_text\":\"Zur\\u00fcck zur Homepage\",\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=2\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_add_image\\\":\\\"\\\",\\\"tx_mask_copy_textus\\\":\\\"\\\",\\\"tx_mask_design_layout\\\":\\\"\\\",\\\"tx_mask_extra_text_right_side\\\":\\\"\\\",\\\"tx_mask_height_of_the_element\\\":\\\"\\\",\\\"tx_mask_image_on_the_right_side\\\":\\\"\\\",\\\"tx_mask_make_my_life_colorfull\\\":\\\"\\\",\\\"tx_mask_small_contact_text_below_text\\\":\\\"\\\",\\\"tx_mask_smallink_below\\\":\\\"\\\",\\\"tx_mask_text_whiteee\\\":\\\"\\\"}\"}}',0,'0400$83deadb2aefb3744667e3736eb0a9def:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(167,1777015065,2,'BE',2,0,20,'tt_content','{\"oldRecord\":{\"header\":\"Danke f\\u00fcr Ihre Nachricht\",\"tx_mask_copy_textus\":\"<p>Vielen Dank f\\u00fcr Ihre Nachricht.<br \\/>Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\"},\"newRecord\":{\"header\":\"Vielen Dank f\\u00fcr Ihre Nachricht\",\"tx_mask_copy_textus\":\"<p>Ich werde mich zeitnah bei Ihnen melden.<br \\/><br \\/>Freundliche Gr\\u00fcsse<br \\/>Dominique Andreas Waser<br \\/>Inhaber und Gesch\\u00e4ftsf\\u00fchrer<br \\/>Adowia Immobilien AG<\\/p>\"}}',0,'0400$4ad1d57ad09a3be583f9c8d7cc99e2b8:e4fcdfe5be41a63ffdd7ab7b888d9459'),
(168,1777015093,2,'BE',2,0,17,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$43d909f3b99343c88696fed1e558efb8:017157395cc6da9e5d2911de6dfd4b9e'),
(169,1777015530,2,'BE',2,0,1,'tx_powermail_domain_model_form','{\"oldRecord\":{\"css\":\"\"},\"newRecord\":{\"css\":\"nolabel\"}}',0,'0400$99c49cf3ec523813dd21488489a234df:77fadea38ee7186969949ea2d770fa93'),
(170,1777015530,2,'BE',2,0,1,'tx_powermail_domain_model_page','{\"oldRecord\":{\"css\":\"\"},\"newRecord\":{\"css\":\"nolabel\"}}',0,'0400$99c49cf3ec523813dd21488489a234df:815cca2cf067a5fe97906554dd6c4ed0'),
(171,1777015530,2,'BE',2,0,6,'tx_powermail_domain_model_field','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"css\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"marker\\\":\\\"\\\",\\\"own_marker_select\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"type\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$99c49cf3ec523813dd21488489a234df:2eac15cec105d1e4e874b103ce4be2d2'),
(172,1777018242,2,'BE',2,0,6,'tt_content','{\"oldRecord\":{\"tx_mask_bigger_text\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_bigger_text\":\"1\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_bigger_text\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"}}',0,'0400$3554fc7b9a1ac282ee43cf40fcc0996c:c0db6803ab1ec5f70c36e2a72187867b'),
(173,1777018374,1,'BE',2,0,24,'sys_file_reference','{\"pid\":4,\"tstamp\":1777018374,\"crdate\":1777018374,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"12\",\"title\":null,\"alternative\":\"konolfingen hund familie\",\"uid_foreign\":5,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_image_second_column\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":24}',0,'0400$8ebe49bd6be1ef8efef98bc8579c38a1:ec378d8e96f494986de35c9be84dff5c'),
(174,1777018374,1,'BE',2,0,21,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":768,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"tx_mask_color_first_column\":\"#F6F2EC\",\"tx_mask_text_second_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"2\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_text_text_on_colorful_background\":null,\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":null,\"tx_mask_extra_text_right_side\":null,\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_content_parent_uid\":0,\"tx_mask_bigger_text\":0,\"crdate\":1777018374,\"t3ver_stage\":0,\"tstamp\":1777018374,\"uid\":21}',0,'0400$18024b992fcf83c0a1415adfcf5c9d81:7fd72e21409e45562c51e7581fc2cb0d'),
(175,1777018374,2,'BE',2,0,21,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$d632a681fbc0864333340e9539abe7ea:7fd72e21409e45562c51e7581fc2cb0d'),
(176,1777018376,2,'BE',2,0,21,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c6372e8de478362a9f1235ca834af382:7fd72e21409e45562c51e7581fc2cb0d'),
(177,1777018490,2,'BE',2,0,21,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"2\",\"tx_mask_text_first_col\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"tx_mask_color_first_column\":\"#F6F2EC\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"1\",\"tx_mask_text_first_col\":\"<p>Nah dran nicht mittendrin genau richtig<\\/p>\",\"tx_mask_color_first_column\":\"#C7CAC5\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$4e51feaadf7a3a0161822540b76567a0:7fd72e21409e45562c51e7581fc2cb0d'),
(178,1777018490,1,'BE',2,0,25,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"18\",\"sys_language_uid\":0,\"crdate\":1777018490,\"t3ver_stage\":0,\"tstamp\":1777018490,\"uid\":25}',0,'0400$4e51feaadf7a3a0161822540b76567a0:5ce305fb03b44e2e5ced3360656e263a'),
(179,1777018490,1,'BE',2,0,26,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1777018490,\"t3ver_stage\":0,\"tstamp\":1777018490,\"uid\":26}',0,'0400$4e51feaadf7a3a0161822540b76567a0:2190384e72cbe31d01b0259338cca742'),
(180,1777018490,1,'BE',2,0,27,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1777018490,\"t3ver_stage\":0,\"tstamp\":1777018490,\"uid\":27}',0,'0400$4e51feaadf7a3a0161822540b76567a0:dd318efa0f8b108e87c8725b284b77c4'),
(181,1777018490,2,'BE',2,0,21,'tt_content','{\"oldRecord\":{\"tx_mask_height_of_the_elemnet\":\"2\",\"tx_mask_text_first_col\":\"<p>Konolfingen?<br \\/>Konolfingen.<\\/p>\",\"tx_mask_color_first_column\":\"#F6F2EC\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_height_of_the_elemnet\":\"1\",\"tx_mask_text_first_col\":\"<p>Nah dran nicht mittendrin genau richtig<\\/p>\",\"tx_mask_color_first_column\":\"#C7CAC5\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$4e51feaadf7a3a0161822540b76567a0:7fd72e21409e45562c51e7581fc2cb0d'),
(182,1777018490,4,'BE',2,0,24,'sys_file_reference',NULL,0,'0400$4e51feaadf7a3a0161822540b76567a0:ec378d8e96f494986de35c9be84dff5c'),
(183,1777019445,1,'BE',2,0,22,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":1024,\"sys_language_uid\":0,\"tx_mask_height_of_the_elemnet\":\"0\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_white_first_col\":\"0\",\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":\"<p>Alltag mit&nbsp;<br \\/>kurzen wegen<\\/p>\",\"tx_mask_text_white_second_column\":\"0\",\"tx_mask_color_second_column\":\"#48433F\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777019445,\"t3ver_stage\":0,\"tstamp\":1777019445,\"uid\":22}',0,'0400$08ed64fb1906747b26e4226aa5a0176e:1a929832156241f61c37ce68bcae4a3c'),
(184,1777019445,1,'BE',2,0,28,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"21\",\"sys_language_uid\":0,\"crdate\":1777019445,\"t3ver_stage\":0,\"tstamp\":1777019445,\"uid\":28}',0,'0400$08ed64fb1906747b26e4226aa5a0176e:59425f1ffdef0b99239b8bcfbe5ba5e9'),
(185,1777019445,1,'BE',2,0,29,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"19\",\"sys_language_uid\":0,\"crdate\":1777019445,\"t3ver_stage\":0,\"tstamp\":1777019445,\"uid\":29}',0,'0400$08ed64fb1906747b26e4226aa5a0176e:b242d4aecdf71ef1fd418f92b6b759e2'),
(186,1777019445,1,'BE',2,0,30,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"20\",\"sys_language_uid\":0,\"crdate\":1777019445,\"t3ver_stage\":0,\"tstamp\":1777019445,\"uid\":30}',0,'0400$08ed64fb1906747b26e4226aa5a0176e:8567b700a7babdbf06fe14b610c41b11'),
(187,1777019554,2,'BE',2,0,22,'tt_content','{\"oldRecord\":{\"tx_mask_text_white_second_column\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"tx_mask_text_white_second_column\":\"1\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$72db4dcf3fbe50a1418dfdf0ebc42de5:1a929832156241f61c37ce68bcae4a3c'),
(188,1777019554,2,'BE',2,0,28,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$72db4dcf3fbe50a1418dfdf0ebc42de5:59425f1ffdef0b99239b8bcfbe5ba5e9'),
(189,1777019554,2,'BE',2,0,29,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$72db4dcf3fbe50a1418dfdf0ebc42de5:b242d4aecdf71ef1fd418f92b6b759e2'),
(190,1777019554,2,'BE',2,0,30,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$72db4dcf3fbe50a1418dfdf0ebc42de5:8567b700a7babdbf06fe14b610c41b11'),
(191,1777019775,1,'BE',2,0,23,'tt_content','{\"CType\":\"mask_simple_image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":896,\"sys_language_uid\":0,\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777019775,\"t3ver_stage\":0,\"tstamp\":1777019775,\"uid\":23}',0,'0400$360052929091eced651f45d287275907:0cf00ee1adffc41f8b3231c0de35256e'),
(192,1777019775,1,'BE',2,0,31,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"22\",\"sys_language_uid\":0,\"crdate\":1777019775,\"t3ver_stage\":0,\"tstamp\":1777019775,\"uid\":31}',0,'0400$360052929091eced651f45d287275907:a49807a2b4589c06cba1b54ee8ff5b0b'),
(193,1777019775,1,'BE',2,0,32,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":4,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"23\",\"sys_language_uid\":0,\"crdate\":1777019775,\"t3ver_stage\":0,\"tstamp\":1777019775,\"uid\":32}',0,'0400$360052929091eced651f45d287275907:39d48e4eee405666728355d4f43660d5'),
(194,1777019783,2,'BE',2,0,23,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_simple_image_class\\\":\\\"\\\"}\"}}',0,'0400$6d6ca34bf0af819c58d5fdd152a08ec8:0cf00ee1adffc41f8b3231c0de35256e'),
(195,1777019783,2,'BE',2,0,31,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$6d6ca34bf0af819c58d5fdd152a08ec8:a49807a2b4589c06cba1b54ee8ff5b0b'),
(196,1777019783,2,'BE',2,0,32,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$6d6ca34bf0af819c58d5fdd152a08ec8:39d48e4eee405666728355d4f43660d5'),
(197,1777019838,1,'BE',2,0,24,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":960,\"sys_language_uid\":0,\"tx_mask_color_of_the_lement\":\"#F6F2EC\",\"header\":\"\",\"tx_mask_text_text_on_colorful_background\":\"<p>Vorteile von Konolfingen als Wohnort dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_text_to_link\":\"\",\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"3\",\"tx_mask_bigger_text\":\"0\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777019838,\"t3ver_stage\":0,\"tstamp\":1777019838,\"uid\":24}',0,'0400$47896b4c3f3ff7b3b2b4b331440944cf:94bb7a1dbcc4ac71f45ee11546313fe2'),
(198,1777019879,1,'BE',2,0,25,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":1280,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":null,\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":null,\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"#F6F2EC\",\"tx_mask_text_text_on_colorful_background\":\"<p>Vorteile von Konolfingen als Wohnort dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"3\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":null,\"tx_mask_extra_text_right_side\":null,\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_content_parent_uid\":0,\"tx_mask_bigger_text\":0,\"crdate\":1777019879,\"t3ver_stage\":0,\"tstamp\":1777019879,\"uid\":25}',0,'0400$18d0a6437ab0a752910db2a60d8f42f2:581bf77acde559fe457e0d401d2ada7b'),
(199,1777019879,2,'BE',2,0,25,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$01e4c3161aeeb01f3206d8d12678a5ca:581bf77acde559fe457e0d401d2ada7b'),
(200,1777019883,2,'BE',2,0,25,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$765b00b6d3fc31a129d1cbd0941f9c81:581bf77acde559fe457e0d401d2ada7b'),
(201,1777019892,2,'BE',2,0,25,'tt_content','{\"oldRecord\":{\"header\":\"\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"header\":\"Optimale  Verkehrsanbindungen\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_bigger_text\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"}}',0,'0400$acd25fdb5154d33f634b7a59baa39a2e:581bf77acde559fe457e0d401d2ada7b'),
(202,1777020049,2,'BE',2,0,25,'tt_content','{\"oldRecord\":{\"tx_mask_text_instead_of_button\":null,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_bigger_text\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_text_instead_of_button\":\"<p>20 min. nach Thun<br \\/>20 min. nach Burgdorf<br \\/>25 min. nach Bern<\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_bigger_text\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_instead_of_button\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"}}',0,'0400$56d936609b9fe8961b00e83a81481ee4:581bf77acde559fe457e0d401d2ada7b'),
(203,1777020490,1,'BE',2,0,26,'tt_content','{\"CType\":\"mask_simple_image\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":3,\"sorting\":384,\"sys_language_uid\":0,\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777020490,\"t3ver_stage\":0,\"tstamp\":1777020490,\"uid\":26}',0,'0400$f1b9ad9e32a448fdc91a9c44b2891283:f6bb218c440a87df0e0eb5986e28af41'),
(204,1777020490,1,'BE',2,0,33,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"8\",\"sys_language_uid\":0,\"crdate\":1777020490,\"t3ver_stage\":0,\"tstamp\":1777020490,\"uid\":33}',0,'0400$f1b9ad9e32a448fdc91a9c44b2891283:d1a319dd1808a8a7d690531c136ea304'),
(205,1777020618,1,'BE',2,0,27,'tt_content','{\"CType\":\"mask_text_on_colorful_background\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":3,\"sorting\":256,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":null,\"tx_mask_color_first_column\":\"\",\"tx_mask_text_second_column\":null,\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"#F6F2EC\",\"tx_mask_text_text_on_colorful_background\":\"<p>Vorteile von Konolfingen als Wohnort dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;<\\/p>\",\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"3\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":null,\"tx_mask_extra_text_right_side\":null,\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_content_parent_uid\":0,\"tx_mask_bigger_text\":0,\"tx_mask_text_instead_of_button\":null,\"crdate\":1777020618,\"t3ver_stage\":0,\"tstamp\":1777020618,\"uid\":27}',0,'0400$66c90dd8ec821045298d0e901d77080d:9c3671c42eb2c0522de6952ddc52c9a7'),
(206,1777020618,2,'BE',2,0,27,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$ef1b49f319a4a86c5a0e4e70735d8e41:9c3671c42eb2c0522de6952ddc52c9a7'),
(207,1777020620,2,'BE',2,0,27,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$7eb35fd93b95a69ec8533cada7fc70e0:9c3671c42eb2c0522de6952ddc52c9a7'),
(208,1777020637,2,'BE',2,0,27,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_bigger_text\\\":\\\"\\\",\\\"tx_mask_color_of_the_lement\\\":\\\"\\\",\\\"tx_mask_layout_choose\\\":\\\"\\\",\\\"tx_mask_link\\\":\\\"\\\",\\\"tx_mask_text_instead_of_button\\\":\\\"\\\",\\\"tx_mask_text_text_on_colorful_background\\\":\\\"\\\",\\\"tx_mask_text_to_link\\\":\\\"\\\"}\"}}',0,'0400$cc8cd46ced8ca244a658f5461d341d2a:9c3671c42eb2c0522de6952ddc52c9a7'),
(209,1777020957,1,'BE',2,0,34,'sys_file_reference','{\"pid\":3,\"tstamp\":1777020957,\"crdate\":1777020957,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"18\",\"title\":null,\"alternative\":null,\"uid_foreign\":21,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_image_second_column\",\"sorting_foreign\":1,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":34}',0,'0400$9b3d1c2577c6efcf3f531b000343a78f:305d1fe50c2aa1143642eca6940718b4'),
(210,1777020957,1,'BE',2,0,35,'sys_file_reference','{\"pid\":3,\"tstamp\":1777020957,\"crdate\":1777020957,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"19\",\"title\":null,\"alternative\":null,\"uid_foreign\":21,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_image_second_column\",\"sorting_foreign\":2,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":35}',0,'0400$9b3d1c2577c6efcf3f531b000343a78f:64261f0ce2585a14a29aa5c2ee36ec50'),
(211,1777020957,1,'BE',2,0,36,'sys_file_reference','{\"pid\":3,\"tstamp\":1777020957,\"crdate\":1777020957,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":\"20\",\"title\":null,\"alternative\":null,\"uid_foreign\":21,\"tablenames\":\"tt_content\",\"fieldname\":\"tx_mask_image_second_column\",\"sorting_foreign\":3,\"link\":\"\",\"description\":null,\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"uid\":36}',0,'0400$9b3d1c2577c6efcf3f531b000343a78f:bbbca4ca3aa54248c26ce1e6a7ce7d5d'),
(212,1777020957,1,'BE',2,0,28,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":3,\"sorting\":192,\"fe_group\":\"\",\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_source\":0,\"l10n_state\":null,\"table_caption\":null,\"tx_impexp_origuid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":null,\"imageborder\":0,\"image_zoom\":0,\"pages\":\"\",\"records\":\"\",\"linkToTop\":0,\"pi_flexform\":null,\"selected_categories\":0,\"category_field\":\"\",\"file_collections\":\"\",\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"tx_mask_text_first_col\":\"<p>Nah dran nicht mittendrin genau richtig<\\/p>\",\"tx_mask_color_first_column\":\"#C7CAC5\",\"tx_mask_text_second_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"1\",\"tx_mask_text_white_first_col\":0,\"tx_mask_text_white_second_column\":0,\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_text_text_on_colorful_background\":null,\"tx_mask_link\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_text_to_link\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_image_on_the_right_side\":0,\"tx_mask_copy_textus\":null,\"tx_mask_extra_text_right_side\":null,\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":0,\"tx_mask_height_of_the_element\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_content_parent_uid\":0,\"tx_mask_bigger_text\":0,\"tx_mask_text_instead_of_button\":null,\"crdate\":1777020957,\"t3ver_stage\":0,\"tstamp\":1777020957,\"uid\":28}',0,'0400$414a33fcdf1ebbe73c66d87c0b473294:b5d015227f2b36f7786e2ff963ca9d51'),
(213,1777020957,2,'BE',2,0,28,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"}}',0,'0400$a2e34ced438bce057c15276b886d470f:b5d015227f2b36f7786e2ff963ca9d51'),
(214,1777020964,2,'BE',2,0,28,'tt_content','{\"oldRecord\":{\"hidden\":1,\"l18n_diffsource\":\"{\\\"colPos\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$093beaa725578e1659cf24be33ad6320:b5d015227f2b36f7786e2ff963ca9d51'),
(215,1777021071,2,'BE',2,0,28,'tt_content','{\"oldRecord\":{\"tx_mask_text_first_col\":\"<p>Nah dran nicht mittendrin genau richtig<\\/p>\",\"tx_mask_color_first_column\":\"#C7CAC5\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_text_first_col\":\"<p>Keller und&nbsp;<br \\/>einstellhallenpl\\u00e4tze<\\/p>\",\"tx_mask_color_first_column\":\"#D9D0C8\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$66eaaf3040c53f8de25e92d6f32d880d:b5d015227f2b36f7786e2ff963ca9d51'),
(216,1777021071,1,'BE',2,0,37,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"24\",\"sys_language_uid\":0,\"crdate\":1777021071,\"t3ver_stage\":0,\"tstamp\":1777021071,\"uid\":37}',0,'0400$66eaaf3040c53f8de25e92d6f32d880d:e1ca626f78bf3a5c2eeb7d40b085ddff'),
(217,1777021071,2,'BE',2,0,28,'tt_content','{\"oldRecord\":{\"tx_mask_text_first_col\":\"<p>Nah dran nicht mittendrin genau richtig<\\/p>\",\"tx_mask_color_first_column\":\"#C7CAC5\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_text_first_col\":\"<p>Keller und&nbsp;<br \\/>einstellhallenpl\\u00e4tze<\\/p>\",\"tx_mask_color_first_column\":\"#D9D0C8\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$66eaaf3040c53f8de25e92d6f32d880d:b5d015227f2b36f7786e2ff963ca9d51'),
(218,1777021071,4,'BE',2,0,36,'sys_file_reference',NULL,0,'0400$66eaaf3040c53f8de25e92d6f32d880d:bbbca4ca3aa54248c26ce1e6a7ce7d5d'),
(219,1777021071,4,'BE',2,0,35,'sys_file_reference',NULL,0,'0400$66eaaf3040c53f8de25e92d6f32d880d:64261f0ce2585a14a29aa5c2ee36ec50'),
(220,1777021071,4,'BE',2,0,34,'sys_file_reference',NULL,0,'0400$66eaaf3040c53f8de25e92d6f32d880d:305d1fe50c2aa1143642eca6940718b4'),
(221,1777021078,2,'BE',2,0,37,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$25ebde64f60f407dfa36b39ebcc0fc3c:e1ca626f78bf3a5c2eeb7d40b085ddff'),
(222,1777021694,2,'BE',2,0,15,'tt_content','{\"oldRecord\":{\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=5\"},\"newRecord\":{\"tx_mask_smallink_below\":\"t3:\\/\\/page?uid=5#here-16\"}}',0,'0400$bc516aaed8c2bc6d7d7f485cd3259c7f:cb118fde3da18e67b21a92b60bb8cbda'),
(223,1777021808,2,'BE',2,0,17,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$a650f1ae9bbde7a6a98e2ac8a3204bfa:017157395cc6da9e5d2911de6dfd4b9e'),
(224,1777021808,1,'BE',2,0,38,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":\"Konoflingen\",\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":5,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"17\",\"sys_language_uid\":0,\"crdate\":1777021808,\"t3ver_stage\":0,\"tstamp\":1777021808,\"uid\":38}',0,'0400$a650f1ae9bbde7a6a98e2ac8a3204bfa:c5d124145c563e90db4b312b017e10a7'),
(225,1777021808,4,'BE',2,0,21,'sys_file_reference',NULL,0,'0400$a650f1ae9bbde7a6a98e2ac8a3204bfa:bd8e6a36b477d61e04d92cfd10d00f96'),
(226,1777021813,2,'BE',2,0,38,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$14b2208b06a6eb335978e93ceb3770be:c5d124145c563e90db4b312b017e10a7'),
(227,1777021856,1,'BE',2,0,39,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":5,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"25\",\"sys_language_uid\":0,\"crdate\":1777021856,\"t3ver_stage\":0,\"tstamp\":1777021856,\"uid\":39}',0,'0400$ce628b8a24470c8c081883dcfc1d70e2:e4ab59ae42d0e2e224b589caed52ad80'),
(228,1777021856,4,'BE',2,0,38,'sys_file_reference',NULL,0,'0400$ce628b8a24470c8c081883dcfc1d70e2:c5d124145c563e90db4b312b017e10a7'),
(229,1777024292,1,'BE',2,0,29,'tt_content','{\"CType\":\"mask_location_map\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":4,\"sorting\":1536,\"sys_language_uid\":0,\"header\":\"Map\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777024292,\"t3ver_stage\":0,\"tstamp\":1777024292,\"uid\":29}',0,'0400$e9031df151d753d3f39455eaf70949c3:12090f8e2b698e14ec860eca10ce232c'),
(230,1777024292,1,'BE',2,0,1,'tx_mask_tabs_map','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":256,\"tx_mask_titel\":\"\\u00d6V\",\"tx_mask_key\":\"1\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_key\\\":\\\"\\\",\\\"tx_mask_titel\\\":\\\"\\\"}\",\"crdate\":1777024292,\"t3ver_stage\":0,\"tstamp\":1777024292,\"uid\":1}',0,'0400$e9031df151d753d3f39455eaf70949c3:7067de7a8ab8d5e7d4c810b3fea9aee4'),
(231,1777024292,1,'BE',2,0,2,'tx_mask_tabs_map','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":128,\"tx_mask_titel\":\"Schulen\",\"tx_mask_key\":\"2\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_key\\\":\\\"\\\",\\\"tx_mask_titel\\\":\\\"\\\"}\",\"crdate\":1777024292,\"t3ver_stage\":0,\"tstamp\":1777024292,\"uid\":2}',0,'0400$e9031df151d753d3f39455eaf70949c3:b5961aa9e3efd685cb558f04f64320c7'),
(232,1777024292,1,'BE',2,0,3,'tx_mask_tabs_map','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":64,\"tx_mask_titel\":\"Einkaufen\",\"tx_mask_key\":\"3\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_key\\\":\\\"\\\",\\\"tx_mask_titel\\\":\\\"\\\"}\",\"crdate\":1777024292,\"t3ver_stage\":0,\"tstamp\":1777024292,\"uid\":3}',0,'0400$e9031df151d753d3f39455eaf70949c3:61c937d378a07929a6dadbee49c54ef0'),
(233,1777024292,1,'BE',2,0,4,'tx_mask_tabs_map','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":32,\"tx_mask_titel\":\"Gesundheit\",\"tx_mask_key\":\"4\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_key\\\":\\\"\\\",\\\"tx_mask_titel\\\":\\\"\\\"}\",\"crdate\":1777024292,\"t3ver_stage\":0,\"tstamp\":1777024292,\"uid\":4}',0,'0400$e9031df151d753d3f39455eaf70949c3:a93c8b27a5a4361e6a475d25295733c0'),
(234,1777024292,1,'BE',2,0,1,'tx_mask_places','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":256,\"tx_mask_titel_place\":\"Bahnhof Konolfingen\",\"tx_mask_category\":\"1\",\"tx_mask_latitude\":\"46.88\",\"tx_mask_longitude\":\"7.62\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\",\"crdate\":1777024292,\"t3ver_stage\":0,\"tstamp\":1777024292,\"uid\":1}',0,'0400$e9031df151d753d3f39455eaf70949c3:01e66f5547336aa1b48b5683f7e0c7bf'),
(235,1777024495,2,'BE',2,0,29,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_places\\\":\\\"\\\",\\\"tx_mask_tabs_map\\\":\\\"\\\"}\"}}',0,'0400$1e7d6bbcc06952c0e70b3a5d7c7c8777:12090f8e2b698e14ec860eca10ce232c'),
(236,1777024495,2,'BE',2,0,1,'tx_mask_tabs_map','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_key\\\":\\\"\\\",\\\"tx_mask_titel\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$1e7d6bbcc06952c0e70b3a5d7c7c8777:7067de7a8ab8d5e7d4c810b3fea9aee4'),
(237,1777024495,2,'BE',2,0,2,'tx_mask_tabs_map','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_key\\\":\\\"\\\",\\\"tx_mask_titel\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$1e7d6bbcc06952c0e70b3a5d7c7c8777:b5961aa9e3efd685cb558f04f64320c7'),
(238,1777024495,2,'BE',2,0,3,'tx_mask_tabs_map','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_key\\\":\\\"\\\",\\\"tx_mask_titel\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$1e7d6bbcc06952c0e70b3a5d7c7c8777:61c937d378a07929a6dadbee49c54ef0'),
(239,1777024495,2,'BE',2,0,4,'tx_mask_tabs_map','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_key\\\":\\\"\\\",\\\"tx_mask_titel\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$1e7d6bbcc06952c0e70b3a5d7c7c8777:a93c8b27a5a4361e6a475d25295733c0'),
(240,1777024495,2,'BE',2,0,1,'tx_mask_places','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$1e7d6bbcc06952c0e70b3a5d7c7c8777:01e66f5547336aa1b48b5683f7e0c7bf'),
(241,1777024495,1,'BE',2,0,2,'tx_mask_places','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":0,\"tx_mask_titel_place\":\"Coop Supermarkt\",\"tx_mask_category\":\"3\",\"tx_mask_latitude\":\"46.88\",\"tx_mask_longitude\":\"7.62\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\",\"crdate\":1777024495,\"t3ver_stage\":0,\"tstamp\":1777024495,\"uid\":2}',0,'0400$1e7d6bbcc06952c0e70b3a5d7c7c8777:703e110ee6258f8f470574623ef28f3d'),
(242,1777024495,2,'BE',2,0,29,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_places\\\":\\\"\\\",\\\"tx_mask_tabs_map\\\":\\\"\\\"}\"}}',0,'0400$1e7d6bbcc06952c0e70b3a5d7c7c8777:12090f8e2b698e14ec860eca10ce232c'),
(243,1777024803,2,'BE',2,0,2,'tx_mask_places','{\"oldRecord\":{\"tx_mask_latitude\":\"46.88\",\"tx_mask_longitude\":\"7.62\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_latitude\":\"46.88116788005828\",\"tx_mask_longitude\":\"7.624048731683577\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"}}',0,'0400$34fa4e2d7f40fe93e0a0e9ef91e0dbb9:703e110ee6258f8f470574623ef28f3d'),
(244,1777028828,1,'BE',2,0,3,'tx_mask_places','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":0,\"tx_mask_titel_place\":\"Kindergarten Sonnrain\",\"tx_mask_category\":\"2\",\"tx_mask_latitude\":\"46.88292614710495\",\"tx_mask_longitude\":\"7.620393855262057\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\",\"crdate\":1777028828,\"t3ver_stage\":0,\"tstamp\":1777028828,\"uid\":3}',0,'0400$18a464f7178429356191b34ace382d10:f9a0927f513a7d434036b768812acae5'),
(245,1777028865,2,'BE',2,0,2,'tx_mask_places','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$9d928efc9011f0975b50044a1efe4aa0:703e110ee6258f8f470574623ef28f3d'),
(246,1777028865,2,'BE',2,0,3,'tx_mask_places','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"}}',0,'0400$9d928efc9011f0975b50044a1efe4aa0:f9a0927f513a7d434036b768812acae5'),
(247,1777028865,1,'BE',2,0,4,'tx_mask_places','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":0,\"tx_mask_titel_place\":\"Dropa Apotheke Konolfingen\",\"tx_mask_category\":\"4\",\"tx_mask_latitude\":\"46.8761761744072\",\"tx_mask_longitude\":\"7.6209579421116445\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\",\"crdate\":1777028865,\"t3ver_stage\":0,\"tstamp\":1777028865,\"uid\":4}',0,'0400$9d928efc9011f0975b50044a1efe4aa0:4f48ec5dcc6f153facd0869aec08021c'),
(248,1777028903,2,'BE',2,0,3,'tx_mask_places','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$5809cadf700dda48119017e178a6ec94:f9a0927f513a7d434036b768812acae5'),
(249,1777028903,2,'BE',2,0,4,'tx_mask_places','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\"}}',0,'0400$5809cadf700dda48119017e178a6ec94:4f48ec5dcc6f153facd0869aec08021c'),
(250,1777028903,1,'BE',2,0,5,'tx_mask_places','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":4,\"sorting\":0,\"tx_mask_titel_place\":\"Dr. med. Imholz Beat\",\"tx_mask_category\":\"4\",\"tx_mask_latitude\":\"46.87763226213031\",\"tx_mask_longitude\":\"7.620187670100313\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_category\\\":\\\"\\\",\\\"tx_mask_latitude\\\":\\\"\\\",\\\"tx_mask_longitude\\\":\\\"\\\",\\\"tx_mask_titel_place\\\":\\\"\\\"}\",\"crdate\":1777028903,\"t3ver_stage\":0,\"tstamp\":1777028903,\"uid\":5}',0,'0400$5809cadf700dda48119017e178a6ec94:60c9c3a7fc7676f84233c8972ddfeaac'),
(251,1777029480,1,'BE',2,0,30,'tt_content','{\"CType\":\"mask_two_columns\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":448,\"sys_language_uid\":0,\"tx_mask_height_of_the_elemnet\":\"2\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_white_first_col\":\"0\",\"tx_mask_color_first_column\":\"#E1DCD7\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_second_column\":\"0\",\"tx_mask_color_second_column\":\"\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777029480,\"t3ver_stage\":0,\"tstamp\":1777029480,\"uid\":30}',0,'0400$cfbcb2be4c953d0d948930184c1b81d3:f6d670f6f6a9a0aecc0bb542c370acdf'),
(252,1777029480,1,'BE',2,0,40,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":2,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"24\",\"sys_language_uid\":0,\"crdate\":1777029480,\"t3ver_stage\":0,\"tstamp\":1777029480,\"uid\":40}',0,'0400$cfbcb2be4c953d0d948930184c1b81d3:2366ea13aeaa959ba384cfd90a0ef3e8'),
(253,1777029811,2,'BE',2,0,30,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$378555e5b517167f877c2f90bebd50e6:f6d670f6f6a9a0aecc0bb542c370acdf'),
(254,1777029811,1,'BE',2,0,31,'tt_content','{\"CType\":\"mask_akkordeon\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"999\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":2,\"sorting\":64,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"main\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.main.form\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.confirmation\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.optin\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.moresteps\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.main.pid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"receiver\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.receiver.type\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.name\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.email\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.subject\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.receiver.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"sender\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.sender.name\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.email\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.subject\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.sender.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"thx\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.flexform.thx.body\\\">\\n                    <value index=\\\"vDEF\\\">&lt;p&gt;{powermail_all}&lt;\\/p&gt;<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.flexform.thx.redirect\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"sys_language_uid\":0,\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777029811,\"t3ver_stage\":0,\"tstamp\":1777029811,\"uid\":31}',0,'0400$378555e5b517167f877c2f90bebd50e6:a338b89fc8d0d789df4b1fd4d37a174b'),
(255,1777029811,2,'BE',2,0,40,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$378555e5b517167f877c2f90bebd50e6:2366ea13aeaa959ba384cfd90a0ef3e8'),
(256,1777029811,2,'BE',2,0,30,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_color_first_column\\\":\\\"\\\",\\\"tx_mask_color_second_column\\\":\\\"\\\",\\\"tx_mask_content_second_column\\\":\\\"\\\",\\\"tx_mask_height_of_the_elemnet\\\":\\\"\\\",\\\"tx_mask_image_first_column\\\":\\\"\\\",\\\"tx_mask_image_second_column\\\":\\\"\\\",\\\"tx_mask_text_first_col\\\":\\\"\\\",\\\"tx_mask_text_second_column\\\":\\\"\\\",\\\"tx_mask_text_white_first_col\\\":\\\"\\\",\\\"tx_mask_text_white_second_column\\\":\\\"\\\"}\"}}',0,'0400$378555e5b517167f877c2f90bebd50e6:f6d670f6f6a9a0aecc0bb542c370acdf'),
(257,1777029875,2,'BE',2,0,31,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_accordion_with_data\\\":\\\"\\\"}\"}}',0,'0400$25d1e309e5728f46dbeba86d519c7078:a338b89fc8d0d789df4b1fd4d37a174b'),
(258,1777029875,1,'BE',2,0,1,'tx_mask_accordion_with_data','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":2,\"sorting\":256,\"tx_mask_text_accordeon\":\"<p>Text \\u00fcber H\\u00e4user sit amet, consetetur sadipsc elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diamren voluptua. At vero eos et accusam et justo duolire dolores et ea rebum. Stet clita kasd gubergren, aus sea takimata sanctus est.<\\/p>\\r\\n<p><br \\/><a href=\\\"t3:\\/\\/page?uid=3\\\">H\\u00e4user ansehen<\\/a><\\/p>\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_text_accordeon\\\":\\\"\\\"}\",\"crdate\":1777029875,\"t3ver_stage\":0,\"tstamp\":1777029875,\"uid\":1}',0,'0400$25d1e309e5728f46dbeba86d519c7078:7aff1fd1636532bce1f05a68a71c5fe9'),
(259,1777029875,2,'BE',2,0,31,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_accordion_with_data\\\":\\\"\\\"}\"}}',0,'0400$25d1e309e5728f46dbeba86d519c7078:a338b89fc8d0d789df4b1fd4d37a174b'),
(260,1777029939,2,'BE',2,0,1,'tx_mask_accordion_with_data','{\"oldRecord\":{\"tx_mask_title_of_the_immo\":\"\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_text_accordeon\\\":\\\"\\\"}\"},\"newRecord\":{\"tx_mask_title_of_the_immo\":\"Haus\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_text_accordeon\\\":\\\"\\\",\\\"tx_mask_title_of_the_immo\\\":\\\"\\\"}\"}}',0,'0400$ba485194a19456bf4cbd64b9c1cbd455:7aff1fd1636532bce1f05a68a71c5fe9'),
(261,1777029939,1,'BE',2,0,2,'tx_mask_accordion_with_data','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":2,\"sorting\":0,\"tx_mask_title_of_the_immo\":\"GARTENWOHNUNG\",\"tx_mask_text_accordeon\":\"<p>Text \\u00fcber H\\u00e4user sit amet, consetetur sadipsc elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diamren voluptua. At vero eos et accusam et justo duolire dolores et ea rebum. Stet clita kasd gubergren, aus sea takimata sanctus est.<\\/p>\\r\\n<p><br \\/><a href=\\\"t3:\\/\\/page?uid=3\\\">H\\u00e4user ansehen<\\/a><\\/p>\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_text_accordeon\\\":\\\"\\\",\\\"tx_mask_title_of_the_immo\\\":\\\"\\\"}\",\"crdate\":1777029939,\"t3ver_stage\":0,\"tstamp\":1777029939,\"uid\":2}',0,'0400$ba485194a19456bf4cbd64b9c1cbd455:17e3e5ccf79b9d066111f4c7ca09f29d'),
(262,1777029939,1,'BE',2,0,3,'tx_mask_accordion_with_data','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":2,\"sorting\":256,\"tx_mask_title_of_the_immo\":\"TERASSENWOHNUNG\",\"tx_mask_text_accordeon\":\"<p>Text \\u00fcber H\\u00e4user sit amet, consetetur sadipsc elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diamren voluptua. At vero eos et accusam et justo duolire dolores et ea rebum. Stet clita kasd gubergren, aus sea takimata sanctus est.<\\/p>\\r\\n<p><br \\/><a href=\\\"t3:\\/\\/page?uid=3\\\">H\\u00e4user ansehen<\\/a><\\/p>\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_text_accordeon\\\":\\\"\\\",\\\"tx_mask_title_of_the_immo\\\":\\\"\\\"}\",\"crdate\":1777029939,\"t3ver_stage\":0,\"tstamp\":1777029939,\"uid\":3}',0,'0400$ba485194a19456bf4cbd64b9c1cbd455:fa9f551da2dee9ee4788db8d08ed3642'),
(263,1777029948,2,'BE',2,0,1,'tx_mask_accordion_with_data','{\"oldRecord\":{\"tx_mask_title_of_the_immo\":\"Haus\"},\"newRecord\":{\"tx_mask_title_of_the_immo\":\"HAUS\"}}',0,'0400$0b47e6e0249ef62ae5508c95041f9866:7aff1fd1636532bce1f05a68a71c5fe9'),
(264,1777029948,2,'BE',2,0,2,'tx_mask_accordion_with_data','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_text_accordeon\\\":\\\"\\\",\\\"tx_mask_title_of_the_immo\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$0b47e6e0249ef62ae5508c95041f9866:17e3e5ccf79b9d066111f4c7ca09f29d'),
(265,1777029948,2,'BE',2,0,3,'tx_mask_accordion_with_data','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_text_accordeon\\\":\\\"\\\",\\\"tx_mask_title_of_the_immo\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$0b47e6e0249ef62ae5508c95041f9866:fa9f551da2dee9ee4788db8d08ed3642'),
(266,1777029973,2,'BE',2,0,30,'tt_content','{\"oldRecord\":{\"tx_mask_color_second_column\":\"\"},\"newRecord\":{\"tx_mask_color_second_column\":\"#E1DCD7\"}}',0,'0400$083ef2cce40104dcfcbe4927aa3b7623:f6d670f6f6a9a0aecc0bb542c370acdf'),
(267,1777121599,1,'BE',2,0,32,'tt_content','{\"CType\":\"mask_apartments\",\"categories\":\"0\",\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"colPos\":\"0\",\"date\":0,\"header_layout\":\"0\",\"header_position\":\"\",\"imagewidth\":0,\"imageheight\":0,\"imageorient\":\"0\",\"imagecols\":\"2\",\"recursive\":\"0\",\"list_type\":\"\",\"sectionIndex\":\"1\",\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"l18n_parent\":0,\"l18n_diffsource\":\"\",\"bullets_type\":\"0\",\"cols\":\"0\",\"table_class\":\"\",\"table_delimiter\":\"124\",\"table_enclosure\":\"0\",\"table_header_position\":\"0\",\"table_tfoot\":0,\"target\":\"\",\"uploads_description\":0,\"uploads_type\":\"0\",\"pid\":3,\"sorting\":160,\"sys_language_uid\":0,\"header\":\"Wohnungen\",\"linkToTop\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"rowDescription\":\"\",\"crdate\":1777121599,\"t3ver_stage\":0,\"tstamp\":1777121599,\"uid\":32}',0,'0400$d895982663111667d2877de34741d9fb:eeb3ef2adec88a8b5b3e3c510b74be1d'),
(268,1777121599,1,'BE',2,0,1,'tx_mask_apartments','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":3,\"sorting\":256,\"tx_mask_number\":\"56.01.1\",\"tx_mask_floor\":\"0\",\"tx_mask_rooms\":\"3.5\",\"tx_mask_area\":\"98.01\",\"tx_mask_outside_area\":\"40\",\"tx_mask_status\":\"0\",\"tx_mask_unit_key\":\"56011\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\",\"crdate\":1777121599,\"t3ver_stage\":0,\"tstamp\":1777121599,\"uid\":1}',0,'0400$d895982663111667d2877de34741d9fb:53717f01f9ea26bb86522d46c5e1bd19'),
(269,1777121599,1,'BE',2,0,41,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1777121599,\"t3ver_stage\":0,\"tstamp\":1777121599,\"uid\":41}',0,'0400$d895982663111667d2877de34741d9fb:19c8584dd5bba095e1e9e14d48d2bbbf'),
(270,1777121648,2,'BE',2,0,32,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_apartments\\\":\\\"\\\"}\"}}',0,'0400$bf7190bbfc165dce16d3a4c812b49272:eeb3ef2adec88a8b5b3e3c510b74be1d'),
(271,1777121648,2,'BE',2,0,1,'tx_mask_apartments','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"}}',0,'0400$bf7190bbfc165dce16d3a4c812b49272:53717f01f9ea26bb86522d46c5e1bd19'),
(272,1777121648,1,'BE',2,0,2,'tx_mask_apartments','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":3,\"sorting\":0,\"tx_mask_number\":\"56.01.2\",\"tx_mask_floor\":\"0\",\"tx_mask_rooms\":\"3.5\",\"tx_mask_area\":\"40\",\"tx_mask_outside_area\":\"120\",\"tx_mask_status\":\"0\",\"tx_mask_unit_key\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\",\"crdate\":1777121648,\"t3ver_stage\":0,\"tstamp\":1777121648,\"uid\":2}',0,'0400$bf7190bbfc165dce16d3a4c812b49272:2cc4dfebfce55c25364468dc1ef254ad'),
(273,1777121648,2,'BE',2,0,41,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$bf7190bbfc165dce16d3a4c812b49272:19c8584dd5bba095e1e9e14d48d2bbbf'),
(274,1777121648,1,'BE',2,0,42,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1777121648,\"t3ver_stage\":0,\"tstamp\":1777121648,\"uid\":42}',0,'0400$bf7190bbfc165dce16d3a4c812b49272:7a5b44578f910fd982a3ce6fc61d2bbf'),
(275,1777121648,2,'BE',2,0,32,'tt_content','{\"oldRecord\":{\"l18n_diffsource\":\"\"},\"newRecord\":{\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_apartments\\\":\\\"\\\"}\"}}',0,'0400$bf7190bbfc165dce16d3a4c812b49272:eeb3ef2adec88a8b5b3e3c510b74be1d'),
(276,1777121695,2,'BE',2,0,1,'tx_mask_apartments','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$5d462e7e2f0240a222203a374ad9944b:53717f01f9ea26bb86522d46c5e1bd19'),
(277,1777121695,2,'BE',2,0,2,'tx_mask_apartments','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$5d462e7e2f0240a222203a374ad9944b:2cc4dfebfce55c25364468dc1ef254ad'),
(278,1777121695,1,'BE',2,0,3,'tx_mask_apartments','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":3,\"sorting\":0,\"tx_mask_number\":\"56.01.3\",\"tx_mask_floor\":\"0\",\"tx_mask_rooms\":\"3.5\",\"tx_mask_area\":\"49\",\"tx_mask_outside_area\":\"120\",\"tx_mask_status\":\"0\",\"tx_mask_unit_key\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\",\"crdate\":1777121695,\"t3ver_stage\":0,\"tstamp\":1777121695,\"uid\":3}',0,'0400$5d462e7e2f0240a222203a374ad9944b:1ad1cb62133673237a8e2c751f381073'),
(279,1777121695,1,'BE',2,0,4,'tx_mask_apartments','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":3,\"sorting\":256,\"tx_mask_number\":\"56.01.4\",\"tx_mask_floor\":\"0\",\"tx_mask_rooms\":\"4.5\",\"tx_mask_area\":\"120\",\"tx_mask_outside_area\":\"230\",\"tx_mask_status\":\"0\",\"tx_mask_unit_key\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\",\"crdate\":1777121695,\"t3ver_stage\":0,\"tstamp\":1777121695,\"uid\":4}',0,'0400$5d462e7e2f0240a222203a374ad9944b:76188b6140e685118edbf332247bc58a'),
(280,1777121695,1,'BE',2,0,43,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1777121695,\"t3ver_stage\":0,\"tstamp\":1777121695,\"uid\":43}',0,'0400$5d462e7e2f0240a222203a374ad9944b:17ca0a6178d323f36fa88baa7aec74b7'),
(281,1777121695,1,'BE',2,0,44,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1777121695,\"t3ver_stage\":0,\"tstamp\":1777121695,\"uid\":44}',0,'0400$5d462e7e2f0240a222203a374ad9944b:07aa68050ff2833e036a1fa71d7a273e'),
(282,1777121736,2,'BE',2,0,3,'tx_mask_apartments','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$760fb259b702fa69bae653e317484d44:1ad1cb62133673237a8e2c751f381073'),
(283,1777121736,2,'BE',2,0,4,'tx_mask_apartments','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"}}',0,'0400$760fb259b702fa69bae653e317484d44:76188b6140e685118edbf332247bc58a'),
(284,1777121736,1,'BE',2,0,5,'tx_mask_apartments','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":3,\"sorting\":0,\"tx_mask_number\":\"56.01.5\",\"tx_mask_floor\":\"0\",\"tx_mask_rooms\":\"3.5\",\"tx_mask_area\":\"80\",\"tx_mask_outside_area\":\"120\",\"tx_mask_status\":\"0\",\"tx_mask_unit_key\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\",\"crdate\":1777121736,\"t3ver_stage\":0,\"tstamp\":1777121736,\"uid\":5}',0,'0400$760fb259b702fa69bae653e317484d44:c36d8c1fc4dcfaf20ac2e0ac8d54694f'),
(285,1777121736,1,'BE',2,0,6,'tx_mask_apartments','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":3,\"sorting\":256,\"tx_mask_number\":\"56.01.7\",\"tx_mask_floor\":\"0\",\"tx_mask_rooms\":\"3.5\",\"tx_mask_area\":\"120\",\"tx_mask_outside_area\":\"80\",\"tx_mask_status\":\"0\",\"tx_mask_unit_key\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\",\"crdate\":1777121736,\"t3ver_stage\":0,\"tstamp\":1777121736,\"uid\":6}',0,'0400$760fb259b702fa69bae653e317484d44:ca47f4be408428667d6e90b8785e67d7'),
(286,1777121736,2,'BE',2,0,44,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\"}\"}}',0,'0400$760fb259b702fa69bae653e317484d44:07aa68050ff2833e036a1fa71d7a273e'),
(287,1777121736,1,'BE',2,0,45,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1777121736,\"t3ver_stage\":0,\"tstamp\":1777121736,\"uid\":45}',0,'0400$760fb259b702fa69bae653e317484d44:f59c54abe9804a9ad756ea862d4d98dd'),
(288,1777121736,1,'BE',2,0,46,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1777121736,\"t3ver_stage\":0,\"tstamp\":1777121736,\"uid\":46}',0,'0400$760fb259b702fa69bae653e317484d44:a82fe300f8818691e26d3b3c2d4b5fa0'),
(289,1777266972,2,'BE',2,0,4,'tx_mask_apartments','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$30c4064e71c3fbfe99b063c8e3ef127b:76188b6140e685118edbf332247bc58a'),
(290,1777266972,2,'BE',2,0,5,'tx_mask_apartments','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$30c4064e71c3fbfe99b063c8e3ef127b:c36d8c1fc4dcfaf20ac2e0ac8d54694f'),
(291,1777266972,2,'BE',2,0,6,'tx_mask_apartments','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\"}}',0,'0400$30c4064e71c3fbfe99b063c8e3ef127b:ca47f4be408428667d6e90b8785e67d7'),
(292,1777266972,1,'BE',2,0,7,'tx_mask_apartments','{\"l10n_parent\":0,\"starttime\":0,\"endtime\":0,\"parentid\":0,\"pid\":3,\"sorting\":0,\"tx_mask_number\":\"56.01.8\",\"tx_mask_floor\":\"3\",\"tx_mask_rooms\":\"4.5\",\"tx_mask_area\":\"120\",\"tx_mask_outside_area\":\"80\",\"tx_mask_status\":\"0\",\"tx_mask_unit_key\":\"\",\"sys_language_uid\":0,\"hidden\":\"0\",\"fe_group\":\"\",\"editlock\":\"0\",\"l10n_diffsource\":\"{\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"parentid\\\":\\\"\\\",\\\"sorting\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"tx_mask_area\\\":\\\"\\\",\\\"tx_mask_floor\\\":\\\"\\\",\\\"tx_mask_number\\\":\\\"\\\",\\\"tx_mask_outside_area\\\":\\\"\\\",\\\"tx_mask_pdf\\\":\\\"\\\",\\\"tx_mask_rooms\\\":\\\"\\\",\\\"tx_mask_status\\\":\\\"\\\",\\\"tx_mask_unit_key\\\":\\\"\\\"}\",\"crdate\":1777266972,\"t3ver_stage\":0,\"tstamp\":1777266972,\"uid\":7}',0,'0400$30c4064e71c3fbfe99b063c8e3ef127b:2ca89091bf01e295ebcebcd3c3ae69a6'),
(293,1777266972,2,'BE',2,0,46,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$30c4064e71c3fbfe99b063c8e3ef127b:a82fe300f8818691e26d3b3c2d4b5fa0'),
(294,1777266972,1,'BE',2,0,47,'sys_file_reference','{\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"autoplay\":0,\"hidden\":\"0\",\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"pid\":3,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"uid_local\":\"26\",\"sys_language_uid\":0,\"crdate\":1777266972,\"t3ver_stage\":0,\"tstamp\":1777266972,\"uid\":47}',0,'0400$30c4064e71c3fbfe99b063c8e3ef127b:fc1fba2d9912fd8b6cce486c76462505');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=157 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES
(156,2,1777266972,'tt_content',32,3,'studio_gg',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=544 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1776865589,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1776865609,1,1,1,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(3,1776865609,1,1,0,'site',0,0,'Site configuration \'%s\' was automatically created for new root page (%s).',6,'site',0,'172.18.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",1]',-1,0,'',0,'','info',NULL,NULL),
(4,1776865609,1,2,1,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(5,1776865629,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(6,1776865629,1,1,0,'site',0,0,'Site configuration \'%s\' was automatically created for new root page (%s).',6,'site',0,'172.18.0.5','[\"autogenerated-2-c81e728d9d4c2f636f067f89cc14862c\",2]',-1,0,'',0,'','info',NULL,NULL),
(7,1776865629,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"4\"}',0,0,'',0,'','info',NULL,NULL),
(8,1776865633,1,3,1,'pages',0,0,'Record pages:{uid} was deleted',1,'content',0,'172.18.0.5','{\"uid\":1}',0,0,'',0,'','info',NULL,NULL),
(9,1776865661,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"6\"}',0,0,'',0,'','info',NULL,NULL),
(10,1776865692,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"7\"}',0,0,'',0,'','info',NULL,NULL),
(11,1776865728,1,3,0,'site',0,0,'Site configuration \'%s\' was renamed to \'%s\'.',6,'site',0,'172.18.0.5','[\"autogenerated-2-c81e728d9d4c2f636f067f89cc14862c\",\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(12,1776865728,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(13,1776865738,1,4,0,'site',0,0,'Site configuration \'%s\' was deleted.',6,'site',0,'172.18.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\"]',-1,0,'',0,'','info',NULL,NULL),
(14,1776865764,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(15,1776865790,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(16,1776865791,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(17,1776865799,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(18,1776865811,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(19,1776865826,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(20,1776866714,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"greuegg-home.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(21,1776866725,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":0}',0,0,'',0,'','info',NULL,NULL),
(22,1776866725,1,1,1,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":1,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(23,1776866725,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":0}',0,0,'',0,'','info',NULL,NULL),
(24,1776866736,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":0}',0,0,'',0,'','info',NULL,NULL),
(25,1776866736,1,2,1,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":1,\"history\":\"9\"}',2,0,'',0,'','info',NULL,NULL),
(26,1776869559,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Css/app.css',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(27,1776869559,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/JavaScript/app.js',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(28,1776869908,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Css/app.css',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(29,1776869908,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/JavaScript/app.js',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(30,1776869908,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/JavaScript/app.js',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(31,1776869908,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Css/app.css',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(32,1776870018,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Css/app.css',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(33,1776870018,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/JavaScript/app.js',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(34,1776870028,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Css/app.css',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(35,1776870028,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/JavaScript/app.js',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(36,1776870031,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(37,1776870114,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(38,1776870139,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(39,1776870168,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(40,1776870967,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(41,1776871009,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(42,1776871026,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(43,1776871049,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(44,1776871444,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(45,1776871454,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(46,1776871455,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(47,1776871456,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(48,1776871456,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(49,1776871456,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(50,1776871456,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(51,1776871462,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(52,1776871491,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(53,1776871492,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(54,1776871547,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(55,1776871666,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(56,1776871667,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(57,1776871667,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(58,1776871668,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(59,1776871671,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(60,1776871673,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(61,1776871688,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(62,1776871702,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(63,1776871703,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(64,1776871929,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(65,1776871930,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(66,1776871931,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(67,1776871931,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(68,1776871931,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(69,1776871982,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(70,1776872094,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/HelveticaNeueLTPro-Lt.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(71,1776872124,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/.well-known/appspecific/com.chrome.devtools.json',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(72,1776872164,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(73,1776872167,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(74,1776872174,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Dist/JavaScript/app.js',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(75,1776872174,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Dist/Css/app.css',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(76,1776872182,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(77,1776872190,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(78,1776872191,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(79,1776872217,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(80,1776872236,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(81,1776872319,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(82,1776872320,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(83,1776872330,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(84,1776872378,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/public/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(85,1776872418,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(86,1776872419,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(87,1776872485,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(88,1776872486,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(89,1776872487,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(90,1776872505,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Dist/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(91,1776872506,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Dist/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(92,1776872637,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(93,1776872638,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(94,1776872654,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(95,1776925312,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,-99,'',0,'','info',NULL,NULL),
(96,1776925315,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/public/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(97,1776925317,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/public/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(98,1776925389,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/public/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(99,1776925391,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(100,1776925392,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(101,1776925400,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(102,1776925426,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(103,1776925472,1,1,3,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(104,1776925481,1,1,4,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(105,1776925487,1,1,5,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(106,1776925491,1,2,3,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":3,\"history\":\"13\"}',2,0,'',0,'','info',NULL,NULL),
(107,1776925495,1,2,4,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":4,\"history\":\"14\"}',2,0,'',0,'','info',NULL,NULL),
(108,1776925497,1,2,5,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":5,\"history\":\"15\"}',2,0,'',0,'','info',NULL,NULL),
(109,1776925915,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/public/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(110,1776926213,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(111,1776927008,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1700813537: No loginRedirectTarget configured for LoginRedirect errorhandler | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/Error/PageErrorHandler/RedirectLoginErrorHandler.php in line 133. Requested URL: https://egg.ddev.site/_assets/7615faf4ef1c8e2ff0d9d782346dc48a/Assets/Fonts/hnl.woff',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(112,1776927029,1,1,6,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(113,1776927032,1,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"17\"}',2,0,'',0,'','info',NULL,NULL),
(114,1776927049,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(115,1776927055,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(116,1776927061,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(117,1776929184,1,2,6,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":6,\"history\":\"18\"}',2,0,'',0,'','info',NULL,NULL),
(118,1776929250,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1509741912: Unable to render image tag in \"pages:2\": Supplied /fileadmin/Resources/Public/Images/logo.svg could not be resolved to a File or FileReference. | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/ImageViewHelper.php in line 175. Requested URL: https://egg.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(119,1776929270,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1509741912: Unable to render image tag in \"pages:2\": Supplied /fileadmin/Resources/Public/Images/Logo1.svg could not be resolved to a File or FileReference. | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/ImageViewHelper.php in line 175. Requested URL: https://egg.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(120,1776929285,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1509741912: Unable to render image tag in \"pages:2\": Supplied EXT:site:package/Resources/Public/Images/logo1.svg could not be resolved to a File or FileReference. | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/ImageViewHelper.php in line 175. Requested URL: https://egg.ddev.site/',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(121,1776930027,1,1,7,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":7,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(122,1776930035,1,1,8,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(123,1776930068,1,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":7,\"history\":\"21\"}',2,0,'',0,'','info',NULL,NULL),
(124,1776930071,1,2,7,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":7,\"history\":\"22\"}',2,0,'',0,'','info',NULL,NULL),
(125,1776930074,1,2,8,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"history\":\"23\"}',2,0,'',0,'','info',NULL,NULL),
(126,1776930076,1,2,8,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":8,\"history\":\"24\"}',2,0,'',0,'','info',NULL,NULL),
(127,1776938865,1,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,0,'',0,'','info',NULL,NULL),
(128,1776938883,1,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,0,'',0,'','info',NULL,NULL),
(129,1776938895,1,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,0,'',0,'','info',NULL,NULL),
(130,1776939062,1,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,0,'',0,'','info',NULL,NULL),
(131,1776939093,1,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,0,'',0,'','info',NULL,NULL),
(132,1776939250,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,0,'',0,'','info',NULL,NULL),
(133,1776939252,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"studio_gg_2\"]',-1,-99,'',0,'','info',NULL,NULL),
(134,1776939260,2,3,1,'be_users',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"be_users\",\"uid\":1,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(135,1776939266,2,2,2,'be_users',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"be_users\",\"uid\":2,\"history\":\"26\"}',0,0,'',0,'','info',NULL,NULL),
(136,1776939318,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"Bildschirmfoto 2026-04-23 um 12.15.08.png\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(137,1776939322,2,1,2,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":2,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(138,1776939322,2,2,2,'be_users',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"be_users\",\"uid\":2,\"history\":0}',0,0,'',0,'','info',NULL,NULL),
(139,1776944465,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(140,1776945661,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"HOme\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(141,1776945678,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"wohnen-konolfingen-1.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(142,1776945678,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"wohnen-konolfingen-2.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(143,1776945701,2,1,1,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(144,1776945701,2,1,3,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(145,1776945701,2,1,4,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(146,1776945701,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(147,1776945701,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(148,1776945884,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(149,1776945902,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"31\"}',2,0,'',0,'','info',NULL,NULL),
(150,1776945902,2,2,3,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":3,\"history\":\"32\"}',2,0,'',0,'','info',NULL,NULL),
(151,1776945902,2,2,4,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":4,\"history\":\"33\"}',2,0,'',0,'','info',NULL,NULL),
(152,1776945910,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"34\"}',2,0,'',0,'','info',NULL,NULL),
(153,1776945924,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(154,1776946378,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"35\"}',2,0,'',0,'','info',NULL,NULL),
(155,1776946385,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"36\"}',2,0,'',0,'','info',NULL,NULL),
(156,1776946935,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(157,1776947158,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1686813703: Using f:format.html in backend context is not allowed. Use f:sanitize.html or f:transform.html instead. | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/Format/HtmlViewHelper.php in line 86. Requested URL: https://egg.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--&id=2',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(158,1776947221,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"37\"}',2,0,'',0,'','info',NULL,NULL),
(159,1776947279,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1686813703: Using f:format.html in backend context is not allowed. Use f:sanitize.html or f:transform.html instead. | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/Format/HtmlViewHelper.php in line 86. Requested URL: https://egg.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--&id=2',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(160,1776947512,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"wohnung-konolfingen.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(161,1776947519,2,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(162,1776947519,2,1,5,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":5,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(163,1776947519,2,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(164,1776947523,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(165,1776947735,2,2,1,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":1,\"history\":\"40\"}',2,0,'',0,'','info',NULL,NULL),
(166,1776947889,2,1,6,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":6,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(167,1776947889,2,1,7,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(168,1776947889,2,1,3,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(169,1776947889,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(170,1776947889,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(171,1776947889,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"44\"}',2,0,'',0,'','info',NULL,NULL),
(172,1776947892,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"45\"}',2,0,'',0,'','info',NULL,NULL),
(173,1776947904,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"konolfingen-haus.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(174,1776947904,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"konolfingen-haus-3.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(175,1776947924,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"46\"}',2,0,'',0,'','info',NULL,NULL),
(176,1776947924,2,1,8,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":8,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(177,1776947924,2,1,9,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":9,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(178,1776947924,2,1,10,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":10,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(179,1776947924,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"50\"}',2,0,'',0,'','info',NULL,NULL),
(180,1776947924,2,2,3,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":3,\"history\":\"51\"}',2,0,'',0,'','info',NULL,NULL),
(181,1776947924,2,3,6,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":6,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(182,1776947924,2,3,7,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":7,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(183,1776948027,2,1,11,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":11,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(184,1776948027,2,1,4,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(185,1776948027,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(186,1776948027,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"56\"}',2,0,'',0,'','info',NULL,NULL),
(187,1776948029,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"57\"}',2,0,'',0,'','info',NULL,NULL),
(188,1776948036,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"konolfingen-familie.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(189,1776948038,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"58\"}',2,0,'',0,'','info',NULL,NULL),
(190,1776948038,2,1,12,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":12,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(191,1776948038,2,2,4,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":4,\"history\":\"60\"}',2,0,'',0,'','info',NULL,NULL),
(192,1776948038,2,3,11,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":11,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(193,1776948176,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"konolfingen-hund.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(194,1776948189,2,1,5,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(195,1776948189,2,1,13,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":13,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(196,1776948189,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(197,1776948199,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"64\"}',2,0,'',0,'','info',NULL,NULL),
(198,1776948199,2,2,13,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":13,\"history\":\"65\"}',2,0,'',0,'','info',NULL,NULL),
(199,1776948204,2,2,5,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":5,\"history\":\"66\"}',2,0,'',0,'','info',NULL,NULL),
(200,1776948264,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(201,1776948866,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(202,1776948964,2,1,6,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(203,1776949548,2,1,7,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(204,1776949675,2,2,7,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":7,\"history\":\"69\"}',2,0,'',0,'','info',NULL,NULL),
(205,1776949885,2,1,8,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":8,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(206,1776951549,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(207,1776952011,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"frau-wohnt-in-konolfingen.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(208,1776952060,2,1,9,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(209,1776952060,2,1,14,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":14,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(210,1776952060,2,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(211,1776952078,2,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":\"73\"}',2,0,'',0,'','info',NULL,NULL),
(212,1776952078,2,2,14,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":14,\"history\":\"74\"}',2,0,'',0,'','info',NULL,NULL),
(213,1776952821,2,1,10,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":10,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(214,1776952871,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"dominique-waser.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(215,1776952884,2,2,10,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":10,\"history\":\"76\"}',2,0,'',0,'','info',NULL,NULL),
(216,1776952884,2,1,15,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":15,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(217,1776952884,2,2,10,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":10,\"history\":\"78\"}',2,0,'',0,'','info',NULL,NULL),
(218,1776953114,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(219,1776953123,2,2,10,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":10,\"history\":\"79\"}',2,0,'',0,'','info',NULL,NULL),
(220,1776953123,2,2,15,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":15,\"history\":\"80\"}',2,0,'',0,'','info',NULL,NULL),
(221,1776953671,2,2,9,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":9,\"history\":\"81\"}',2,0,'',0,'','info',NULL,NULL),
(222,1776954054,2,2,10,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":10,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(223,1776954685,2,1,16,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":16,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(224,1776954685,2,1,11,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(225,1776954685,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(226,1776954685,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"84\"}',3,0,'',0,'','info',NULL,NULL),
(227,1776954687,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"85\"}',3,0,'',0,'','info',NULL,NULL),
(228,1776954732,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"Wohnen\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(229,1776954738,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"kon2.jpg\",\"destination\":\"\\/user_upload\\/Wohnen\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(230,1776954747,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"86\"}',3,0,'',0,'','info',NULL,NULL),
(231,1776954747,2,2,16,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":16,\"history\":\"87\"}',3,0,'',0,'','info',NULL,NULL),
(232,1776954747,2,1,17,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":17,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(233,1776954747,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"89\"}',3,0,'',0,'','info',NULL,NULL),
(234,1776954935,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(235,1776954935,2,2,17,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":17,\"history\":\"90\"}',3,0,'',0,'','info',NULL,NULL),
(236,1776954941,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(237,1776955067,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(238,1776955738,2,1,12,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":12,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(239,1776955738,2,2,12,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":12,\"history\":\"92\"}',3,0,'',0,'','info',NULL,NULL),
(240,1776955740,2,2,12,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":12,\"history\":\"93\"}',3,0,'',0,'','info',NULL,NULL),
(241,1776955761,2,2,12,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":12,\"history\":\"94\"}',3,0,'',0,'','info',NULL,NULL),
(242,1776955772,2,4,11,'tt_content',0,0,'Moved record {table}:{uid} on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(243,1776955772,2,2,11,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":11,\"history\":\"96\"}',3,0,'',0,'','info',NULL,NULL),
(244,1776955864,2,1,18,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":18,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(245,1776955864,2,1,13,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(246,1776955864,2,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(247,1776955864,2,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":\"99\"}',4,0,'',0,'','info',NULL,NULL),
(248,1776955866,2,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":\"100\"}',4,0,'',0,'','info',NULL,NULL),
(249,1776955932,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"Umgebung\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(250,1776955937,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"kind-wohnt-in-konolfingen.jpg\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(251,1776955955,2,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":\"101\"}',4,0,'',0,'','info',NULL,NULL),
(252,1776955955,2,1,19,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":19,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(253,1776955955,2,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":\"103\"}',4,0,'',0,'','info',NULL,NULL),
(254,1776955987,2,2,13,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":13,\"history\":\"104\"}',4,0,'',0,'','info',NULL,NULL),
(255,1776955987,2,2,19,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":19,\"history\":\"105\"}',4,0,'',0,'','info',NULL,NULL),
(256,1776955987,2,3,18,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":18,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(257,1776956029,2,1,14,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":14,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(258,1776956137,2,1,20,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":20,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(259,1776956137,2,1,15,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(260,1776956137,2,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(261,1776956137,2,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":\"110\"}',5,0,'',0,'','info',NULL,NULL),
(262,1776956138,2,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":\"111\"}',5,0,'',0,'','info',NULL,NULL),
(263,1776956187,2,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":\"112\"}',5,0,'',0,'','info',NULL,NULL),
(264,1776956187,2,2,20,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":20,\"history\":\"113\"}',5,0,'',0,'','info',NULL,NULL),
(265,1776956197,2,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(266,1777010326,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',0,'172.18.0.5','[\"studio_gg_2\"]',-1,-99,'',0,'','info',NULL,NULL),
(267,1777010331,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,-99,'',0,'','info',NULL,NULL),
(268,1777010337,2,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(269,1777013065,2,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(270,1777013379,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(271,1777013767,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(272,1777013790,2,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(273,1777013955,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1686813703: Using f:format.html in backend context is not allowed. Use f:sanitize.html or f:transform.html instead. | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/Format/HtmlViewHelper.php in line 86. Requested URL: https://egg.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--&id=5',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(274,1777013979,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1686813703: Using f:format.html in backend context is not allowed. Use f:sanitize.html or f:transform.html instead. | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/Format/HtmlViewHelper.php in line 86. Requested URL: https://egg.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--&id=5',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(275,1777013982,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1686813703: Using f:format.html in backend context is not allowed. Use f:sanitize.html or f:transform.html instead. | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/Format/HtmlViewHelper.php in line 86. Requested URL: https://egg.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--&id=5&',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(276,1777013983,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1686813703: Using f:format.html in backend context is not allowed. Use f:sanitize.html or f:transform.html instead. | RuntimeException thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/Format/HtmlViewHelper.php in line 86. Requested URL: https://egg.ddev.site/typo3/module/web/layout?token=--AnonymizedToken--&id=5',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(277,1777014061,2,1,16,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(278,1777014155,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"blumen-wohnung-in-konolfingen.jpg\",\"destination\":\"\\/user_upload\\/Wohnen\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(279,1777014210,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":\"115\"}',5,0,'',0,'','info',NULL,NULL),
(280,1777014210,2,1,21,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(281,1777014210,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":\"117\"}',5,0,'',0,'','info',NULL,NULL),
(282,1777014255,2,1,9,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(283,1777014257,2,2,9,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":9,\"history\":\"119\"}',2,0,'',0,'','info',NULL,NULL),
(284,1777014296,2,1,1,'tx_powermail_domain_model_form',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_form\",\"uid\":1,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(285,1777014296,2,1,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(286,1777014296,2,1,1,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":1,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(287,1777014296,2,2,1,'tx_powermail_domain_model_form',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_form\",\"uid\":1,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(288,1777014296,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(289,1777014325,2,2,1,'tx_powermail_domain_model_form',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_form\",\"uid\":1,\"history\":\"123\"}',9,0,'',0,'','info',NULL,NULL),
(290,1777014325,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":\"124\"}',9,0,'',0,'','info',NULL,NULL),
(291,1777014325,2,2,1,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":1,\"history\":\"125\"}',9,0,'',0,'','info',NULL,NULL),
(292,1777014325,2,1,2,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":2,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(293,1777014325,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":\"127\"}',9,0,'',0,'','info',NULL,NULL),
(294,1777014337,2,2,1,'tx_powermail_domain_model_form',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_form\",\"uid\":1,\"history\":\"128\"}',9,0,'',0,'','info',NULL,NULL),
(295,1777014337,2,2,1,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":1,\"history\":\"129\"}',9,0,'',0,'','info',NULL,NULL),
(296,1777014337,2,2,2,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":2,\"history\":\"130\"}',9,0,'',0,'','info',NULL,NULL),
(297,1777014337,2,1,3,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":3,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(298,1777014337,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(299,1777014344,2,2,2,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":2,\"history\":\"132\"}',9,0,'',0,'','info',NULL,NULL),
(300,1777014344,2,2,3,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":3,\"history\":\"133\"}',9,0,'',0,'','info',NULL,NULL),
(301,1777014488,2,2,3,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":3,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(302,1777014488,2,1,4,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":4,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(303,1777014488,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(304,1777014502,2,2,3,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":3,\"history\":\"135\"}',9,0,'',0,'','info',NULL,NULL),
(305,1777014502,2,2,4,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":4,\"history\":\"136\"}',9,0,'',0,'','info',NULL,NULL),
(306,1777014502,2,1,5,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":5,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(307,1777014502,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(308,1777014522,2,2,4,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":4,\"history\":\"138\"}',9,0,'',0,'','info',NULL,NULL),
(309,1777014522,2,2,5,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":5,\"history\":\"139\"}',9,0,'',0,'','info',NULL,NULL),
(310,1777014522,2,1,6,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":6,\"pid\":9}',9,0,'',0,'','info',NULL,NULL),
(311,1777014522,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":0}',9,0,'',0,'','info',NULL,NULL),
(312,1777014526,2,2,5,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":5,\"history\":\"141\"}',9,0,'',0,'','info',NULL,NULL),
(313,1777014526,2,2,6,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":6,\"history\":\"142\"}',9,0,'',0,'','info',NULL,NULL),
(314,1777014640,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(315,1777014640,2,1,17,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":17,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(316,1777014640,2,2,21,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":21,\"history\":\"144\"}',5,0,'',0,'','info',NULL,NULL),
(317,1777014640,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(318,1777014649,2,1,10,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(319,1777014656,2,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":\"146\"}',5,0,'',0,'','info',NULL,NULL),
(320,1777014658,2,2,10,'pages',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"pages\",\"uid\":10,\"history\":\"147\"}',5,0,'',0,'','info',NULL,NULL),
(321,1777014845,2,1,18,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":18,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(322,1777014869,2,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":18,\"history\":\"149\"}',10,0,'',0,'','info',NULL,NULL),
(323,1777014882,2,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":18,\"history\":0}',10,0,'',0,'','info',NULL,NULL),
(324,1777014914,2,2,18,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":18,\"history\":\"150\"}',10,0,'',0,'','info',NULL,NULL),
(325,1777014917,2,1,22,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(326,1777014917,2,1,19,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(327,1777014917,2,2,19,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"history\":0}',10,0,'',0,'','info',NULL,NULL),
(328,1777014917,2,2,19,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"history\":\"153\"}',10,0,'',0,'','info',NULL,NULL),
(329,1777014918,2,2,19,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"history\":\"154\"}',10,0,'',0,'','info',NULL,NULL),
(330,1777014959,2,2,19,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"history\":\"155\"}',10,0,'',0,'','info',NULL,NULL),
(331,1777014959,2,2,22,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":22,\"history\":\"156\"}',10,0,'',0,'','info',NULL,NULL),
(332,1777014965,2,2,19,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"history\":\"157\"}',10,0,'',0,'','info',NULL,NULL),
(333,1777014986,2,2,19,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"history\":\"158\"}',10,0,'',0,'','info',NULL,NULL),
(334,1777014992,2,2,19,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"history\":\"159\"}',10,0,'',0,'','info',NULL,NULL),
(335,1777015006,2,3,22,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":22,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(336,1777015006,2,3,19,'tt_content',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":19,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(337,1777015013,2,1,23,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":23,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(338,1777015013,2,1,20,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":20,\"pid\":10}',10,0,'',0,'','info',NULL,NULL),
(339,1777015013,2,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":20,\"history\":0}',10,0,'',0,'','info',NULL,NULL),
(340,1777015013,2,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"164\"}',10,0,'',0,'','info',NULL,NULL),
(341,1777015014,2,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"165\"}',10,0,'',0,'','info',NULL,NULL),
(342,1777015050,2,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"166\"}',10,0,'',0,'','info',NULL,NULL),
(343,1777015065,2,2,20,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":20,\"history\":\"167\"}',10,0,'',0,'','info',NULL,NULL),
(344,1777015093,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(345,1777015093,2,2,17,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":17,\"history\":\"168\"}',5,0,'',0,'','info',NULL,NULL),
(346,1777015291,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1698750868: Cannot cast an array to string. | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/SyntaxTree/AbstractNode.php in line 72. Requested URL: https://egg.ddev.site/kontakt',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(347,1777015349,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(348,1777015371,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1540246570: No Content Object definition found at TypoScript object path \"lib.tx_mask.content_second_column\" | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 114. Requested URL: https://egg.ddev.site/kontakt',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(349,1777015392,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1253191023: TypoScript object path \"data.tx_mask_content_second_column\" does not exist | TYPO3Fluid\\Fluid\\Core\\ViewHelper\\Exception thrown in file /var/www/html/vendor/typo3/cms-fluid/Classes/ViewHelpers/CObjectViewHelper.php in line 106. Requested URL: https://egg.ddev.site/kontakt',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(350,1777015530,2,2,1,'tx_powermail_domain_model_form',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_form\",\"uid\":1,\"history\":\"169\"}',9,0,'',0,'','info',NULL,NULL),
(351,1777015530,2,2,1,'tx_powermail_domain_model_page',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_page\",\"uid\":1,\"history\":\"170\"}',9,0,'',0,'','info',NULL,NULL),
(352,1777015530,2,2,6,'tx_powermail_domain_model_field',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_powermail_domain_model_field\",\"uid\":6,\"history\":\"171\"}',9,0,'',0,'','info',NULL,NULL),
(353,1777015608,2,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(354,1777015620,2,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(355,1777015629,2,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"adowia\"]',-1,0,'',0,'','info',NULL,NULL),
(356,1777018242,2,2,6,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":6,\"history\":\"172\"}',2,0,'',0,'','info',NULL,NULL),
(357,1777018374,2,1,24,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":24,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(358,1777018374,2,1,21,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":21,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(359,1777018374,2,2,21,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":21,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(360,1777018374,2,2,21,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":21,\"history\":\"175\"}',4,0,'',0,'','info',NULL,NULL),
(361,1777018376,2,2,21,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":21,\"history\":\"176\"}',4,0,'',0,'','info',NULL,NULL),
(362,1777018482,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"konol1.jpg\",\"destination\":\"\\/user_upload\\/Umgebung\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(363,1777018482,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"wohnen-konolfingen-1.jpg\",\"destination\":\"\\/user_upload\\/Umgebung\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(364,1777018482,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"wohnen-konolfingen-2.jpg\",\"destination\":\"\\/user_upload\\/Umgebung\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(365,1777018490,2,2,21,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":21,\"history\":\"177\"}',4,0,'',0,'','info',NULL,NULL),
(366,1777018490,2,1,25,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":25,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(367,1777018490,2,1,26,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":26,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(368,1777018490,2,1,27,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":27,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(369,1777018490,2,2,21,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":21,\"history\":\"181\"}',4,0,'',0,'','info',NULL,NULL),
(370,1777018490,2,3,24,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":24,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(371,1777019122,2,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1224485398: Fluid parse error in template Default_action_TwoColumns_8bfba02f72b4e70b, line 174 at character 14. Error: Templating tags not properly nested. Expected: TYPO3Fluid\\Fluid\\ViewHelpers\\IfViewHelper; Actual: TYPO3Fluid\\Fluid\\ViewHelpers\\ElseViewHelper (error code 1224485398). Template source chunk: </f:else> | TYPO3Fluid\\Fluid\\Core\\Parser\\Exception thrown in file /var/www/html/vendor/typo3fluid/fluid/src/Core/Parser/TemplateParser.php in line 131. Requested URL: https://egg.ddev.site/umgebung',5,'php',0,'172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(372,1777019433,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"man-velo.jpg\",\"destination\":\"\\/user_upload\\/Umgebung\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(373,1777019445,2,1,22,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":22,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(374,1777019445,2,1,28,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":28,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(375,1777019445,2,1,29,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":29,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(376,1777019445,2,1,30,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":30,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(377,1777019445,2,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":22,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(378,1777019554,2,2,22,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":22,\"history\":\"187\"}',4,0,'',0,'','info',NULL,NULL),
(379,1777019554,2,2,28,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":28,\"history\":\"188\"}',4,0,'',0,'','info',NULL,NULL),
(380,1777019554,2,2,29,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":29,\"history\":\"189\"}',4,0,'',0,'','info',NULL,NULL),
(381,1777019554,2,2,30,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":30,\"history\":\"190\"}',4,0,'',0,'','info',NULL,NULL),
(382,1777019755,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"gleitsicht_hero_small_desktop.png\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(383,1777019768,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"konolfingen-234.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(384,1777019775,2,1,23,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":23,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(385,1777019775,2,1,31,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":31,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(386,1777019775,2,1,32,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":32,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(387,1777019775,2,2,23,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":23,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(388,1777019783,2,2,23,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":23,\"history\":\"194\"}',4,0,'',0,'','info',NULL,NULL),
(389,1777019783,2,2,31,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":31,\"history\":\"195\"}',4,0,'',0,'','info',NULL,NULL),
(390,1777019783,2,2,32,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":32,\"history\":\"196\"}',4,0,'',0,'','info',NULL,NULL),
(391,1777019838,2,1,24,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":24,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(392,1777019879,2,1,25,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":25,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(393,1777019879,2,2,25,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":25,\"history\":\"199\"}',4,0,'',0,'','info',NULL,NULL),
(394,1777019883,2,2,25,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":25,\"history\":\"200\"}',4,0,'',0,'','info',NULL,NULL),
(395,1777019892,2,2,25,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":25,\"history\":\"201\"}',4,0,'',0,'','info',NULL,NULL),
(396,1777020049,2,2,25,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":25,\"history\":\"202\"}',4,0,'',0,'','info',NULL,NULL),
(397,1777020490,2,1,26,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":26,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(398,1777020490,2,1,33,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":33,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(399,1777020490,2,2,26,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":26,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(400,1777020618,2,1,27,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":27,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(401,1777020618,2,2,27,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":27,\"history\":\"206\"}',3,0,'',0,'','info',NULL,NULL),
(402,1777020620,2,2,27,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":27,\"history\":\"207\"}',3,0,'',0,'','info',NULL,NULL),
(403,1777020637,2,2,27,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":27,\"history\":\"208\"}',3,0,'',0,'','info',NULL,NULL),
(404,1777020658,2,2,27,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":27,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(405,1777020957,2,1,34,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":34,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(406,1777020957,2,1,35,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":35,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(407,1777020957,2,1,36,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":36,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(408,1777020957,2,1,28,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":28,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(409,1777020957,2,2,28,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":28,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(410,1777020957,2,2,28,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":28,\"history\":\"213\"}',3,0,'',0,'','info',NULL,NULL),
(411,1777020964,2,2,28,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":28,\"history\":\"214\"}',3,0,'',0,'','info',NULL,NULL),
(412,1777021059,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"keller-konolfingen.jpg\",\"destination\":\"\\/user_upload\\/HOme\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(413,1777021071,2,2,28,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":28,\"history\":\"215\"}',3,0,'',0,'','info',NULL,NULL),
(414,1777021071,2,1,37,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":37,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(415,1777021071,2,2,28,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":28,\"history\":\"217\"}',3,0,'',0,'','info',NULL,NULL),
(416,1777021071,2,3,36,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":36,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(417,1777021071,2,3,35,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":35,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(418,1777021071,2,3,34,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":34,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(419,1777021078,2,2,28,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":28,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(420,1777021078,2,2,37,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":37,\"history\":\"221\"}',3,0,'',0,'','info',NULL,NULL),
(421,1777021694,2,2,15,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":15,\"history\":\"222\"}',5,0,'',0,'','info',NULL,NULL),
(422,1777021808,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(423,1777021808,2,2,17,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":17,\"history\":\"223\"}',5,0,'',0,'','info',NULL,NULL),
(424,1777021808,2,1,38,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":38,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(425,1777021808,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(426,1777021808,2,3,21,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":21,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(427,1777021813,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(428,1777021813,2,2,38,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":38,\"history\":\"226\"}',5,0,'',0,'','info',NULL,NULL),
(429,1777021816,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(430,1777021854,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"blumen-wohnung-in-konolfingen-2.jpg\",\"destination\":\"\\/user_upload\\/Wohnen\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(431,1777021856,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(432,1777021856,2,1,39,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":39,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(433,1777021856,2,2,16,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":16,\"history\":0}',5,0,'',0,'','info',NULL,NULL),
(434,1777021856,2,3,38,'sys_file_reference',0,0,'Record {table}:{uid} was deleted from pages:{pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":38,\"pid\":5}',5,0,'',0,'','info',NULL,NULL),
(435,1777024136,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(436,1777024292,2,1,29,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(437,1777024292,2,1,1,'tx_mask_tabs_map',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_tabs_map\",\"uid\":1,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(438,1777024292,2,1,2,'tx_mask_tabs_map',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_tabs_map\",\"uid\":2,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(439,1777024292,2,1,3,'tx_mask_tabs_map',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_tabs_map\",\"uid\":3,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(440,1777024292,2,1,4,'tx_mask_tabs_map',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_tabs_map\",\"uid\":4,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(441,1777024292,2,1,1,'tx_mask_places',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":1,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(442,1777024292,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(443,1777024292,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(444,1777024495,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":\"235\"}',4,0,'',0,'','info',NULL,NULL),
(445,1777024495,2,2,1,'tx_mask_tabs_map',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_tabs_map\",\"uid\":1,\"history\":\"236\"}',4,0,'',0,'','info',NULL,NULL),
(446,1777024495,2,2,2,'tx_mask_tabs_map',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_tabs_map\",\"uid\":2,\"history\":\"237\"}',4,0,'',0,'','info',NULL,NULL),
(447,1777024495,2,2,3,'tx_mask_tabs_map',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_tabs_map\",\"uid\":3,\"history\":\"238\"}',4,0,'',0,'','info',NULL,NULL),
(448,1777024495,2,2,4,'tx_mask_tabs_map',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_tabs_map\",\"uid\":4,\"history\":\"239\"}',4,0,'',0,'','info',NULL,NULL),
(449,1777024495,2,2,1,'tx_mask_places',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":1,\"history\":\"240\"}',4,0,'',0,'','info',NULL,NULL),
(450,1777024495,2,1,2,'tx_mask_places',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":2,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(451,1777024495,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":\"242\"}',4,0,'',0,'','info',NULL,NULL),
(452,1777024543,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(453,1777024700,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(454,1777024803,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(455,1777024803,2,2,2,'tx_mask_places',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":2,\"history\":\"243\"}',4,0,'',0,'','info',NULL,NULL),
(456,1777028828,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(457,1777028828,2,1,3,'tx_mask_places',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":3,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(458,1777028828,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(459,1777028865,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(460,1777028865,2,2,2,'tx_mask_places',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":2,\"history\":\"245\"}',4,0,'',0,'','info',NULL,NULL),
(461,1777028865,2,2,3,'tx_mask_places',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":3,\"history\":\"246\"}',4,0,'',0,'','info',NULL,NULL),
(462,1777028865,2,1,4,'tx_mask_places',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":4,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(463,1777028865,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(464,1777028903,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(465,1777028903,2,2,3,'tx_mask_places',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":3,\"history\":\"248\"}',4,0,'',0,'','info',NULL,NULL),
(466,1777028903,2,2,4,'tx_mask_places',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":4,\"history\":\"249\"}',4,0,'',0,'','info',NULL,NULL),
(467,1777028903,2,1,5,'tx_mask_places',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_places\",\"uid\":5,\"pid\":4}',4,0,'',0,'','info',NULL,NULL),
(468,1777028903,2,2,29,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":29,\"history\":0}',4,0,'',0,'','info',NULL,NULL),
(469,1777029254,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(470,1777029480,2,1,30,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":30,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(471,1777029480,2,1,40,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":40,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(472,1777029480,2,2,30,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":30,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(473,1777029654,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(474,1777029801,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(475,1777029811,2,2,30,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":30,\"history\":\"253\"}',2,0,'',0,'','info',NULL,NULL),
(476,1777029811,2,1,31,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":31,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(477,1777029811,2,2,40,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":40,\"history\":\"255\"}',2,0,'',0,'','info',NULL,NULL),
(478,1777029811,2,2,30,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":30,\"history\":\"256\"}',2,0,'',0,'','info',NULL,NULL),
(479,1777029875,2,2,30,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":30,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(480,1777029875,2,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":31,\"history\":\"257\"}',2,0,'',0,'','info',NULL,NULL),
(481,1777029875,2,1,1,'tx_mask_accordion_with_data',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_accordion_with_data\",\"uid\":1,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(482,1777029875,2,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":31,\"history\":\"259\"}',2,0,'',0,'','info',NULL,NULL),
(483,1777029939,2,2,30,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":30,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(484,1777029939,2,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":31,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(485,1777029939,2,2,1,'tx_mask_accordion_with_data',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_accordion_with_data\",\"uid\":1,\"history\":\"260\"}',2,0,'',0,'','info',NULL,NULL),
(486,1777029939,2,1,2,'tx_mask_accordion_with_data',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_accordion_with_data\",\"uid\":2,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(487,1777029939,2,1,3,'tx_mask_accordion_with_data',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_accordion_with_data\",\"uid\":3,\"pid\":2}',2,0,'',0,'','info',NULL,NULL),
(488,1777029939,2,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":31,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(489,1777029948,2,2,30,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":30,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(490,1777029948,2,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":31,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(491,1777029948,2,2,1,'tx_mask_accordion_with_data',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_accordion_with_data\",\"uid\":1,\"history\":\"263\"}',2,0,'',0,'','info',NULL,NULL),
(492,1777029948,2,2,2,'tx_mask_accordion_with_data',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_accordion_with_data\",\"uid\":2,\"history\":\"264\"}',2,0,'',0,'','info',NULL,NULL),
(493,1777029948,2,2,3,'tx_mask_accordion_with_data',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_accordion_with_data\",\"uid\":3,\"history\":\"265\"}',2,0,'',0,'','info',NULL,NULL),
(494,1777029973,2,2,30,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":30,\"history\":\"266\"}',2,0,'',0,'','info',NULL,NULL),
(495,1777029973,2,2,31,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":31,\"history\":0}',2,0,'',0,'','info',NULL,NULL),
(496,1777119800,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,-99,'',0,'','info',NULL,NULL),
(497,1777121557,2,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"PDFs\",\"destination\":\"\\/user_upload\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(498,1777121584,2,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"blank.pdf\",\"destination\":\"\\/user_upload\\/PDFs\\/\"}',-1,0,'',0,'','info',NULL,NULL),
(499,1777121599,2,1,32,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(500,1777121599,2,1,1,'tx_mask_apartments',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":1,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(501,1777121599,2,1,41,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":41,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(502,1777121599,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(503,1777121599,2,2,1,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":1,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(504,1777121648,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":\"270\"}',3,0,'',0,'','info',NULL,NULL),
(505,1777121648,2,2,1,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":1,\"history\":\"271\"}',3,0,'',0,'','info',NULL,NULL),
(506,1777121648,2,1,2,'tx_mask_apartments',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":2,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(507,1777121648,2,2,41,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":41,\"history\":\"273\"}',3,0,'',0,'','info',NULL,NULL),
(508,1777121648,2,1,42,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":42,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(509,1777121648,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":\"275\"}',3,0,'',0,'','info',NULL,NULL),
(510,1777121648,2,2,2,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":2,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(511,1777121695,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(512,1777121695,2,2,1,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":1,\"history\":\"276\"}',3,0,'',0,'','info',NULL,NULL),
(513,1777121695,2,2,2,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":2,\"history\":\"277\"}',3,0,'',0,'','info',NULL,NULL),
(514,1777121695,2,1,3,'tx_mask_apartments',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":3,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(515,1777121695,2,1,4,'tx_mask_apartments',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":4,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(516,1777121695,2,1,43,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":43,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(517,1777121695,2,1,44,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":44,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(518,1777121695,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(519,1777121695,2,2,3,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":3,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(520,1777121695,2,2,4,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":4,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(521,1777121736,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(522,1777121736,2,2,3,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":3,\"history\":\"282\"}',3,0,'',0,'','info',NULL,NULL),
(523,1777121736,2,2,4,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":4,\"history\":\"283\"}',3,0,'',0,'','info',NULL,NULL),
(524,1777121736,2,1,5,'tx_mask_apartments',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":5,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(525,1777121736,2,1,6,'tx_mask_apartments',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":6,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(526,1777121736,2,2,44,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":44,\"history\":\"286\"}',3,0,'',0,'','info',NULL,NULL),
(527,1777121736,2,1,45,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":45,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(528,1777121736,2,1,46,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":46,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(529,1777121736,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(530,1777121736,2,2,5,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":5,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(531,1777121736,2,2,6,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":6,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(532,1777121744,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(533,1777266942,2,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',0,'172.18.0.5','[\"studio_gg\"]',-1,-99,'',0,'','info',NULL,NULL),
(534,1777266972,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(535,1777266972,2,2,4,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":4,\"history\":\"289\"}',3,0,'',0,'','info',NULL,NULL),
(536,1777266972,2,2,5,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":5,\"history\":\"290\"}',3,0,'',0,'','info',NULL,NULL),
(537,1777266972,2,2,6,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":6,\"history\":\"291\"}',3,0,'',0,'','info',NULL,NULL),
(538,1777266972,2,1,7,'tx_mask_apartments',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":7,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(539,1777266972,2,2,46,'sys_file_reference',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":46,\"history\":\"293\"}',3,0,'',0,'','info',NULL,NULL),
(540,1777266972,2,1,47,'sys_file_reference',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content',0,'172.18.0.5','{\"table\":\"sys_file_reference\",\"uid\":47,\"pid\":3}',3,0,'',0,'','info',NULL,NULL),
(541,1777266972,2,2,32,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tt_content\",\"uid\":32,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(542,1777266972,2,2,7,'tx_mask_apartments',0,0,'Record {table}:{uid} was updated',1,'content',0,'172.18.0.5','{\"table\":\"tx_mask_apartments\",\"uid\":7,\"history\":0}',3,0,'',0,'','info',NULL,NULL),
(543,1777267297,2,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"studio_gg\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_preview`
--

DROP TABLE IF EXISTS `sys_preview`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_preview` (
  `keyword` varchar(32) NOT NULL DEFAULT '',
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `config` text DEFAULT NULL,
  PRIMARY KEY (`keyword`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_preview`
--

LOCK TABLES `sys_preview` WRITE;
/*!40000 ALTER TABLE `sys_preview` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_preview` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_redirect`
--

DROP TABLE IF EXISTS `sys_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_redirect` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `hitcount` int(11) NOT NULL DEFAULT 0,
  `source_host` varchar(255) NOT NULL DEFAULT '',
  `source_path` text NOT NULL DEFAULT '',
  `force_https` smallint(5) unsigned NOT NULL DEFAULT 0,
  `keep_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `respect_query_parameters` smallint(5) unsigned NOT NULL DEFAULT 0,
  `target` text NOT NULL DEFAULT '',
  `target_statuscode` int(10) unsigned NOT NULL DEFAULT 0,
  `lasthiton` bigint(20) NOT NULL DEFAULT 0,
  `disable_hitcount` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_regexp` smallint(5) unsigned NOT NULL DEFAULT 0,
  `protected` smallint(5) unsigned NOT NULL DEFAULT 0,
  `creation_type` int(10) unsigned NOT NULL DEFAULT 0,
  `integrity_status` varchar(180) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `index_source` (`source_host`(80),`source_path`(80)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_redirect`
--

LOCK TABLES `sys_redirect` WRITE;
/*!40000 ALTER TABLE `sys_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('005b0c8ad1009980df6e6c0e2a503e86','tt_content',32,'tx_mask_apartments',0,0,2147483647,0,'','','',0,0,'tx_mask_apartments',1,'',0,0,2147483647,0,0,''),
('032c9455240737904f045d3fb40ed1d2','sys_file',16,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('0577005503db7a74a9e41e4aca68ef82','tt_content',29,'tx_mask_places',0,0,2147483647,0,'','','',4,0,'tx_mask_places',5,'',0,0,2147483647,0,0,''),
('06473baa2bc4c377c384c7bc37600e09','tt_content',22,'tx_mask_image_first_column',0,0,2147483647,0,'','','',2,0,'sys_file_reference',30,'',0,0,2147483647,0,0,''),
('082e15706119eaaa70ec74e6f9b4ad94','tt_content',22,'tx_mask_image_first_column',0,0,2147483647,0,'','','',1,0,'sys_file_reference',29,'',0,0,2147483647,0,0,''),
('088af7a8a8c15ae07aa9c67fd6d574af','tx_mask_apartments',7,'tx_mask_pdf',0,0,2147483647,0,'','','',0,0,'sys_file_reference',47,'',0,0,2147483647,0,0,''),
('08bc8084fc9ecee647a781018c70ce04','tx_powermail_domain_model_form',1,'pages',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('0924a81a811e2ca9a8685b275c0b4ab2','tx_mask_apartments',6,'tx_mask_pdf',0,0,2147483647,0,'','','',0,0,'sys_file_reference',46,'',0,0,2147483647,0,0,''),
('0bfca5c1e7181ef55a529a4ab918b8cd','sys_file_reference',46,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('0d4e0ed1dfc736b29353595f52136d14','tx_mask_tabs_map',2,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('0eb6c1f02b61188547fdd9c3ad1c1f58','sys_file_reference',20,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',14,'',0,0,2147483647,0,0,''),
('13e3f775f5fe55e34e6c3053fc81a294','sys_file',7,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',7,'',0,0,2147483647,0,0,''),
('1891e5b68039b20ea9ed0acf765648c4','sys_file',11,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('1b097c1876b630e8e2f0a913333eedcb','be_users',2,'avatar',0,0,2147483647,0,'','','',0,0,'sys_file_reference',2,'',0,0,2147483647,0,0,''),
('1b68d36703260c2e4022314885024c2c','tx_mask_apartments',7,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',32,'',0,0,2147483647,0,0,''),
('1bb57bc64cd75b6fc74edc570c5bf546','tx_powermail_domain_model_field',3,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('1cb75ad318b7c7770181c1361640dbee','tx_powermail_domain_model_field',6,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('21258650f973214ea36749d6f1e0e877','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_field',1,'',0,0,2147483647,0,0,''),
('279f73c366eb0636c1fc922e1f65755a','tt_content',32,'tx_mask_apartments',0,0,2147483647,0,'','','',5,0,'tx_mask_apartments',6,'',0,0,2147483647,0,0,''),
('2a3aeca59991b97c233b159a4bf8e877','tt_content',16,'tx_mask_content_second_column',0,0,2147483647,0,'','','',0,0,'tt_content',17,'',0,0,2147483647,0,0,''),
('2ac556e20e35ec457e98ac9f7532860b','tt_content',29,'tx_mask_tabs_map',0,0,2147483647,0,'','','',2,0,'tx_mask_tabs_map',3,'',0,0,2147483647,0,0,''),
('2b5a5f92bfa5ddfbefeed42a45243261','tt_content',22,'tx_mask_image_first_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',28,'',0,0,2147483647,0,0,''),
('2f10c1fce201d5e63a983a85ce50b6e4','be_users',2,'email',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'dani@studiothompfister.com'),
('2fd5cb2ea8066bfcfe3636587548f838','sys_file_reference',44,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('340158331ec1edb4e312004cd6cd39be','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',3,0,'tx_powermail_domain_model_field',4,'',0,0,2147483647,0,0,''),
('34467228cf4e5292ab46b25ba32e7573','tx_mask_tabs_map',1,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('35680ec3a9fd25bca673ea0913b20e24','sys_file_reference',17,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',15,'',0,0,2147483647,0,0,''),
('35dc2fa5640cb5571a685fa96c3fcb65','tt_content',29,'tx_mask_tabs_map',0,0,2147483647,0,'','','',1,0,'tx_mask_tabs_map',2,'',0,0,2147483647,0,0,''),
('37828d2161a41115b9a43d629521ae6a','tt_content',15,'tx_mask_smallink_below',0,0,2147483647,0,'','typolink','fcc4adbef574f4aa7983519e83e4219d:0',0,0,'pages',5,'',0,0,2147483647,0,0,''),
('3803b37796a6a4fa40ce4891b42f5c92','tt_content',31,'tx_mask_accordion_with_data',0,0,2147483647,0,'','','',1,0,'tx_mask_accordion_with_data',2,'',0,0,2147483647,0,0,''),
('3898ee315c4f93ce8b745e9cf5830098','sys_file_reference',29,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('38b0e31db2e06835e6d790da725a03f8','sys_file_reference',19,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',16,'',0,0,2147483647,0,0,''),
('39302b34fcc68b7cc0dab6f16be7c324','sys_file',8,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',8,'',0,0,2147483647,0,0,''),
('3c2afbf12f575868fa8647d40a46b87e','tx_mask_tabs_map',4,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('3c75b846aba8f0139928ab35c44f8d00','tx_mask_apartments',1,'tx_mask_pdf',0,0,2147483647,0,'','','',0,0,'sys_file_reference',41,'',0,0,2147483647,0,0,''),
('3dbc7ee58ce994d1f261697a6dd473fd','sys_file_reference',8,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',9,'',0,0,2147483647,0,0,''),
('43c11b7c2d075b45c65be6b7b0d1a017','sys_file',23,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('44eb9c223a49f5e5e1682d152ada13ac','tt_content',32,'tx_mask_apartments',0,0,2147483647,0,'','','',6,0,'tx_mask_apartments',7,'',0,0,2147483647,0,0,''),
('454efd19a68c02b0d38bf21026f2a865','sys_file_reference',14,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',13,'',0,0,2147483647,0,0,''),
('46a2b61b37af50d08dc6d66ede075994','sys_file_reference',16,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',11,'',0,0,2147483647,0,0,''),
('479da7d6fe1870aeb4a312e762d0e237','tt_content',31,'tx_mask_accordion_with_data',0,0,2147483647,0,'','','',0,0,'tx_mask_accordion_with_data',1,'',0,0,2147483647,0,0,''),
('485b276d61a66437a43845287ae864ef','tt_content',10,'tx_mask_add_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',15,'',0,0,2147483647,0,0,''),
('48b778a61fcb51902582a290e06ee2dc','tt_content',29,'tx_mask_places',0,0,2147483647,0,'','','',2,0,'tx_mask_places',3,'',0,0,2147483647,0,0,''),
('49a1dca9b44dbc2f1878bcbdb69eaa56','sys_file',20,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',20,'',0,0,2147483647,0,0,''),
('4d25ffe7967678a860e32a7d6ee88b96','tt_content',2,'tx_mask_simple_image_class',0,0,2147483647,0,'','','',0,0,'sys_file_reference',5,'',0,0,2147483647,0,0,''),
('4ea66e820587842f4509eca5d5fe6495','tt_content',13,'tx_mask_image_first_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',19,'',0,0,2147483647,0,0,''),
('50918afd9208cd80f6ad4eadb4fe2e61','tt_content',1,'tx_mask_image_second_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',4,'',0,0,2147483647,0,0,''),
('522e8d6cab27b43b6493fac5cd39a3ca','sys_file_reference',4,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',7,'',0,0,2147483647,0,0,''),
('54dcff8d48331aea5e0df2d4579e73c4','sys_file_reference',31,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',22,'',0,0,2147483647,0,0,''),
('5642d7d05a85f673280b33a9c599c4fc','tt_content',21,'tx_mask_image_second_column',0,0,2147483647,0,'','','',2,0,'sys_file_reference',27,'',0,0,2147483647,0,0,''),
('56b7487b342b18edb6d1c2816b74ba45','sys_file_reference',5,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('573a4dca6df00fe35d62df2d0a9cac00','tx_mask_apartments',4,'tx_mask_pdf',0,0,2147483647,0,'','','',0,0,'sys_file_reference',44,'',0,0,2147483647,0,0,''),
('574e04733ee053469f70924d412e00e1','sys_file',12,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',12,'',0,0,2147483647,0,0,''),
('58749618f0e61574eb6c8142a1351107','sys_file_reference',9,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',9,'',0,0,2147483647,0,0,''),
('59c7319c41b3f5fd154aab420e38af03','sys_file',15,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('5a91e78f4ba57de753144527a4e0ed4f','tt_content',1,'tx_mask_image_first_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',3,'',0,0,2147483647,0,0,''),
('5c5c708d6f72da78f5f0240ceccdb4d0','tx_powermail_domain_model_field',4,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('5d84d5ba7c3bfcf63ba2b282c71c9366','sys_file_reference',30,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('5e1c80364390a7e2e74cf26d556b1f9b','tt_content',32,'tx_mask_apartments',0,0,2147483647,0,'','','',2,0,'tx_mask_apartments',3,'',0,0,2147483647,0,0,''),
('60c3ad76b5e939126dae5d29e94bf064','tt_content',7,'tx_mask_link',0,0,2147483647,0,'','typolink','4813c02b9d0cf50c6ed946333abb653b:0',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('60fbaa0d303d3d21fde731eda7865de5','sys_file_reference',23,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',14,'',0,0,2147483647,0,0,''),
('63f5e5b7d1805b377f4e9e6038f02325','tx_mask_places',5,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('63f95fe7cd6ff73e74aa9df923bacdb6','sys_file_reference',2,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',5,'',0,0,2147483647,0,0,''),
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('64f91d9385c66159e0535b5b94f95d8f','sys_file',25,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('656b2851ee7dddc375e1caf43969289a','sys_file',26,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('664fdbfa7a902074489d8fe9975d993a','tx_mask_apartments',4,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',32,'',0,0,2147483647,0,0,''),
('66e9b03dd695851dedd81caf93830032','sys_file_reference',33,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',8,'',0,0,2147483647,0,0,''),
('69982b2a98cbef53cc80295c48be6116','sys_file',17,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('69c7f7764a16ab4dea97a7135f5f49f5','tx_mask_apartments',2,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',32,'',0,0,2147483647,0,0,''),
('6a94b41f5ae34b7bae0ec9070182ed92','sys_file',13,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('6ad2b796fd0cbcb166cca5093b699511','tx_powermail_domain_model_field',5,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('70256a47356305f766a201d9ecb2f2c8','tt_content',11,'tx_mask_simple_image_class',0,0,2147483647,0,'','','',1,0,'sys_file_reference',17,'',0,0,2147483647,0,0,''),
('72887a592be8e6b5332e9751721ed2ff','tt_content',10,'tx_mask_extra_text_right_side',0,0,2147483647,0,'','typolink_tag','3',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@adowia.ch'),
('731a3e934d4284dc1337694ff2a2e91a','sys_file',22,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('74f89f508a8d8465607d030c6629dc92','sys_file_reference',1,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('7500a4999b67ff07ac7c056a1c3385fd','sys_file_reference',3,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',6,'',0,0,2147483647,0,0,''),
('77c1b13d2222b2a264bf63ae39a484d0','sys_file',9,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('784fe3ba729fd36e9b07cad6dfd98558','tt_content',26,'tx_mask_simple_image_class',0,0,2147483647,0,'','','',0,0,'sys_file_reference',33,'',0,0,2147483647,0,0,''),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('7b4a4e370c1e1cfae92bc39e440e5868','tt_content',10,'tx_mask_smallink_below',0,0,2147483647,0,'','typolink','ef1791d8aae7076649986e070d543b5c:0',0,0,'pages',5,'',0,0,2147483647,0,0,''),
('7ba992bbccb9e919afcc3d02e58d610f','tt_content',3,'tx_mask_image_first_column',0,0,2147483647,0,'','','',1,0,'sys_file_reference',9,'',0,0,2147483647,0,0,''),
('7bc8f2b4dd42ac732ccd2663dfc2c89c','sys_file_reference',43,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('80c4957496e22252d040432422efe9c3','tx_mask_apartments',2,'tx_mask_pdf',0,0,2147483647,0,'','','',0,0,'sys_file_reference',42,'',0,0,2147483647,0,0,''),
('825aada1766f403b76e9adc3ff3908d2','tx_powermail_domain_model_field',1,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('82c21e11bc6f1dcff8aa3ccd54bd2d7a','tt_content',32,'tx_mask_apartments',0,0,2147483647,0,'','','',1,0,'tx_mask_apartments',2,'',0,0,2147483647,0,0,''),
('82e712977c1fa4a6ba3e5b993c315da3','tt_content',30,'tx_mask_content_second_column',0,0,2147483647,0,'','','',0,0,'tt_content',31,'',0,0,2147483647,0,0,''),
('85ce5f98e1d11d3a63413f8c25da17d8','sys_file',19,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('86ad52913788fdf884667de8802859c3','tx_mask_places',3,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('87a03d2706f7ebf76d3158b9f1e12310','tt_content',3,'tx_mask_image_second_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',10,'',0,0,2147483647,0,0,''),
('882c47779d94bb603f0119efd780f4e1','tt_content',16,'tx_mask_image_first_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',39,'',0,0,2147483647,0,0,''),
('8b0150d4f62fda6824bf3c42237f897f','tt_content',29,'tx_mask_places',0,0,2147483647,0,'','','',0,0,'tx_mask_places',1,'',0,0,2147483647,0,0,''),
('8d20646af662092f2ec1cf930987beb0','tx_powermail_domain_model_page',1,'form',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_form',1,'',0,0,2147483647,0,0,''),
('8d76fd4e84510152211bc0f4ebe1be0a','tx_mask_apartments',5,'tx_mask_pdf',0,0,2147483647,0,'','','',0,0,'sys_file_reference',45,'',0,0,2147483647,0,0,''),
('8f244cc6f1183583658a81fed6599af8','sys_file',18,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',18,'',0,0,2147483647,0,0,''),
('8faa51247ba724a99b31a800286e2a69','sys_file_reference',41,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('90e7f3da34d7608360de732c74672093','tt_content',23,'tx_mask_simple_image_class',0,0,2147483647,0,'','','',0,0,'sys_file_reference',31,'',0,0,2147483647,0,0,''),
('992d2d59bc44f3553bbd664be00fdbae','tt_content',15,'tx_mask_add_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',20,'',0,0,2147483647,0,0,''),
('9ba6379e955236cdc93fdc47bbebede1','tx_mask_accordion_with_data',1,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',31,'',0,0,2147483647,0,0,''),
('9bbed8a3e23490c1ce2f601b942e1654','tx_mask_places',4,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('9bf136258c189276fa32d7f3bc7f4015','tt_content',10,'tx_mask_extra_text_right_side',0,0,2147483647,0,'','email','2',0,0,'_STRING',0,'',0,0,2147483647,0,0,'info@adowia.ch'),
('9dbdd09d43af8f4987bcb73392d99394','tx_mask_apartments',3,'tx_mask_pdf',0,0,2147483647,0,'','','',0,0,'sys_file_reference',43,'',0,0,2147483647,0,0,''),
('9f4f80f7417765a1fd405687474b2680','sys_file',18,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('9f8158e2f474bac65ea229f25287a92e','sys_file_reference',15,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',14,'',0,0,2147483647,0,0,''),
('a26601f65c446338abc6d80cbc6aa0db','tt_content',20,'tx_mask_add_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',23,'',0,0,2147483647,0,0,''),
('a2a81f6c6de35aedd69d97f59dbb40ee','tx_mask_places',1,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('a5569eb2c78f693f9a101eeef82735ec','tt_content',30,'tx_mask_image_first_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',40,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a6e96dbd49b65b44379422999bef3997','sys_file_reference',26,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',19,'',0,0,2147483647,0,0,''),
('a71d156cbbc1fd0aea0e6f9e84024815','sys_file',14,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a7930c4ec9856a664a67607bcb6b83b6','tt_content',32,'tx_mask_apartments',0,0,2147483647,0,'','','',3,0,'tx_mask_apartments',4,'',0,0,2147483647,0,0,''),
('a8ae560441da233771408a7e6b28c1b6','sys_file',20,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('aaa50d14f0e159bd3931bcdfdb82d5b2','tt_content',21,'tx_mask_image_second_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',25,'',0,0,2147483647,0,0,''),
('aac3dd048e1283643c1695f07b1d20bb','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',4,0,'tx_powermail_domain_model_field',5,'',0,0,2147483647,0,0,''),
('ab3cf07851ca609d758eb6721188767f','tt_content',5,'tx_mask_image_second_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',13,'',0,0,2147483647,0,0,''),
('ac116c952c32a114f34e17c7575c96e6','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',2,0,'tx_powermail_domain_model_field',3,'',0,0,2147483647,0,0,''),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('ae80e0ed2f2d9beb7030e3069a3856cb','tx_mask_apartments',6,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',32,'',0,0,2147483647,0,0,''),
('aee547857f6141802dab956d643f67a0','tx_mask_apartments',5,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',32,'',0,0,2147483647,0,0,''),
('b32e3178cab69b832b1bd405526602d0','tx_mask_accordion_with_data',2,'tx_mask_text_accordeon',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('b6a9111e75c2f990d02c79c08a60b8b4','tt_content',23,'tx_mask_simple_image_class',0,0,2147483647,0,'','','',1,0,'sys_file_reference',32,'',0,0,2147483647,0,0,''),
('b84fd590a7528020ea5b6dce553c529b','sys_file_reference',47,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('b8ca7445cd6c6aa7880601bbe709707f','sys_file',14,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',14,'',0,0,2147483647,0,0,''),
('b8d0fd897fdd90c98ade83720d16a646','sys_file',19,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',19,'',0,0,2147483647,0,0,''),
('bb11bfcd9fbe307d2c6e64fb6547fda6','tt_content',17,'pi_flexform',0,0,2147483647,0,'main/lDEF/settings.flexform.main.form/vDEF/','','',0,0,'tx_powermail_domain_model_form',1,'',0,0,2147483647,0,0,''),
('c05ba4d229e67b24a14c15fcfccca35c','tt_content',20,'tx_mask_smallink_below',0,0,2147483647,0,'','typolink','52f2a4dff936ccc27ab98a4f181a2e43:0',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('c0ad726ebb73d7e0bbd92b5deed31994','sys_file_reference',37,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',24,'',0,0,2147483647,0,0,''),
('c1874037c7077a6f79802e9d4b5d1469','tt_content',28,'tx_mask_image_second_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',37,'',0,0,2147483647,0,0,''),
('c47a797b1e46b346553bd44455bbef56','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',1,0,'tx_powermail_domain_model_field',2,'',0,0,2147483647,0,0,''),
('c51082a0cfb0fd54329d3ac566d0d3d9','tx_mask_places',2,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('c8a072d69c325051d32e8d673550a9d6','sys_file_reference',45,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('ca0780371b778fca9ffe46744e3d9a3a','sys_file_reference',13,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',12,'',0,0,2147483647,0,0,''),
('ccc76f735cb38dca39df162b0b627353','sys_file',12,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('ce5d84aa39bed2c184ece9ab314fecc2','tx_powermail_domain_model_field',2,'page',0,0,2147483647,0,'','','',0,0,'tx_powermail_domain_model_page',1,'',0,0,2147483647,0,0,''),
('cfa5736f94652537c375b6a89019c1f3','sys_file_reference',10,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',10,'',0,0,2147483647,0,0,''),
('cfe176725d8fcd32847425c3d6a35eb6','tx_mask_accordion_with_data',1,'tx_mask_text_accordeon',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('d04e0c4a8cf1838ebbc9b7599bb2e042','tx_mask_tabs_map',3,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',29,'',0,0,2147483647,0,0,''),
('d1ce3b22fd9a5b6b1d4fbc8de942afe2','pages',2,'media',0,0,2147483647,0,'','','',0,0,'sys_file_reference',1,'',0,0,2147483647,0,0,''),
('d275908e4ef7db9959a59ff8bd28dddd','tt_content',9,'tx_mask_add_image',0,0,2147483647,0,'','','',0,0,'sys_file_reference',14,'',0,0,2147483647,0,0,''),
('d65f2190aeac9098c5e7f0dd5a100918','sys_file_reference',39,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',25,'',0,0,2147483647,0,0,''),
('d860d9389667c92145871d401a40f562','sys_file',6,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',6,'',0,0,2147483647,0,0,''),
('da30c04627741e0d02ee6b301fcfbe3e','sys_file_reference',28,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',21,'',0,0,2147483647,0,0,''),
('dd6e06a2c9cd98f2ba43ef232bfddca0','tx_mask_accordion_with_data',3,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',31,'',0,0,2147483647,0,0,''),
('ddb0486620e0393165318a07cbbc4b8e','sys_file',21,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('deb7e17a215d4eeaa4808de39668c3ef','sys_file_reference',40,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',24,'',0,0,2147483647,0,0,''),
('df7fbb4834b3f1a28a6d9fc8f16be3f1','sys_file_reference',32,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',23,'',0,0,2147483647,0,0,''),
('e00ea458c2b4d6b35f23546e98c4c4a9','tt_content',10,'tx_mask_extra_text_right_side',0,0,2147483647,0,'','typolink_tag','1',0,0,'_STRING',0,'',0,0,2147483647,0,0,'+41797737519'),
('e102e6fdd7d7709254dbbf76876218b1','tx_mask_accordion_with_data',2,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',31,'',0,0,2147483647,0,0,''),
('e2072dc81768213c676c2f0af5706fb8','sys_file_reference',12,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',11,'',0,0,2147483647,0,0,''),
('e3ee75fb6ad8bb587c25ffb3531dbecb','tt_content',21,'tx_mask_image_second_column',0,0,2147483647,0,'','','',1,0,'sys_file_reference',26,'',0,0,2147483647,0,0,''),
('e42ed6290e07dfc94cd0d943d46f64bb','tx_mask_accordion_with_data',3,'tx_mask_text_accordeon',0,0,2147483647,0,'','typolink_tag','1',0,0,'pages',3,'',0,0,2147483647,0,0,''),
('e47c9ae5d8f1040d3df8c1fa69a7fe5d','tx_mask_apartments',3,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',32,'',0,0,2147483647,0,0,''),
('e5f01943e3261ab8be95460f1222660a','sys_file',17,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',17,'',0,0,2147483647,0,0,''),
('e6ae20ecdc91993983801ec95da4893d','sys_file_reference',27,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',20,'',0,0,2147483647,0,0,''),
('e8615de88de3637661a6eb67c3465a94','tt_content',31,'tx_mask_accordion_with_data',0,0,2147483647,0,'','','',2,0,'tx_mask_accordion_with_data',3,'',0,0,2147483647,0,0,''),
('e908da7e7ad7c85d4062aeee1b0fdebb','tt_content',29,'tx_mask_places',0,0,2147483647,0,'','','',1,0,'tx_mask_places',2,'',0,0,2147483647,0,0,''),
('e929cbf4625a7dfcc8697279c8a382b7','tx_powermail_domain_model_page',1,'fields',0,0,2147483647,0,'','','',5,0,'tx_powermail_domain_model_field',6,'',0,0,2147483647,0,0,''),
('ea6965a2a5e92ee2be94d60f034bdcc8','sys_file_reference',42,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',26,'',0,0,2147483647,0,0,''),
('ea9a5f1416c185f2b5f9ad41ce2e6995','sys_file_reference',25,'uid_local',0,0,2147483647,0,'','','',0,0,'sys_file',18,'',0,0,2147483647,0,0,''),
('ec1d0f81741248272d9d3ffccdd412a4','tx_mask_apartments',1,'parentid',0,0,2147483647,0,'','','',0,0,'tt_content',32,'',0,0,2147483647,0,0,''),
('f0c897c2ec73563d1eaa03b11332bbb0','tt_content',29,'tx_mask_tabs_map',0,0,2147483647,0,'','','',0,0,'tx_mask_tabs_map',1,'',0,0,2147483647,0,0,''),
('f22f11ea3dbcc3d044a1dc5cc08665ca','tt_content',11,'tx_mask_simple_image_class',0,0,2147483647,0,'','','',0,0,'sys_file_reference',16,'',0,0,2147483647,0,0,''),
('f314d7d7160398937ff84f7b9d34bba8','sys_file',24,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f316bb3ffbe5584babdc96fabc6f70eb','tt_content',18,'tx_mask_text_text_on_colorful_background',1,0,2147483647,0,'','typolink_tag','1',0,0,'pages',2,'',0,0,2147483647,0,0,''),
('f6062209d87aa82eace335f4ab0c7610','sys_file',10,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f6496082c060daf588c2ea74953f2e63','tt_content',29,'tx_mask_tabs_map',0,0,2147483647,0,'','','',3,0,'tx_mask_tabs_map',4,'',0,0,2147483647,0,0,''),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f88c3208c70ea74317bdbd5e6a5dc7e4','tt_content',4,'tx_mask_simple_image_class',0,0,2147483647,0,'','','',0,0,'sys_file_reference',12,'',0,0,2147483647,0,0,''),
('fb9c934b520085056d7e7a2b91741b0d','tt_content',32,'tx_mask_apartments',0,0,2147483647,0,'','','',4,0,'tx_mask_apartments',5,'',0,0,2147483647,0,0,''),
('fd0c11bdff517b0ff1303df3a2024272','tt_content',29,'tx_mask_places',0,0,2147483647,0,'','','',3,0,'tx_mask_places',4,'',0,0,2147483647,0,0,''),
('ff904e7f2736621d4180c009942733bb','tt_content',3,'tx_mask_image_first_column',0,0,2147483647,0,'','','',0,0,'sys_file_reference',8,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\IndexedSearchCTypeMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PagesRecyclerDoktypeMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Extensionmanager\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(12,'installUpdate','MASK\\Mask\\Updates\\ConvertTemplatesToUppercase','i:1;'),
(13,'installUpdate','MASK\\Mask\\Updates\\FillTranslationSourceField','i:1;'),
(14,'installUpdate','MASK\\Mask\\Updates\\MigrateContentFields','i:1;'),
(15,'installUpdate','MASK\\Mask\\Updates\\MoveRteOptions','i:1;'),
(16,'installUpdateRows','rowUpdatersDone','a:1:{i:0;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(18,'core','formProtectionSessionToken:2','s:64:\"46c9b78ed6f52620fd865ffc63de25f8cc0695f755ed5c7b645e3b3d069bace0\";'),
(19,'languagePacks','de-site_package','i:1777016381;'),
(20,'languagePacks','de','i:1777016381;');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_workspace`
--

DROP TABLE IF EXISTS `sys_workspace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_workspace` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(30) NOT NULL DEFAULT '',
  `adminusers` longtext DEFAULT NULL,
  `members` longtext DEFAULT NULL,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `publish_time` bigint(20) NOT NULL DEFAULT 0,
  `freeze` smallint(5) unsigned NOT NULL DEFAULT 0,
  `live_edit` smallint(5) unsigned NOT NULL DEFAULT 0,
  `publish_access` smallint(5) unsigned NOT NULL DEFAULT 0,
  `previewlink_lifetime` int(11) NOT NULL DEFAULT 0,
  `stagechg_notification` smallint(5) unsigned NOT NULL DEFAULT 1,
  `custom_stages` int(10) unsigned NOT NULL DEFAULT 0,
  `edit_notification_defaults` longtext DEFAULT NULL,
  `edit_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `edit_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 2,
  `publish_notification_defaults` longtext DEFAULT NULL,
  `publish_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `publish_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 1,
  `execute_notification_defaults` longtext DEFAULT NULL,
  `execute_allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `execute_notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 3,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace`
--

LOCK TABLES `sys_workspace` WRITE;
/*!40000 ALTER TABLE `sys_workspace` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_workspace` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_workspace_stage`
--

DROP TABLE IF EXISTS `sys_workspace_stage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_workspace_stage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `parentid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(30) NOT NULL DEFAULT '',
  `responsible_persons` longtext DEFAULT NULL,
  `default_mailcomment` longtext DEFAULT NULL,
  `notification_defaults` longtext DEFAULT NULL,
  `allow_notificaton_settings` smallint(5) unsigned NOT NULL DEFAULT 3,
  `notification_preselection` smallint(5) unsigned NOT NULL DEFAULT 8,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_workspace_stage`
--

LOCK TABLES `sys_workspace_stage` WRITE;
/*!40000 ALTER TABLE `sys_workspace_stage` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_workspace_stage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 0,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_add_titiel_elo` longtext DEFAULT NULL,
  `tx_mask_all_cases` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_clienst_second_col` longtext DEFAULT NULL,
  `tx_mask_clients_first_colum` longtext DEFAULT NULL,
  `tx_mask_images_for_this_case` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_photo_info` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_text_info` longtext DEFAULT NULL,
  `tx_mask_text_to_start` longtext DEFAULT NULL,
  `tx_mask_text_first_col` mediumtext DEFAULT NULL,
  `tx_mask_image_first_column` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_color_first_column` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_text_second_column` mediumtext DEFAULT NULL,
  `tx_mask_image_second_column` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_color_second_column` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_height_of_the_elemnet` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_text_white_first_col` int(11) NOT NULL DEFAULT 0,
  `tx_mask_text_white_second_column` int(11) NOT NULL DEFAULT 0,
  `tx_mask_simple_image_class` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_color_of_the_lement` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_text_text_on_colorful_background` mediumtext DEFAULT NULL,
  `tx_mask_link` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_layout_choose` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_text_to_link` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_make_my_life_colorfull` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_add_image` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_image_on_the_right_side` int(11) NOT NULL DEFAULT 0,
  `tx_mask_copy_textus` mediumtext DEFAULT NULL,
  `tx_mask_extra_text_right_side` mediumtext DEFAULT NULL,
  `tx_mask_small_contact_text_below_text` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_smallink_below` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_text_whiteee` int(11) NOT NULL DEFAULT 0,
  `tx_mask_height_of_the_element` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_design_layout` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_content_second_column` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_content_parent_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_content_role` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_content_tablenames` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_bigger_text` int(11) NOT NULL DEFAULT 0,
  `tx_mask_text_instead_of_button` mediumtext DEFAULT NULL,
  `tx_mask_tabs_map` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_places` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_accordion_with_data` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_apartments` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `CType` (`CType`),
  KEY `translation_source` (`l10n_source`),
  KEY `tx_mask_content_parent_uid` (`tx_mask_content_parent_uid`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,2,1776947735,1776945701,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'',1,'','',1,'','2',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(2,2,1776947519,1776947519,0,0,0,0,'',512,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mask_simple_image',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,1,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(3,2,1776947924,1776947889,0,0,0,0,'',768,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'',2,'','',1,'','2',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(4,2,1776948038,1776948027,0,0,0,0,'',1024,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_simple_image_class\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_simple_image',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,1,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(5,2,1776948204,1776948189,0,0,0,0,'',640,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'<p>Konolfingen?<br />Konolfingen.</p>',0,'#F6F2EC','',1,'','2',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(6,2,1777018242,1776948964,0,0,0,0,'',384,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_bigger_text\":\"\",\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_link\":\"\",\"tx_mask_text_text_on_colorful_background\":\"\",\"tx_mask_text_to_link\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#C7CAC5','<p>DREI WOHNWELTEN DREI ARTEN SICH ZUHAUSE ZU FÜHLEN.</p>','','4','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',1,NULL,0,0,0,0),
(7,2,1776949675,1776949548,0,0,0,0,'',704,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_link\":\"\",\"tx_mask_text_text_on_colorful_background\":\"\",\"tx_mask_text_to_link\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#B9A99A','<p>Text über Konolfingen sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','t3://page?uid=3','3','Mehr erfahren','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(8,2,1776949885,1776949885,0,0,0,0,'',128,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'Modernes Wohnprojekt in Konolfingen Häuser, Garten- und Terrassenwohnungen',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#F6F2EC','<p>Einleitungstext zum Projekt Grünegg sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','','0','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(9,2,1776953671,1776952060,0,0,0,0,'',896,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_add_image\":\"\",\"tx_mask_copy_textus\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_height_of_the_element\":\"\",\"tx_mask_image_on_the_right_side\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_info_contact_two_columns',0,0,'','',0,'Wer findet in grünegg das passende zuhause?',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','#48433F',1,0,'<p>Text über die Zielgruppe sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','','','',1,'2','0',0,0,'','',0,NULL,0,0,0,0),
(10,2,1776954054,1776952821,0,0,0,0,'',1280,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_add_image\":\"\",\"tx_mask_copy_textus\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_height_of_the_element\":\"\",\"tx_mask_image_on_the_right_side\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_info_contact_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','#F6F2EC',1,0,'<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','<p><a href=\"tel:+41797737519\">+41 79 773 75 19</a><br /><a href=\"mailto:info@adowia.ch\">info@adowia.ch</a></p>','Kontakt aufnehmen','t3://page?uid=5',0,'2','1',0,0,'','',0,NULL,0,0,0,0),
(11,3,1776955772,1776954685,0,0,0,0,'',64,'',0,0,0,0,NULL,'{\"colPos\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_simple_image',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,2,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(12,3,1776955761,1776955738,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_link\":\"\",\"tx_mask_text_text_on_colorful_background\":\"\",\"tx_mask_text_to_link\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'Wohnungen im überblick',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#E2E4E6','<p>Einleitungstext zu den Objekten sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','','0','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(13,4,1776955987,1776955864,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'',1,'','<p>Konolfingen?<br />Konolfingen.</p>',0,'#B9A99A','2',0,1,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(14,4,1776956029,1776956029,0,0,0,0,'',512,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#F6F2EC','<p>Text über Konolfingen dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','','4','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(15,5,1777021694,1776956137,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_add_image\":\"\",\"tx_mask_copy_textus\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_height_of_the_element\":\"\",\"tx_mask_image_on_the_right_side\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_info_contact_two_columns',0,0,'','',0,'Beratung und Verkauf',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','#D3D6D7',1,1,'<p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>\r\n<p>Dominique Andreas Waser<br />Inhaber und Geschäftsführer Adowia</p>','','Zum Kontaktformular','t3://page?uid=5#here-16',0,'2','2',0,0,'','',0,NULL,0,0,0,0),
(16,5,1777021856,1777014061,0,0,0,0,'',512,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_content_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'',1,'','',0,'#F6F2EC','2',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',1,0,'','',0,NULL,0,0,0,0),
(17,5,1777021856,1777014640,0,0,0,0,'',1,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'default',999,NULL,0,'powermail_pi1',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"main\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.main.form\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.flexform.main.confirmation\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.optin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.moresteps\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.pid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"receiver\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.receiver.type\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.receiver.name\">\n                    <value index=\"vDEF\">Adowia – Dominique Andreas Waser</value>\n                </field>\n                <field index=\"settings.flexform.receiver.email\">\n                    <value index=\"vDEF\">dani@studiothompfister.com</value>\n                </field>\n                <field index=\"settings.flexform.receiver.subject\">\n                    <value index=\"vDEF\">Grünegg | Nachricht über das Kontaktformular</value>\n                </field>\n                <field index=\"settings.flexform.receiver.body\">\n                    <value index=\"vDEF\">&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"sender\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.sender.name\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.email\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.subject\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.body\">\n                    <value index=\"vDEF\">&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"thx\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.thx.body\">\n                    <value index=\"vDEF\">&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n                <field index=\"settings.flexform.thx.redirect\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,16,'tx_mask_content_second_column','tt_content',0,NULL,0,0,0,0),
(18,10,1777014914,1777014845,0,1,0,0,'',256,'',0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'Danke für Ihre Nachricht',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#D3D6D7','<p class=\"text-center\">&nbsp;</p>\r\n<p class=\"text-center\">&nbsp;</p>\r\n<p class=\"text-center\">Vielen Dank für Ihre Nachricht.<br />Ich werde mich zeitnah bei Ihnen melden.<br /><br />Freundliche Grüsse<br />Dominique Andreas Waser<br />Inhaber und Geschäftsführer<br />Adowia Immobilien AG</p>\r\n<p class=\"text-center\">&nbsp;</p>\r\n<p class=\"text-center\"><a href=\"t3://page?uid=2\">Zurück zur Homepage</a></p>\r\n<p class=\"text-center\">&nbsp;</p>\r\n<p class=\"text-center\">&nbsp;</p>','','4','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(19,10,1777015006,1777014917,1,0,0,0,'',128,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_add_image\":\"\",\"tx_mask_copy_textus\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_height_of_the_element\":\"\",\"tx_mask_image_on_the_right_side\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_info_contact_two_columns',0,0,'','',0,'Danke für Ihre Nachricht',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','#F6F2EC',1,1,'<h1 class=\"text-center\"><strong>Vielen Dank für Ihre Nachricht.</strong></h1>\r\n<p class=\"text-center\">Ich werde mich zeitnah bei Ihnen melden.<br /><br />Freundliche Grüsse<br />Dominique Andreas Waser<br />Inhaber und Geschäftsführer<br />Adowia Immobilien AG</p>\r\n<p class=\"text-center\">&nbsp;</p>\r\n<p class=\"text-center\"><a href=\"t3://page?uid=2\">Zurück zur Homepage</a></p>','','Zurück zur Homepage','t3://page?uid=2',0,'2','1',0,0,'','',0,NULL,0,0,0,0),
(20,10,1777015065,1777015013,0,0,0,0,'',128,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_add_image\":\"\",\"tx_mask_copy_textus\":\"\",\"tx_mask_design_layout\":\"\",\"tx_mask_extra_text_right_side\":\"\",\"tx_mask_height_of_the_element\":\"\",\"tx_mask_image_on_the_right_side\":\"\",\"tx_mask_make_my_life_colorfull\":\"\",\"tx_mask_small_contact_text_below_text\":\"\",\"tx_mask_smallink_below\":\"\",\"tx_mask_text_whiteee\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_info_contact_two_columns',0,0,'','',0,'Vielen Dank für Ihre Nachricht',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','#D3D6D7',1,1,'<p>Ich werde mich zeitnah bei Ihnen melden.<br /><br />Freundliche Grüsse<br />Dominique Andreas Waser<br />Inhaber und Geschäftsführer<br />Adowia Immobilien AG</p>','','Zurück zur Homepage','t3://page?uid=2',0,'2','2',0,0,'','',0,NULL,0,0,0,0),
(21,4,1777018490,1777018374,0,0,0,0,'',768,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_content_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'<p>Nah dran nicht mittendrin genau richtig</p>',0,'#C7CAC5','',3,'','1',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(22,4,1777019554,1777019445,0,0,0,0,'',1024,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_content_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'',3,'','<p>Alltag mit&nbsp;<br />kurzen wegen</p>',0,'#48433F','0',0,1,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(23,4,1777019783,1777019775,0,0,0,0,'',896,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_simple_image_class\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_simple_image',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,2,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(24,4,1777019838,1777019838,0,0,0,0,'',960,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#F6F2EC','<p>Vorteile von Konolfingen als Wohnort dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','','3','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(25,4,1777020049,1777019879,0,0,0,0,'',1280,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_bigger_text\":\"\",\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_link\":\"\",\"tx_mask_text_instead_of_button\":\"\",\"tx_mask_text_text_on_colorful_background\":\"\",\"tx_mask_text_to_link\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'Optimale  Verkehrsanbindungen',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#F6F2EC','<p>Vorteile von Konolfingen als Wohnort dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','','3','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,'<p>20 min. nach Thun<br />20 min. nach Burgdorf<br />25 min. nach Bern</p>',0,0,0,0),
(26,3,1777020490,1777020490,0,0,0,0,'',384,'',0,0,0,0,NULL,'',0,0,0,0,'default',0,NULL,0,'mask_simple_image',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,1,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(27,3,1777020658,1777020618,0,0,0,0,'',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_bigger_text\":\"\",\"tx_mask_color_of_the_lement\":\"\",\"tx_mask_layout_choose\":\"\",\"tx_mask_link\":\"\",\"tx_mask_text_instead_of_button\":\"\",\"tx_mask_text_text_on_colorful_background\":\"\",\"tx_mask_text_to_link\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_text_on_colorful_background',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'#F6F2EC','<p>Vorteile von Konolfingen als Wohnort dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.&nbsp;</p>','','3','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(28,3,1777021078,1777020957,0,0,0,0,'',192,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_content_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,'',0,'',0,'',1,0,NULL,'0','',0,0,'',124,0,0,0,'',0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'<p>Keller und&nbsp;<br />einstellhallenplätze</p>',0,'#D9D0C8','',1,'','1',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,0),
(29,4,1777028903,1777024292,0,0,0,0,'',1536,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_places\":\"\",\"tx_mask_tabs_map\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_location_map',0,0,'','',0,'Map',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,4,5,0,0),
(30,2,1777029973,1777029480,0,0,0,0,'',448,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_color_first_column\":\"\",\"tx_mask_color_second_column\":\"\",\"tx_mask_content_second_column\":\"\",\"tx_mask_height_of_the_elemnet\":\"\",\"tx_mask_image_first_column\":\"\",\"tx_mask_image_second_column\":\"\",\"tx_mask_text_first_col\":\"\",\"tx_mask_text_second_column\":\"\",\"tx_mask_text_white_first_col\":\"\",\"tx_mask_text_white_second_column\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_two_columns',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,'',1,'#E1DCD7','',0,'#E1DCD7','2',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',1,0,'','',0,NULL,0,0,0,0),
(31,2,1777029973,1777029811,0,0,0,0,'',1,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_accordion_with_data\":\"\"}',0,0,0,0,'default',999,NULL,0,'mask_akkordeon',0,0,'','',0,'',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"main\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.main.form\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.main.confirmation\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.optin\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.moresteps\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.main.pid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"receiver\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.receiver.type\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.flexform.receiver.name\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.receiver.email\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.receiver.subject\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.receiver.body\">\n                    <value index=\"vDEF\">&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"sender\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.sender.name\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.email\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.subject\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.flexform.sender.body\">\n                    <value index=\"vDEF\">&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"thx\">\n            <language index=\"lDEF\">\n                <field index=\"settings.flexform.thx.body\">\n                    <value index=\"vDEF\">&lt;p&gt;{powermail_all}&lt;/p&gt;</value>\n                </field>\n                <field index=\"settings.flexform.thx.redirect\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,30,'tx_mask_content_second_column','tt_content',0,NULL,0,0,3,0),
(32,3,1777266972,1777121599,0,0,0,0,'',160,'',0,0,0,0,NULL,'{\"CType\":\"\",\"categories\":\"\",\"colPos\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"frame_class\":\"\",\"header\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"tx_mask_apartments\":\"\"}',0,0,0,0,'default',0,NULL,0,'mask_apartments',0,0,'','',0,'Wohnungen',0,'','','',NULL,0,0,0,0,0,0,0,2,NULL,0,'',0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0,NULL,0,NULL,NULL,0,0,NULL,NULL,NULL,0,'',NULL,0,'','',0,0,0,'',NULL,'','','','',0,0,NULL,NULL,'','',0,'','',0,0,'','',0,NULL,0,0,0,7);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `state` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `last_updated` bigint(20) NOT NULL DEFAULT 0,
  `update_comment` longtext DEFAULT NULL,
  `current_version` smallint(5) unsigned NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_linkvalidator_link`
--

DROP TABLE IF EXISTS `tx_linkvalidator_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_linkvalidator_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `language` int(11) NOT NULL DEFAULT -1,
  `headline` varchar(255) NOT NULL DEFAULT '',
  `field` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `element_type` varchar(255) NOT NULL DEFAULT '',
  `link_title` text DEFAULT NULL,
  `url` text DEFAULT NULL,
  `url_response` text DEFAULT NULL,
  `last_check` int(11) NOT NULL DEFAULT 0,
  `link_type` varchar(50) NOT NULL DEFAULT '',
  `needs_recheck` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_linkvalidator_link`
--

LOCK TABLES `tx_linkvalidator_link` WRITE;
/*!40000 ALTER TABLE `tx_linkvalidator_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_linkvalidator_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_mask_accordion_with_data`
--

DROP TABLE IF EXISTS `tx_mask_accordion_with_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mask_accordion_with_data` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tx_mask_text_accordeon` mediumtext DEFAULT NULL,
  `parentid` int(11) NOT NULL DEFAULT 0,
  `parenttable` varchar(255) DEFAULT '',
  `tx_mask_title_of_the_immo` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mask_accordion_with_data`
--

LOCK TABLES `tx_mask_accordion_with_data` WRITE;
/*!40000 ALTER TABLE `tx_mask_accordion_with_data` DISABLE KEYS */;
INSERT INTO `tx_mask_accordion_with_data` VALUES
(1,2,1777029973,1777029875,0,0,0,0,'',1,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_mask_text_accordeon\":\"\",\"tx_mask_title_of_the_immo\":\"\"}',0,0,0,0,'<p>Text über Häuser sit amet, consetetur sadipsc elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diamren voluptua. At vero eos et accusam et justo duolire dolores et ea rebum. Stet clita kasd gubergren, aus sea takimata sanctus est.</p>\r\n<p><br /><a href=\"t3://page?uid=3\">Häuser ansehen</a></p>',31,'tt_content','HAUS'),
(2,2,1777029973,1777029939,0,0,0,0,'',2,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'<p>Text über Häuser sit amet, consetetur sadipsc elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diamren voluptua. At vero eos et accusam et justo duolire dolores et ea rebum. Stet clita kasd gubergren, aus sea takimata sanctus est.</p>\r\n<p><br /><a href=\"t3://page?uid=3\">Häuser ansehen</a></p>',31,'tt_content','GARTENWOHNUNG'),
(3,2,1777029973,1777029939,0,0,0,0,'',3,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'<p>Text über Häuser sit amet, consetetur sadipsc elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diamren voluptua. At vero eos et accusam et justo duolire dolores et ea rebum. Stet clita kasd gubergren, aus sea takimata sanctus est.</p>\r\n<p><br /><a href=\"t3://page?uid=3\">Häuser ansehen</a></p>',31,'tt_content','TERASSENWOHNUNG');
/*!40000 ALTER TABLE `tx_mask_accordion_with_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_mask_all_cases`
--

DROP TABLE IF EXISTS `tx_mask_all_cases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mask_all_cases` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tx_mask_link_for_image` text NOT NULL DEFAULT '',
  `tx_mask_photo_case` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_text_on_image` longtext DEFAULT NULL,
  `parentid` int(10) unsigned NOT NULL DEFAULT 0,
  `parenttable` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_catgeory` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mask_all_cases`
--

LOCK TABLES `tx_mask_all_cases` WRITE;
/*!40000 ALTER TABLE `tx_mask_all_cases` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_mask_all_cases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_mask_apartments`
--

DROP TABLE IF EXISTS `tx_mask_apartments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mask_apartments` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tx_mask_number` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_floor` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_rooms` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_area` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_outside_area` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_status` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_pdf` int(10) unsigned NOT NULL DEFAULT 0,
  `tx_mask_unit_key` varchar(255) NOT NULL DEFAULT '',
  `parentid` int(11) NOT NULL DEFAULT 0,
  `parenttable` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mask_apartments`
--

LOCK TABLES `tx_mask_apartments` WRITE;
/*!40000 ALTER TABLE `tx_mask_apartments` DISABLE KEYS */;
INSERT INTO `tx_mask_apartments` VALUES
(1,3,1777266972,1777121599,0,0,0,0,'',1,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'56.01.1','0','3.5','98.01','40','0',1,'56011',32,'tt_content'),
(2,3,1777266972,1777121648,0,0,0,0,'',2,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'56.01.2','0','3.5','40','120','0',1,'',32,'tt_content'),
(3,3,1777266972,1777121695,0,0,0,0,'',3,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'56.01.3','0','3.5','49','120','0',1,'',32,'tt_content'),
(4,3,1777266972,1777121695,0,0,0,0,'',4,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'56.01.4','0','4.5','120','230','0',1,'',32,'tt_content'),
(5,3,1777266972,1777121736,0,0,0,0,'',5,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'56.01.5','0','3.5','80','120','0',1,'',32,'tt_content'),
(6,3,1777266972,1777121736,0,0,0,0,'',6,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_mask_area\":\"\",\"tx_mask_floor\":\"\",\"tx_mask_number\":\"\",\"tx_mask_outside_area\":\"\",\"tx_mask_pdf\":\"\",\"tx_mask_rooms\":\"\",\"tx_mask_status\":\"\",\"tx_mask_unit_key\":\"\"}',0,0,0,0,'56.01.7','0','3.5','120','80','0',1,'',32,'tt_content'),
(7,3,1777266972,1777266972,0,0,0,0,'',7,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"parentid\":\"\",\"sorting\":\"\",\"starttime\":\"\",\"tx_mask_area\":\"\",\"tx_mask_floor\":\"\",\"tx_mask_number\":\"\",\"tx_mask_outside_area\":\"\",\"tx_mask_pdf\":\"\",\"tx_mask_rooms\":\"\",\"tx_mask_status\":\"\",\"tx_mask_unit_key\":\"\"}',0,0,0,0,'56.01.8','3','4.5','120','80','0',1,'',32,'tt_content');
/*!40000 ALTER TABLE `tx_mask_apartments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_mask_places`
--

DROP TABLE IF EXISTS `tx_mask_places`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mask_places` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tx_mask_titel_place` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_category` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_latitude` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_longitude` varchar(255) NOT NULL DEFAULT '',
  `parentid` int(11) NOT NULL DEFAULT 0,
  `parenttable` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mask_places`
--

LOCK TABLES `tx_mask_places` WRITE;
/*!40000 ALTER TABLE `tx_mask_places` DISABLE KEYS */;
INSERT INTO `tx_mask_places` VALUES
(1,4,1777028903,1777024292,0,0,0,0,'',1,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'Bahnhof Konolfingen','1','46.88','7.62',29,'tt_content'),
(2,4,1777028903,1777024495,0,0,0,0,'',2,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'Coop Supermarkt','3','46.88116788005828','7.624048731683577',29,'tt_content'),
(3,4,1777028903,1777028828,0,0,0,0,'',3,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'Kindergarten Sonnrain','2','46.88292614710495','7.620393855262057',29,'tt_content'),
(4,4,1777028903,1777028865,0,0,0,0,'',4,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"tx_mask_category\":\"\",\"tx_mask_latitude\":\"\",\"tx_mask_longitude\":\"\",\"tx_mask_titel_place\":\"\"}',0,0,0,0,'Dropa Apotheke Konolfingen','4','46.8761761744072','7.6209579421116445',29,'tt_content'),
(5,4,1777028903,1777028903,0,0,0,0,'',5,0,0,0,0,NULL,0,'{\"editlock\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"hidden\":\"\",\"parentid\":\"\",\"sorting\":\"\",\"starttime\":\"\",\"tx_mask_category\":\"\",\"tx_mask_latitude\":\"\",\"tx_mask_longitude\":\"\",\"tx_mask_titel_place\":\"\"}',0,0,0,0,'Dr. med. Imholz Beat','4','46.87763226213031','7.620187670100313',29,'tt_content');
/*!40000 ALTER TABLE `tx_mask_places` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_mask_tabs_map`
--

DROP TABLE IF EXISTS `tx_mask_tabs_map`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_mask_tabs_map` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tx_mask_titel` varchar(255) NOT NULL DEFAULT '',
  `tx_mask_key` varchar(255) NOT NULL DEFAULT '',
  `parentid` int(11) NOT NULL DEFAULT 0,
  `parenttable` varchar(255) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_mask_tabs_map`
--

LOCK TABLES `tx_mask_tabs_map` WRITE;
/*!40000 ALTER TABLE `tx_mask_tabs_map` DISABLE KEYS */;
INSERT INTO `tx_mask_tabs_map` VALUES
(1,4,1777028903,1777024292,0,0,0,0,'',1,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'ÖV','1',29,'tt_content'),
(2,4,1777028903,1777024292,0,0,0,0,'',2,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'Schulen','2',29,'tt_content'),
(3,4,1777028903,1777024292,0,0,0,0,'',3,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'Einkaufen','3',29,'tt_content'),
(4,4,1777028903,1777024292,0,0,0,0,'',4,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'Gesundheit','4',29,'tt_content');
/*!40000 ALTER TABLE `tx_mask_tabs_map` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_powermail_domain_model_answer`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_answer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_answer` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `mail` int(10) unsigned NOT NULL DEFAULT 0,
  `value` text DEFAULT NULL,
  `value_type` int(10) unsigned NOT NULL DEFAULT 0,
  `field` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `mail` (`mail`),
  KEY `deleted` (`deleted`),
  KEY `hidden` (`hidden`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_answer`
--

LOCK TABLES `tx_powermail_domain_model_answer` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_powermail_domain_model_answer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_powermail_domain_model_field`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_field` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `page` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `type` varchar(255) NOT NULL DEFAULT '',
  `settings` text DEFAULT NULL,
  `path` varchar(255) NOT NULL DEFAULT '',
  `content_element` int(11) NOT NULL DEFAULT 0,
  `text` text DEFAULT NULL,
  `prefill_value` text DEFAULT NULL,
  `placeholder` text DEFAULT NULL,
  `placeholder_repeat` text DEFAULT NULL,
  `create_from_typoscript` text DEFAULT NULL,
  `validation` int(11) NOT NULL DEFAULT 0,
  `validation_configuration` varchar(255) NOT NULL DEFAULT '',
  `css` varchar(255) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `multiselect` smallint(5) unsigned NOT NULL DEFAULT 0,
  `datepicker_settings` varchar(255) NOT NULL DEFAULT '',
  `feuser_value` varchar(255) NOT NULL DEFAULT '',
  `sender_email` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sender_name` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mandatory` smallint(5) unsigned NOT NULL DEFAULT 0,
  `own_marker_select` smallint(5) unsigned NOT NULL DEFAULT 0,
  `marker` varchar(255) NOT NULL DEFAULT '',
  `mandatory_text` varchar(255) NOT NULL DEFAULT '',
  `autocomplete_token` varchar(20) NOT NULL DEFAULT '',
  `autocomplete_section` varchar(100) NOT NULL DEFAULT '',
  `autocomplete_type` varchar(8) NOT NULL DEFAULT '',
  `autocomplete_purpose` varchar(8) NOT NULL DEFAULT '',
  `auto_marker` smallint(5) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent_page` (`page`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_field`
--

LOCK TABLES `tx_powermail_domain_model_field` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_field` DISABLE KEYS */;
INSERT INTO `tx_powermail_domain_model_field` VALUES
(1,9,1777015530,1777014296,0,0,0,0,1,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Vorname','input','','',0,'','','','','',0,'','','',0,'','',0,1,1,0,'vorname','','','','','',0,''),
(2,9,1777015530,1777014325,0,0,0,0,2,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Name','input','','',0,'','','','','',0,'','','',0,'','',0,1,1,0,'name','','','','','',0,''),
(3,9,1777015530,1777014337,0,0,0,0,3,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'E-Mail','input','','',0,'','','','','',1,'','','',0,'','',1,0,1,0,'e_mail','','','','','',0,''),
(4,9,1777015530,1777014488,0,0,0,0,4,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Telefonnummer','input','','',0,'','','','','',0,'','','',0,'','',0,0,1,0,'telefonnummer','','','','','',0,''),
(5,9,1777015530,1777014502,0,0,0,0,5,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Ich interessiere mich für folgenden Wohnraum','textarea','','',0,'','','','','',0,'','','',0,'','',0,0,0,0,'ichinteressieremichfuerfolgendenwohnraum','','','','','',0,''),
(6,9,1777015530,1777014522,0,0,0,0,6,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,'Anfrage senden','submit','','',0,'','','','','',0,'','','',0,'','',0,0,0,0,'anfragesenden','','','','','',0,'');
/*!40000 ALTER TABLE `tx_powermail_domain_model_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_powermail_domain_model_form`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_form` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `note` smallint(5) unsigned NOT NULL DEFAULT 0,
  `css` varchar(255) NOT NULL DEFAULT '',
  `pages` varchar(255) NOT NULL DEFAULT '',
  `autocomplete_token` varchar(3) NOT NULL DEFAULT '',
  `is_dummy_record` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_form`
--

LOCK TABLES `tx_powermail_domain_model_form` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_form` DISABLE KEYS */;
INSERT INTO `tx_powermail_domain_model_form` VALUES
(1,9,1777015530,1777014296,0,0,0,0,0,0,NULL,0,'{\"autocomplete_token\":\"\",\"css\":\"\",\"endtime\":\"\",\"hidden\":\"\",\"pages\":\"\",\"starttime\":\"\",\"title\":\"\"}',0,0,0,0,'Contact form',0,'nolabel','1','',0,'');
/*!40000 ALTER TABLE `tx_powermail_domain_model_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_powermail_domain_model_mail`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_mail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_mail` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `sender_name` varchar(255) NOT NULL DEFAULT '',
  `sender_mail` varchar(255) NOT NULL DEFAULT '',
  `subject` varchar(255) NOT NULL DEFAULT '',
  `receiver_mail` varchar(1024) NOT NULL DEFAULT '',
  `body` text DEFAULT NULL,
  `feuser` int(11) NOT NULL DEFAULT 0,
  `sender_ip` tinytext NOT NULL,
  `user_agent` text DEFAULT NULL,
  `time` int(11) NOT NULL DEFAULT 0,
  `form` int(11) NOT NULL DEFAULT 0,
  `answers` int(10) unsigned NOT NULL DEFAULT 0,
  `marketing_referer_domain` text DEFAULT NULL,
  `marketing_referer` text DEFAULT NULL,
  `marketing_country` text DEFAULT NULL,
  `marketing_mobile_device` smallint(5) unsigned NOT NULL DEFAULT 0,
  `marketing_frontend_language` int(11) NOT NULL DEFAULT 0,
  `marketing_browser_language` text DEFAULT NULL,
  `marketing_page_funnel` text DEFAULT NULL,
  `spam_factor` varchar(255) NOT NULL DEFAULT '',
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `form` (`form`),
  KEY `feuser` (`feuser`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_mail`
--

LOCK TABLES `tx_powermail_domain_model_mail` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_mail` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_powermail_domain_model_mail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_powermail_domain_model_page`
--

DROP TABLE IF EXISTS `tx_powermail_domain_model_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_powermail_domain_model_page` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `form` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `css` varchar(255) NOT NULL DEFAULT '',
  `fields` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_label` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent_form` (`form`),
  KEY `language` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_powermail_domain_model_page`
--

LOCK TABLES `tx_powermail_domain_model_page` WRITE;
/*!40000 ALTER TABLE `tx_powermail_domain_model_page` DISABLE KEYS */;
INSERT INTO `tx_powermail_domain_model_page` VALUES
(1,9,1777015530,1777014296,0,0,0,0,1,0,0,NULL,0,'{\"css\":\"\",\"endtime\":\"\",\"fields\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"title\":\"\"}',0,0,0,0,1,'Contact form first page','nolabel',6,'');
/*!40000 ALTER TABLE `tx_powermail_domain_model_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task`
--

DROP TABLE IF EXISTS `tx_scheduler_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `nextexecution` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_time` int(10) unsigned NOT NULL DEFAULT 0,
  `lastexecution_failure` text DEFAULT NULL,
  `lastexecution_context` varchar(3) NOT NULL DEFAULT '',
  `serialized_task_object` mediumblob DEFAULT NULL,
  `serialized_executions` mediumblob DEFAULT NULL,
  `task_group` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `index_nextexecution` (`nextexecution`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task`
--

LOCK TABLES `tx_scheduler_task` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_scheduler_task_group`
--

DROP TABLE IF EXISTS `tx_scheduler_task_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_scheduler_task_group` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `groupName` varchar(80) NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_scheduler_task_group`
--

LOCK TABLES `tx_scheduler_task_group` WRITE;
/*!40000 ALTER TABLE `tx_scheduler_task_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_scheduler_task_group` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-27  8:20:15
